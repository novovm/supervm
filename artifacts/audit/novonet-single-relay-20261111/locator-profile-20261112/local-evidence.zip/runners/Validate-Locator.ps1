param([switch]$Linux,[ValidateSet('codec','owner','clippy')][string]$Phase)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$platform=if($Linux){'linux'}else{'windows'}
Set-Location $repo
$env:CARGO_TARGET_DIR=if($Linux){'/home/aoem-a1/novovm-build-b-20261102'}else{'C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'}
$env:CARGO_BUILD_JOBS='2'
if($Linux){$env:PATH="/home/aoem-a1/.cargo/bin:$env:PATH"}
$pkg="$repo/artifacts/product-overlay/novonet-observation-a2d7af7f-$platform-x86_64"
$env:NOVOVM_AOEM_TEST_LIBRARY=if($Linux){"$pkg/aoem/linux/core/bin/libaoem_ffi.so"}else{"$pkg/aoem/windows/core/bin/aoem_ffi.dll"}
$env:AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$root="$repo/target/double-relay-20261112/locator-profile"
New-Item -ItemType Directory -Force $root|Out-Null
$checks=@(switch($Phase){
 'codec' { ,@('test','--release','--locked','-p','novovm-network','--lib','--features','iroh-transport','discovery_control::node_locator::tests::','--','--test-threads=1','--nocapture') }
 'owner' { ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','native_pipeline::service::network::','--','--test-threads=1','--nocapture') }
 'clippy' { @(
  ,@('clippy','--release','--locked','-p','novovm-network','--lib','--tests','--features','iroh-transport','--','-D','warnings')
  ,@('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings')
 ) }
})
$index=0
foreach($arguments in $checks){
 $log="$root/$platform-$Phase-v2-$index.log"
 if(Test-Path $log){throw 'Preserve previous evidence'}
 & cargo @arguments 2>&1|Tee-Object $log
 $code=$LASTEXITCODE
 [ordered]@{arguments=$arguments;exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json"
 if($code -ne 0){exit $code}
 if($Phase -ne 'clippy'){
  $count=if($Phase -eq 'codec'){2}else{22}
  if((Get-Content $log -Raw) -notmatch "test result: ok\. $count passed; 0 failed; 0 ignored;"){throw 'Exact original gate count not executed'}
 }
 $index++
}
