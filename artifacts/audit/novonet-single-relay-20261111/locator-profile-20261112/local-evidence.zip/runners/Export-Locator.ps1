$ErrorActionPreference='Stop'
Set-Location D:/WorksArea/SUPERVM
$root='target/double-relay-20261112/locator-profile'
$out='artifacts/audit/novonet-single-relay-20261111/locator-profile-20261112'
$old='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-a2d7af7f-20261112'
if((Test-Path "$out/results.json") -or (Test-Path "$out/local-evidence.zip")){throw 'Preserve prior export'}
$results=@()
foreach($platform in @('windows','linux')){
 foreach($phase in @('codec','owner','clippy')){
  $indices=if($phase -eq 'clippy'){@(0,1)}else{@(0)}
  foreach($i in $indices){
   $log="$root/$platform-$phase-v2-$i.log"
   $r=Get-Content "$log.result.json" -Raw|ConvertFrom-Json
   if($r.exit_code -ne 0){throw 'Gate failed'}
   $count=if($phase -eq 'codec'){2}elseif($phase -eq 'owner'){22}else{$null}
   if($null -ne $count -and (Get-Content $log -Raw) -notmatch "test result: ok\. $count passed; 0 failed; 0 ignored;"){throw 'Actual count differs'}
   $results += [ordered]@{platform=$platform;phase=$phase;log=[IO.Path]::GetFileName($log);arguments=$r.arguments;exit_code=$r.exit_code;passed=$count;utc=$r.utc}
  }
 }
 if((Get-Content "$old/owner-with-packaged-aoem-$platform.log" -Raw) -notmatch 'test result: FAILED\. 19 passed; 3 failed; 0 ignored;'){throw 'Original failure missing'}
}
New-Item -ItemType Directory -Force $out|Out-Null
$z=[IO.Compression.ZipFile]::Open("$out/local-evidence.zip",[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($file in Get-ChildItem $root -File){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,$file.FullName,"fixed/$($file.Name)")}
 foreach($name in @('Validate-Locator.ps1','Export-Locator.ps1')){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,"target/double-relay-20261112/$name","runners/$name")}
 foreach($platform in @('windows','linux')){
  foreach($name in @("owner-with-packaged-aoem-$platform.log","owner-test-build-$platform.log","packaged-native-identity-$platform.log","verified-$platform.json","build-$platform.log")){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,"$old/$name","rejected-a2d7af7f/$name")}
 }
}finally{$z.Dispose()}
$paths=@('crates/novovm-network/src/discovery_control.rs','crates/novovm-network/src/discovery_control/node_locator.rs','crates/novovm-node/src/native_pipeline/service/network.rs','.github/workflows/ci.yml')
[ordered]@{base=(git rev-parse HEAD);source_hashes=@($paths|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash $_).Hash.ToLowerInvariant()}});prior_qualification=@{source='a2d7af7fb867936ca7e062fa32e91ea43e871345';windows=@{passed=19;failed=3};linux=@{passed=19;failed=3};gate='owner-with-packaged-aoem';reason='native locator projection would change signed fields'};checks=$results;archive_sha256=(Get-FileHash "$out/local-evidence.zip").Hash.ToLowerInvariant();full_dispatched=$false;deployed=$false;real_double_relay_accepted=$false}|ConvertTo-Json -Depth 10|Set-Content "$out/results.json"
