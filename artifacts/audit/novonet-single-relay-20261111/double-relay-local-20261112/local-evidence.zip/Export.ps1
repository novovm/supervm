$ErrorActionPreference='Stop'
Set-Location 'D:/WorksArea/SUPERVM'
$sourceRoot=Join-Path (Get-Location) 'target/double-relay-20261112'
$destination=Join-Path (Get-Location) 'artifacts/audit/novonet-single-relay-20261111/double-relay-local-20261112'
if(Test-Path $destination){throw 'Preserve previous export'}
$checks=@()
foreach($platform in @('windows','linux')) {
 foreach($index in 0..8) {
  $stem=if($index -lt 2){"$platform-final-source-$index.log"}elseif($platform -eq 'windows'){"windows-final128-$index.log"}else{"linux-final128-complete-$index.log"}
  $log=Join-Path $sourceRoot $stem
  $code=if($platform -eq 'windows'){(Get-Content "$log.result.json" -Raw | ConvertFrom-Json).exit_code}else{[int](Get-Content "$log.exit-code" -Raw)}
  if($code -ne 0){throw "Failed final check: $stem"}
  $content=Get-Content $log -Raw
  $expected=@(5,2,1,5,2,3)
  if($index -lt 6 -and $content -notmatch "test result: ok\. $($expected[$index]) passed; 0 failed; 0 ignored;"){throw "Missing exact executed count: $stem"}
  $checks += [ordered]@{platform=$platform;log=$stem;exit_code=$code;kind=if($index -lt 6){'test'}else{'clippy'};passed=if($index -lt 6){$expected[$index]}else{$null}}
 }
 foreach($index in 2..3) {
  $stem="$platform-final-source-$index.log"
  $log=Join-Path $sourceRoot $stem
  $code=if($platform -eq 'windows'){(Get-Content "$log.result.json" -Raw | ConvertFrom-Json).exit_code}else{[int](Get-Content "$log.exit-code" -Raw)}
  $content=Get-Content $log -Raw
  if($code -ne 0 -or $content -notmatch 'test result: ok\. ([1-9][0-9]*) passed; 0 failed; 0 ignored;'){throw "Missing compatibility result: $stem"}
  $checks += [ordered]@{platform=$platform;log=$stem;exit_code=$code;kind='compatibility';passed=[int]$Matches[1]}
 }
}
New-Item -ItemType Directory -Path $destination | Out-Null
$files=Get-ChildItem -LiteralPath $sourceRoot -File
Compress-Archive -LiteralPath $files.FullName -DestinationPath (Join-Path $destination 'local-evidence.zip')
$sourcePaths=@(git diff --name-only -- crates .github/workflows/ci.yml)
if($LASTEXITCODE -ne 0){throw 'git source list failed'}
$sourceHashes=@($sourcePaths | ForEach-Object { [ordered]@{path=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()} })
$libraries=@(foreach($platform in @('windows','linux')) {
 $root="artifacts/product-overlay/novonet-observation-875d3307-$platform-x86_64"
 $binary=if($platform -eq 'windows'){"$root/aoem/windows/core/bin/aoem_ffi.dll"}else{"$root/aoem/linux/core/bin/libaoem_ffi.so"}
 [ordered]@{platform=$platform;binary=$binary;sha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant();manifest_sha256=(Get-FileHash -LiteralPath "$root/aoem/manifest/aoem-manifest.json").Hash.ToLowerInvariant()}
})
[ordered]@{scope='local component IO and original owner regression, not real-host acceptance';base=(git rev-parse HEAD);utc=[DateTime]::UtcNow.ToString('o');relay_bytes_per_minute=131072;candidate_validation_authorized=$true;deployment_authorized_by_this_change=$false;checks=$checks;source_hashes=$sourceHashes;aoem=$libraries;archive_sha256=(Get-FileHash -LiteralPath (Join-Path $destination 'local-evidence.zip')).Hash.ToLowerInvariant();raw_files=@($files | ForEach-Object {[ordered]@{name=$_.Name;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $destination 'results.json')
Get-Item (Join-Path $destination 'local-evidence.zip'),(Join-Path $destination 'results.json') | Select-Object Name,Length
