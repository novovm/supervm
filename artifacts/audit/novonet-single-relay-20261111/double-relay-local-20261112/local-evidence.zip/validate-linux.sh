#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export PATH="/home/aoem-a1/.cargo/bin:$PATH"
export CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102
export CARGO_BUILD_JOBS=2
pkg="$PWD/artifacts/product-overlay/novonet-observation-875d3307-linux-x86_64"
export NOVOVM_AOEM_TEST_LIBRARY="$pkg/aoem/linux/core/bin/libaoem_ffi.so"
export AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
export NOVOVM_AOEM_MANIFEST="$AOEM_DLL_MANIFEST"
export NOVOVM_AOEM_TEST_MANIFEST="$AOEM_DLL_MANIFEST"
export AOEM_DLL_MANIFEST_REQUIRED=1
export AOEM_SEMANTIC_GRAPH_V2_WORKERS=2
export NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0
phase="${1:-test}"
label="${2:-v2}"
index=0
run() {
  local log="$PWD/target/double-relay-20261112/linux-$phase-$label-$index.log"
  test ! -e "$log"
  set +e
  cargo "$@" 2>&1 | tee "$log"
  local code=${PIPESTATUS[0]}
  set -e
  printf '%s\n' "$code" > "$log.exit-code"
  test "$code" -eq 0 || exit "$code"
  index=$((index+1))
}
if test "$phase" = test; then
  for filter in service::network::diagnostic service::network::tests::diagnostic service::network::probe::; do
    run test --release --locked -p novovm-node --lib --features iroh-transport "$filter" -- --test-threads=1 --nocapture
  done
  run test --release --locked -p novovmctl native_network_probe -- --test-threads=1 --nocapture
elif test "$phase" = remaining; then
  for filter in service::network::probe:: native_lifecycle::probe::; do
    run test --release --locked -p novovm-node --lib --features iroh-transport "$filter" -- --test-threads=1 --nocapture
  done
  run test --release --locked -p novovmctl native_network_probe -- --test-threads=1 --nocapture
  run test --release --locked -p novovm-network --lib --features iroh-transport relay::hop::tests -- --test-threads=1 --nocapture
  run clippy --release --locked -p novovm-network --lib --tests --features iroh-transport -- -D warnings
else
  test "$phase" = clippy
  run clippy --release --locked -p novovm-node --lib --tests --features iroh-transport -- -D warnings
  run clippy --release --locked -p novovmctl --bin novovmctl -- -D warnings
fi
