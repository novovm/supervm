param([switch]$Linux,[ValidateSet('test','clippy','remaining')][string]$Phase='test',[string]$Label='v2')
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
Set-Location $repo
$platform=if($Linux){'linux'}else{'windows'}
$env:CARGO_TARGET_DIR=if($Linux){'/home/aoem-a1/novovm-build-b-20261102'}else{'C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'}
$env:CARGO_BUILD_JOBS='2'
$pkg="$repo/artifacts/product-overlay/novonet-observation-875d3307-$platform-x86_64"
$env:NOVOVM_AOEM_TEST_LIBRARY=if($Linux){"$pkg/aoem/linux/core/bin/libaoem_ffi.so"}else{"$pkg/aoem/windows/core/bin/aoem_ffi.dll"}
$env:AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$checks=if($Phase -eq 'test'){@(
 ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::diagnostic','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::tests::diagnostic','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::probe::','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovmctl','native_network_probe','--','--test-threads=1','--nocapture')
)}elseif($Phase -eq 'remaining'){@(
 ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::probe::','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','native_lifecycle::probe::','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovmctl','native_network_probe','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-network','--lib','--features','iroh-transport','relay::hop::tests','--','--test-threads=1','--nocapture')
 ,@('clippy','--release','--locked','-p','novovm-network','--lib','--tests','--features','iroh-transport','--','-D','warnings')
)}else{@(
 ,@('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings')
 ,@('clippy','--release','--locked','-p','novovmctl','--bin','novovmctl','--','-D','warnings')
)}
$index=0
foreach($arguments in $checks){
 $log="$repo/target/double-relay-20261112/$platform-$Phase-$Label-$index.log"
 if(Test-Path $log){throw "Preserve prior evidence: $log"}
 & cargo @arguments 2>&1|Tee-Object -FilePath $log
 $code=$LASTEXITCODE
 [ordered]@{arguments=$arguments;exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json"
 if($code -ne 0){exit $code}
 $index++
}
