$ErrorActionPreference='Stop'
Set-Location 'D:/WorksArea/SUPERVM'
$env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'
$env:CARGO_BUILD_JOBS='2'
$pkg='D:/WorksArea/SUPERVM/artifacts/product-overlay/novonet-observation-875d3307-windows-x86_64'
$env:NOVOVM_AOEM_TEST_LIBRARY="$pkg/aoem/windows/core/bin/aoem_ffi.dll"
$env:AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$testBinary=Join-Path $env:CARGO_TARGET_DIR 'release/deps/novovm_node-2448a5ce12032170.exe'
$binaryHash=(Get-FileHash -LiteralPath $testBinary).Hash
$index=0
foreach($filter in @('service::network::diagnostic','service::network::tests::diagnostic','carrier_tests','retained_tick_reactor_')) {
 $log="target/double-relay-20261112/windows-final-source-$index.log"
 if(Test-Path $log){throw "Preserve previous evidence: $log"}
 & $testBinary $filter --test-threads=1 --nocapture 2>&1 | Tee-Object -FilePath $log
 $code=$LASTEXITCODE
 if((Get-FileHash -LiteralPath $testBinary).Hash -ne $binaryHash){throw 'Test binary changed during execution'}
 [ordered]@{filter=$filter;binary=$testBinary;sha256=$binaryHash;exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content "$log.result.json"
 if($code -ne 0){exit $code}
 $index++
}
