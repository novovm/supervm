#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export PATH="/home/aoem-a1/.cargo/bin:$PATH"
export CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102
export CARGO_BUILD_JOBS=2
index=0
for filter in service::network::diagnostic service::network::tests::diagnostic carrier_tests retained_tick_reactor_; do
  log="target/double-relay-20261112/linux-final-source-$index.log"
  test ! -e "$log"
  set +e
  cargo test --release --locked -p novovm-node --lib --features iroh-transport "$filter" -- --test-threads=1 --nocapture 2>&1 | tee "$log"
  code=${PIPESTATUS[0]}
  set -e
  printf '%s\n' "$code" > "$log.exit-code"
  test "$code" -eq 0 || exit "$code"
  index=$((index+1))
done
