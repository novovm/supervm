$ErrorActionPreference='Stop'
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$script=Get-Content D:/WorksArea/SUPERVM/target/relay-constraint-20261111/Freeze-Candidate.ps1 -Raw
if(!$script.Contains("'owner-with-packaged-aoem'=20")){throw 'Original freeze gate changed'}
$script=$script.Replace('candidate-observation-$short-20261111','candidate-observation-$short-20261112').Replace("'owner-with-packaged-aoem'=20","'owner-with-packaged-aoem'=22")
& ([scriptblock]::Create($script)) -Source $source
