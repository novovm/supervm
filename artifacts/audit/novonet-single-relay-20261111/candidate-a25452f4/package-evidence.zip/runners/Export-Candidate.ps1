$ErrorActionPreference='Stop'
Set-Location D:/WorksArea/SUPERVM
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$root='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-a25452f4-20261112'
$out='artifacts/audit/novonet-single-relay-20261111/candidate-a25452f4'
$m=Get-Content "$out/candidate-manifest.json" -Raw|ConvertFrom-Json
if($m.source_commit -cne $source -or !$m.both_platforms_qualified){throw 'Fixed manifest required'}
if(Test-Path "$out/package-evidence.zip"){throw 'Preserve previous evidence'}
$names=@('build-windows.log','build-linux.log','verified-windows.json','verified-linux.json','owner-qualification-windows.json','owner-qualification-linux.json','owner-test-build-windows.log','owner-test-build-linux.log')
foreach($platform in @('windows','linux')){
 foreach($name in @('packaged-native-identity','owner-with-packaged-aoem','packaged-node-recovery','packaged-uca-recovery','packaged-runtime-startup')){$names+="$name-$platform.log"}
 foreach($kind in @('relay-commands','double-relay-commands')){
  $result=Get-Content "$root/$kind-$platform/result.json" -Raw|ConvertFrom-Json
  if($result.source -cne $source -or $result.results.Count -ne 3 -or @($result.results|Where-Object exit_code -NE 0).Count){throw 'Packaged CLI evidence incomplete'}
  foreach($leaf in @('result.json','arm.json','send.json','cancel.json','arm.stderr','send.stderr','cancel.stderr')){$names+="$kind-$platform/$leaf"}
 }
}
$z=[IO.Compression.ZipFile]::Open("$out/package-evidence.zip",[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($name in $names){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,"$root/$name",$name)}
 foreach($name in @('Candidate.ps1','Qualify.ps1','Check-Packaged-Commands.ps1','Freeze-Candidate.ps1','Dispatch-Qualified-Full.ps1','Export-Candidate.ps1')){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,"target/double-relay-20261112/$name","runners/$name")}
}finally{$z.Dispose()}
[ordered]@{source_commit=$source;sha256=(Get-FileHash "$out/package-evidence.zip").Hash.ToLowerInvariant();public_evidence_only=$true;files=@($names|ForEach-Object{[ordered]@{name=$_;bytes=(Get-Item "$root/$_").Length;sha256=(Get-FileHash "$root/$_").Hash.ToLowerInvariant()}})}|ConvertTo-Json -Depth 8|Set-Content "$out/package-evidence-manifest.json"
