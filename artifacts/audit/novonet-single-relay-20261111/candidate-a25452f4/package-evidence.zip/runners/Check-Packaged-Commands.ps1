param([switch]$Linux)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$script=Get-Content "$repo/target/relay-constraint-20261111/Check-Packaged-Relay-Commands.ps1" -Raw
$script=$script.Replace('20261111','20261112')
& ([scriptblock]::Create($script)) -Source $source -Linux:$Linux
$script=$script.Replace('relay-commands-$platform','double-relay-commands-$platform').Replace("'--via',('33'*32)","'--via',('33'*32),'--via',('55'*32)").Replace('409','441')
& ([scriptblock]::Create($script)) -Source $source -Linux:$Linux
$platform=if($Linux){'linux'}else{'windows'}
$delivery=if($Linux){'/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-a25452f4-20261112'}else{'C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-a25452f4-20261112'}
foreach($name in @('arm','send','cancel')) {
 $response=Get-Content "$delivery/double-relay-commands-$platform/$name.json" -Raw|ConvertFrom-Json
 $bytes=[IO.File]::ReadAllBytes("$delivery/double-relay-commands-$platform/$name.nvprobe")
 if($response.data.relays.Count -ne 2 -or @($response.data.relays[1]|Where-Object {$_ -ne 85}).Count -or @($bytes[409..440]|Where-Object {$_ -ne 85}).Count){throw 'Second relay was not preserved in packaged command'}
}
Write-Output 'PASS actual packaged single/double relay commands; local files only'
