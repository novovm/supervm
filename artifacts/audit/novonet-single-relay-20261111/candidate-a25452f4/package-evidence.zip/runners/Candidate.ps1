param([Parameter(Mandatory)][ValidateSet('Build','Verify','Qualify','Archive')][string]$Phase,[switch]$Linux)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$script=Get-Content "$repo/target/openssl-security-20261110/Candidate.ps1" -Raw
$old='$deliveryName="candidate-observation-$short-20261110"'
if(!$script.Contains($old)){throw 'Original candidate wrapper changed'}
$script=$script.Replace($old,'$deliveryName="candidate-observation-$short-20261112"')
& ([scriptblock]::Create($script)) -Source $source -Phase $Phase -Linux:$Linux
