$ErrorActionPreference='Stop'
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$script=Get-Content D:/WorksArea/SUPERVM/target/relay-constraint-20261111/Dispatch-Qualified-Full.ps1 -Raw
$script=$script.Replace('candidate-observation-$short-20261111','candidate-observation-$short-20261112')
& ([scriptblock]::Create($script)) -Source $source
