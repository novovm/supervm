param([switch]$Linux)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$source='a25452f4c49be37cd984e650f2079642e6c273b3'
$archive=[IO.Compression.ZipFile]::OpenRead("$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/original-package-evidence.zip")
try{$reader=[IO.StreamReader]::new($archive.GetEntry('Qualify-Fixed-Package.ps1').Open());try{$script=$reader.ReadToEnd()}finally{$reader.Dispose()}}finally{$archive.Dispose()}
if(!$script.Contains("count=15;ignored=`$false") -or !$script.Contains('Frozen clean source required')){throw 'Original qualifier changed'}
$script=$script.Replace('1ef3189307382ef579775c7ce2b55a08d829d04a',$source).Replace('1ef31893','a25452f4').Replace('candidate-observation-a25452f4-20261110','candidate-observation-a25452f4-20261112')
$script=$script.Replace("count=15;ignored=`$false","count=22;ignored=`$false")
$script=$script.Replace('& "$repo/target/openssl-security-20261110/Candidate.ps1" -Source $source -Phase','& "$repo/target/double-relay-20261112/Candidate.ps1" -Phase')
& ([scriptblock]::Create($script)) -Linux:$Linux
