#Requires -Version 7.0
#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference=$false
$out='D:/WorksArea/SUPERVM/target/native-time-upgrade-20261110/single-relay-window-20261111'
$taskName='NOVOVM-AD-UDP-restore-20261111-single-relay'
$rules=@('NOVOVM-AD-UDP-in-20261111-single-relay','NOVOVM-AD-UDP-out-20261111-single-relay')
$work='C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-observation-8fed4b76-20261110'
$root='C:/ProgramData/NOVOVM/releases/novonet-observation-8fed4b76-windows-x86_64'
$exe="$root/bin/novovm-node.exe"
$command="$work/commands/control.nvprobe"
function Hex($bytes){[Convert]::ToHexString([byte[]]$bytes).ToLowerInvariant()}
function Read-Public {
 $file=Get-Item "$work/logs/progress.json"
 if($file.Length -gt 4MB -or ([DateTime]::UtcNow-$file.LastWriteTimeUtc).TotalSeconds -gt 15){throw 'Stale/unbounded original progress'}
 $p=[IO.File]::ReadAllText($file.FullName)|ConvertFrom-Json
 if($p.chain_id -ne 91129655606029 -or $p.execution_failures -ne 0){throw 'Original node health differs'}
 return $p
}
function Save-Public($p,$name){
 [ordered]@{utc=[DateTime]::UtcNow.ToString('o');chain_id=$p.chain_id;current_height=$p.current_height;execution_failures=$p.execution_failures;novonet=$p.novonet;native_network_probe=$p.native_network_probe}|ConvertTo-Json -Depth 80|Set-Content "$out/$name" -Encoding utf8
}
if(Test-Path -LiteralPath $out){throw 'One attempt only; evidence already exists'}
New-Item -ItemType Directory -Path $out|Out-Null
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');status='preflight';object_sent=$false;restored=$false;node_restarted=$false;production_settings_changed=$false}
$registered=$false
try {
 if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Cleanup task name occupied'}
 foreach($name in $rules){if(Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue){throw 'Rule name occupied'}}
 if(@(Get-NetFirewallProfile|Where-Object {!$_.Enabled}).Count){throw 'Firewall must already be enabled; not changing profiles'}
 if((Get-FileHash $exe).Hash.ToLowerInvariant() -cne '021e7f8b0b41d8b72577d7394cd9c1fb9edb8388c4ae90903dca6f86a53a8a32'){throw 'Fixed executable mismatch'}
 if((Get-FileHash "$root/bin/novovmctl.exe").Hash.ToLowerInvariant() -cne '6201c4a18a7fa8cdd176cb9715ceedfe6912e8538761aefc263140a4506d77ec'){throw 'Fixed ctl mismatch'}
 $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"|Where-Object ExecutablePath -IEQ $exe.Replace('/','\'))
 if($nodes.Count -ne 1 -or (Invoke-CimMethod $nodes[0] -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Original LocalService owner not confirmed'}
 $result.pid=$nodes[0].ProcessId
 $config=Get-Content "$work/run.json" -Raw|ConvertFrom-Json
 $net=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
 if(!$net.relay_forwarding -or $net.probe_control_file.Replace('\','/') -cne $command){throw 'Original relay/command owner differs'}
 $transportIds=@($config.genesis.validators|ForEach-Object {'novovm-mldsa65:'+(Hex ([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("NOVOVM/transport-identity/ML-DSA-65/v2`0")+[byte[]]$_.transport_public_key))))})
 $validatorIds=@($config.genesis.validators|ForEach-Object {Hex ([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("novovm-round-bft/v2/mldsa65/validator-id`0")+[byte[]]$_.public_key)))})
 if($validatorIds[0] -cne 'b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43' -or $validatorIds[3] -cne 'd90f5145f324790d6cef7b592d25747d0fb21958327eaeeb2367c800d74a8f90'){throw 'A/D identity differs'}
 $result.transport_ids=$transportIds
 $p=Read-Public
 Save-Public $p 'before.json'
 $oldHash=if(Test-Path $command){(Get-FileHash $command).Hash}else{$null}
 # Independent SYSTEM watchdog, registered before either temporary rule exists.
 # Constant encoded command removes only the two names owned by this window.
 $cleanup="`$ErrorActionPreference='Stop'; @('$($rules[0])','$($rules[1])') | ForEach-Object { Get-NetFirewallRule -Name `$_ -ErrorAction SilentlyContinue | Remove-NetFirewallRule }; [ordered]@{utc=[DateTime]::UtcNow.ToString('o');watchdog=`$true;remaining=@(Get-NetFirewallRule -Name '$($rules[0])','$($rules[1])' -ErrorAction SilentlyContinue).Count}|ConvertTo-Json|Set-Content -LiteralPath '$out/watchdog.json' -Encoding utf8"
 $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cleanup))
 $trigger=New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(270)
 $action=New-ScheduledTaskAction -Execute 'C:/Program Files/PowerShell/7/pwsh.exe' -Argument "-NoProfile -NonInteractive -EncodedCommand $encoded"
 $settings=New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 1)
 Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -User 'SYSTEM' -RunLevel Highest|Out-Null
 $registered=$true
 if((Get-ScheduledTask -TaskName $taskName).State -ne 'Ready'){throw 'Independent restore not armed'}
 $result.watchdog_due_local=$trigger.StartBoundary
 $clock=[Diagnostics.Stopwatch]::StartNew()
 foreach($direction in @('Inbound','Outbound')) {
  $name=if($direction -eq 'Inbound'){$rules[0]}else{$rules[1]}
  New-NetFirewallRule -Name $name -DisplayName $name -Direction $direction -Action Block -Enabled True -Profile Any -Protocol UDP -Program $exe.Replace('/','\') -LocalAddress 192.168.71.74 -RemoteAddress 192.168.71.59 -LocalPort @('41051','42051') -RemotePort @('41053','42053') -PolicyStore PersistentStore|Out-Null
 }
 $result.block_started_utc=[DateTime]::UtcNow.ToString('o')
 $ruleEvidence=@($rules|ForEach-Object {$r=Get-NetFirewallRule -PolicyStore ActiveStore -Name $_; [ordered]@{name=$r.Name;enabled=$r.Enabled.ToString();direction=$r.Direction.ToString();action=$r.Action.ToString();ports=($r|Get-NetFirewallPortFilter|Select-Object Protocol,LocalPort,RemotePort);addresses=($r|Get-NetFirewallAddressFilter|Select-Object LocalAddress,RemoteAddress);application=($r|Get-NetFirewallApplicationFilter|Select-Object Program)}})
 $ruleEvidence|ConvertTo-Json -Depth 8|Set-Content "$out/rules.json" -Encoding utf8
 if(@($ruleEvidence|Where-Object {$_.action -ne 'Block' -or $_.enabled -ne 'True'}).Count){throw 'Temporary block not active'}
 $result.status='waiting_for_authenticated_single_relay'
 $result|ConvertTo-Json -Depth 8|Set-Content "$out/live.json" -Encoding utf8
 $snapshot=0;$sentNonce=$null;$selected=$null
 while($clock.Elapsed.TotalSeconds -lt 240) {
  $p=Read-Public
  if($snapshot % 10 -eq 0){Save-Public $p ('observe-{0:D3}.json' -f $snapshot)}
  $snapshot++
  $time=@($p.native_network_probe.protocol_time.peers|Where-Object {(Hex $_.peer) -ceq $validatorIds[3] -and $_.relative_ready})
  $circuits=@($p.native_network_probe.transport.relay_circuits|Where-Object {$_.route.role -ceq 'origin' -and $_.route.origin -ceq $transportIds[0] -and $_.route.path.Count -eq 2 -and $_.route.path[1] -ceq $transportIds[3] -and $_.route.path[0] -in @($transportIds[1],$transportIds[2]) -and $null -ne $_.native_session -and $null -eq $_.stream_dropped_us})
  $matched=@($circuits|Where-Object {$s=Hex $_.native_session; @($time|Where-Object {(Hex $_.session) -ceq $s}).Count -eq 1})
  if(!$result.object_sent -and $matched.Count -eq 1 -and $p.novonet.installed_bound_peer_routes -gt 0 -and $clock.Elapsed.TotalSeconds -lt 210) {
   $selected=$matched[0];Save-Public $p 'before-send.json'
   if(Test-Path $command){if((Get-FileHash $command).Hash -cne $oldHash){throw 'Command slot changed concurrently'};Move-Item -LiteralPath $command -Destination "$out/prior-command.nvprobe"}
   $result.object_sent=$true
   $result.selected_circuit=$selected
   $result|ConvertTo-Json -Depth 30|Set-Content "$out/live.json" -Encoding utf8
   & "$root/bin/novovmctl.exe" native-network-probe prepare --sender $validatorIds[0] --recipient $validatorIds[3] --output $command 1> "$out/command.json" 2> "$out/command.stderr"
   if($LASTEXITCODE -ne 0){throw 'One prepare failed; no retry'}
   Copy-Item -LiteralPath $command -Destination "$out/command.nvprobe"
   $prepared=Get-Content "$out/command.json" -Raw|ConvertFrom-Json
   $sentNonce=Hex $prepared.data.nonce
   $result.nonce=$sentNonce
  }
  if($sentNonce){
   $events=@($p.native_network_probe.events|Where-Object {(Hex $_.nonce) -ceq $sentNonce})
   if(@($events|Where-Object {$_.event -ceq 'probe_object_done' -or $_.event -match 'expired|rejected|cancelled'}).Count){
    Save-Public $p 'sender-terminal.json';$result.events=$events
    $done=@($events|Where-Object {$_.event -ceq 'probe_object_done' -and (Hex $_.session_id) -ceq (Hex $selected.native_session) -and $_.path -ne 'native_udp'})
    $result.status=if($done.Count -eq 1){'SENDER_DONE_REQUIRES_RELAY_AND_RECEIVER_MATCH'}else{'OBJECT_TERMINAL_NOT_QUALIFIED_SINGLE_RELAY'}
    break
   }
  }
  Start-Sleep -Seconds 1
 }
 if(!$result.object_sent){$result.status='NO_AUTHENTICATED_SINGLE_RELAY_NO_OBJECT_SENT'}
 Save-Public (Read-Public) 'before-restore.json'
}catch{$result.error=$_.Exception.Message;$result.status='STOPPED_ON_ERROR'}
finally {
 foreach($name in $rules){Get-NetFirewallRule -PolicyStore PersistentStore -Name $name -ErrorAction SilentlyContinue|Remove-NetFirewallRule -ErrorAction Continue}
 $remaining=@($rules|ForEach-Object {Get-NetFirewallRule -PolicyStore ActiveStore -Name $_ -ErrorAction SilentlyContinue})
 $result.remaining_rules=$remaining.Count
 $result.restored=($remaining.Count -eq 0)
 $result.completed_utc=[DateTime]::UtcNow.ToString('o')
 if($registered -and $result.restored){Unregister-ScheduledTask -TaskName $taskName -Confirm:$false}
 $result|ConvertTo-Json -Depth 50|Set-Content "$out/result.json" -Encoding utf8
}
if(!$result.restored -or $result.Contains('error')){exit 1}
