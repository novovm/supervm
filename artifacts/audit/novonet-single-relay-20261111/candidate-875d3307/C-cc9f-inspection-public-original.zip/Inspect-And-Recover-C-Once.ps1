#Requires -Version 7.0
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference=$false
$root=$PSScriptRoot
$settings=Get-Content -LiteralPath (Join-Path $root 'settings.json') -Raw | ConvertFrom-Json
$oldExe='C:\ProgramData\NOVOVM\releases\novonet-observation-8fed4b76-windows-x86_64\bin\novovm-node.exe'
$oldPin='021e7f8b0b41d8b72577d7394cd9c1fb9edb8388c4ae90903dca6f86a53a8a32'
$logs='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-observation-8fed4b76-20261110\logs'
$oldTask='NOVOVM-C-8fed4b76-Existing-20261110'
$public=Join-Path $root 'public'
function Save([string]$path,$data) {
    $b=[Text.UTF8Encoding]::new($false).GetBytes(($data|ConvertTo-Json -Depth 35))
    $f=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}
}
function File-View([string]$path) {
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) {return [ordered]@{path=$path;exists=$false}}
    $f=Get-Item -LiteralPath $path
    return [ordered]@{path=$path;exists=$true;bytes=$f.Length;last_write_utc=$f.LastWriteTimeUtc.ToString('o');sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
}
function Task-View($task) {
    $info=Get-ScheduledTaskInfo -TaskName $task.TaskName -TaskPath $task.TaskPath
    $sid=if($task.Principal.UserId.StartsWith('S-1-')){$task.Principal.UserId}else{([Security.Principal.NTAccount]::new($task.Principal.UserId)).Translate([Security.Principal.SecurityIdentifier]).Value}
    return [ordered]@{name=$task.TaskName;path=$task.TaskPath;state=$task.State.ToString();principal=$task.Principal.UserId;sid=$sid;last_run_utc=$info.LastRunTime.ToUniversalTime().ToString('o');last_task_result=[uint32]$info.LastTaskResult;restart_count=[int]$task.Settings.RestartCount;trigger_count=@($task.Triggers|Where-Object {$null -ne $_}).Count;execution_time_limit=[string]$task.Settings.ExecutionTimeLimit;last_run=$info.LastRunTime.ToUniversalTime()}
}
function Process-View($node) {
    $sidResult=Invoke-CimMethod -InputObject $node -MethodName GetOwnerSid
    if ($sidResult.ReturnValue -ne 0) {throw 'Process owner SID unavailable'}
    if ([string]::IsNullOrWhiteSpace($node.ExecutablePath)) {throw 'Process executable path unavailable'}
    return [ordered]@{pid=$node.ProcessId;parent_pid=$node.ParentProcessId;created_utc=$node.CreationDate.ToUniversalTime().ToString('o');exe=$node.ExecutablePath;exe_sha256=(Get-FileHash -LiteralPath $node.ExecutablePath -Algorithm SHA256).Hash.ToLowerInvariant();sid=$sidResult.Sid}
}
$principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {throw 'Administrator PowerShell7 required'}
if (Test-Path -LiteralPath $public) {throw 'Evidence already exists; do not rerun'}
New-Item -ItemType Directory -Path $public | Out-Null
Save (Join-Path $root 'inspection-invoked-once.json') ([ordered]@{host='C';handoff='cc9f874b';started_utc=[DateTime]::UtcNow.ToString('o');D_touched=$false;collector_started=$false})
$obs=[ordered]@{host='C';started_utc=[DateTime]::UtcNow.ToString('o');inspection_completed=$false;active=@();exited=@();ports=@();tasks=@();errors=@()}
$invocations=0;$updateCode=$null;$controllerCode=1;$branch=$null;$status=$null
try {
    $updater=Join-Path $settings.tools 'Update-Windows.ps1'
    $helper=Join-Path $settings.tools 'NovonetExistingProcess.ps1'
    if ((Get-FileHash $updater).Hash.ToLowerInvariant() -cne 'e50d180036b8d82eda6991ab7dd4cf2d4555970b231ef675d02cbb853b2ea7d2' -or (Get-FileHash $helper).Hash.ToLowerInvariant() -cne '4d6f1b1dc79251034493c0d55fbda942da5515cee95b756293801e3177b415be') {throw 'Original tool hash differs'}
    . $helper
    $tokens=$null;$parseErrors=$null
    $ast=[Management.Automation.Language.Parser]::ParseFile($updater,[ref]$tokens,[ref]$parseErrors)
    if ($parseErrors.Count) {throw 'Original updater parse failure'}
    $functions=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false))
    foreach($name in @('Assert-StoppedOwnerEvidence','Assert-CrashedOwnerEvidence','Assert-RecoveredProgress','ConvertFrom-NovonetCrashEvent')) {
        $f=@($functions|Where-Object Name -CEQ $name)
        if ($f.Count -ne 1) {throw 'Original validation function absent'}
        . ([scriptblock]::Create($f[0].Extent.Text))
    }
    $execution=Get-NovonetNodeExecutionState
    foreach($n in @($execution.active)) {$obs.active+=,(Process-View $n)}
    $obs.exited=@($execution.exited)
    $ports=@(Get-NetUDPEndpoint|Where-Object {$_.LocalPort -in @(41052,42052)})
    foreach($p in $ports) {
        $node=Get-CimInstance Win32_Process -Filter "ProcessId=$($p.OwningProcess)"
        if ($null -eq $node) {throw 'UDP port owner cannot be identified'}
        $obs.ports+=,[ordered]@{address=$p.LocalAddress;port=$p.LocalPort;owner=(Process-View $node)}
    }
    $tasks=@(Get-ScheduledTask|Where-Object {$_.TaskName -like 'NOVOVM-C-*'})
    foreach($t in $tasks) {$obs.tasks+=,(Task-View $t)}
    $task=@($obs.tasks|Where-Object {$_.name -ceq $oldTask})
    if ($task.Count -ne 1) {throw 'Original C task absent or ambiguous'}
    $task=$task[0]
    $obs.old_executable=File-View $oldExe
    $progressFile=Join-Path $logs 'progress.json'
    $obs.progress_file=File-View $progressFile
    $obs.exit_file=File-View (Join-Path $logs 'exit.json')
    $obs.log_files=@((File-View (Join-Path $logs 'node.stdout')),(File-View (Join-Path $logs 'node.stderr')))
    $obs.failure_lines=@()
    foreach($name in @('node.stdout','node.stderr')) {
        $path=Join-Path $logs $name
        if (Test-Path -LiteralPath $path) {
            $lines=@(Get-Content -LiteralPath $path -Tail 200 | Where-Object {$_ -match '(?i)panic|fatal|exception|error|failed|denied'} | Select-Object -Last 20)
            foreach($line in $lines) {
                $safe=([string]$line) -replace '(?i)(password|secret|token|bearer|capability)\s*[:=]\s*\S+','$1=[redacted]'
                $safe=$safe -replace '[A-Za-z0-9_+/=-]{60,}','[redacted-long-value]'
                if ($safe.Length -gt 512) {$safe=$safe.Substring(0,512)+'[truncated]'}
                $obs.failure_lines+=,[ordered]@{file=$name;line=$safe;redacted=$true}
            }
        }
    }
    $obs.matching_crashes=@()
    try {$events=@(Get-WinEvent -FilterHashtable @{LogName='Application';Id=1000;StartTime=$task.last_run.ToLocalTime()})}
    catch {if ($_.FullyQualifiedErrorId -like 'NoMatchingEventsFound*') {$events=@()}else{throw}}
    foreach($event in $events) {
        $crash=ConvertFrom-NovonetCrashEvent ([xml]$event.ToXml()) $event.TimeCreated.ToUniversalTime() $event.RecordId $oldExe
        if ($null -ne $crash) {$obs.matching_crashes+=,$crash}
    }
    if (!$obs.progress_file.exists -or $obs.progress_file.bytes -gt 67108864) {throw 'Original progress absent or too large to inspect safely'}
    $progress=Get-Content -LiteralPath $progressFile -Raw|ConvertFrom-Json
    $obs.progress=[ordered]@{}
    foreach($field in @('entry','chain_id','current_height','head','execution_failures','recovery_in_progress')) {
        if ($progress.psobject.Properties.Name -notcontains $field) {throw 'Original progress missing public field'}
        $obs.progress[$field]=$progress.$field
    }
    Assert-RecoveredProgress $progress $progress $false
    if ($obs.exit_file.exists) {
        $exit=Get-Content -LiteralPath (Join-Path $logs 'exit.json') -Raw|ConvertFrom-Json
        $obs.exit=[ordered]@{exit_code=$exit.exit_code;start=$exit.start;time=$exit.time}
        if ($exit.start -cne 'existing' -or [uint32]$exit.exit_code -ne $task.last_task_result -or [DateTime]$exit.time -lt $task.last_run.AddSeconds(-5) -or [DateTime]$exit.time -gt [DateTime]::UtcNow.AddSeconds(5)) {throw 'Original task and exit evidence conflict'}
    }
    $obs.inspection_completed=$true
    $obs.ended_utc=[DateTime]::UtcNow.ToString('o')
    Save (Join-Path $public 'old-owner-public.json') $obs
    if ($obs.active.Count -ne 0 -or $obs.ports.Count -ne 0) {throw 'Recovery requires no executing node and no target port owner'}
    if (@($obs.tasks|Where-Object {$_.name -cne $oldTask -and $_.state -ceq 'Running'}).Count -ne 0) {throw 'Another C NOVOVM task is running'}
    if (!$obs.old_executable.exists -or $obs.old_executable.sha256 -cne $oldPin) {throw 'Original old executable identity mismatch'}
    $proof=[pscustomobject]@{task_state=$task.state;task_sid=$task.sid;restart_count=$task.restart_count;trigger_count=$task.trigger_count;task_exit_code=$task.last_task_result;executing_nodes=$obs.active.Count;bound_ports=$obs.ports.Count;last_run_utc=$task.last_run;progress_utc=[DateTime]$obs.progress_file.last_write_utc}
    $qualified=@();$gates=@()
    foreach($interrupted in @($false,$true)) {
        try {Assert-StoppedOwnerEvidence $proof $interrupted;$qualified+= $(if($interrupted){'RecoverInterrupted'}else{'ResumeStopped'});$gates+=,[ordered]@{branch=$qualified[-1];qualified=$true}}
        catch {$gates+=,[ordered]@{branch=$(if($interrupted){'RecoverInterrupted'}else{'ResumeStopped'});qualified=$false;reason=$_.Exception.Message}}
    }
    try {
        $crash=@($obs.matching_crashes|Sort-Object event_utc -Descending|Select-Object -First 1)
        if ($crash.Count -ne 1) {throw 'Current matching crash event absent'}
        $crash=$crash[0]
        $crash|Add-Member -NotePropertyMembers @{task_state=$task.state;task_sid=$task.sid;restart_count=$task.restart_count;trigger_count=$task.trigger_count;task_exit_code=$task.last_task_result;last_run_utc=$task.last_run}
        Assert-CrashedOwnerEvidence $crash $oldExe
        $qualified+='RecoverCrashed';$gates+=,[ordered]@{branch='RecoverCrashed';qualified=$true}
    } catch {$gates+=,[ordered]@{branch='RecoverCrashed';qualified=$false;reason=$_.Exception.Message}}
    if ($qualified.Count -ne 1) {Save (Join-Path $public 'branch-decision.json') @{qualified=$qualified;gates=$gates;update_started=$false};throw 'Exactly one original recovery branch was not proven'}
    $branch=$qualified[0]
    Save (Join-Path $public 'branch-decision.json') ([ordered]@{branch=$branch;qualified=$qualified;gates=$gates;time_utc=[DateTime]::UtcNow.ToString('o');updater_rechecks_all_guards=$true;old_program_started_first=$false})
    Save (Join-Path $root 'recovery-invoked-once.json') ([ordered]@{host='C';started_utc=[DateTime]::UtcNow.ToString('o');branch=$branch;updater_sha256='e50d180036b8d82eda6991ab7dd4cf2d4555970b231ef675d02cbb853b2ea7d2';evidence=$settings.evidence;start='existing'})
    $invocations=1
    $switch='-'+$branch
    & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoProfile -NonInteractive -File $updater -HostId C -PackageRoot $settings.package_root -EvidenceRoot $settings.evidence $switch 1> (Join-Path $public 'update.stdout.log') 2> (Join-Path $public 'update.stderr.log')
    $updateCode=$LASTEXITCODE
    foreach($name in @('result.json','error.json','old-exit.json','firewall.json','rollback-requested.json','recovery-stopped.json','stopped-owner-preflight.json','crash-recovery-preflight.json')) {
        $file=Join-Path $settings.evidence $name
        if (Test-Path -LiteralPath $file) {Copy-Item -LiteralPath $file -Destination (Join-Path $public $name)}
    }
    if ($updateCode -ne 0) {throw 'Original recovery updater failed; no automatic retry'}
    $a=Get-Content -LiteralPath (Join-Path $settings.evidence 'after.json') -Raw|ConvertFrom-Json
    $p=$a.progress;$probe=$p.native_network_probe;$fields=@($probe.transport.psobject.Properties.Name)
    $after=[ordered]@{}
    foreach($field in @('host_id','time','source','pid','exe','node_sha256','sid','database','start','initialize_executed','keys_generated','custody_unchanged','aoem_module','aoem_sha256','old_task','new_task','listeners','new_command_file_present')) {$after[$field]=$a.$field}
    foreach($field in @('entry','chain_id','current_height','head','execution_failures','recovery_in_progress')) {$after[$field]=$p.$field}
    $after.probe_enabled=$probe.enabled;$after.relay_observation_available=(($fields -contains 'relay_circuits') -and ($fields -contains 'relay_evicted_records') -and ($fields -contains 'relay_omitted_observations'))
    $after.collector_started=$false;$after.authenticated_A_query_pending=$true
    Save (Join-Path $public 'after-public.json') $after
    $status='C_875_EXISTING_READY_FOR_A_QUERY';$controllerCode=0
} catch {
    $obs.errors+=,$_.Exception.Message
    if (!(Test-Path -LiteralPath (Join-Path $public 'old-owner-public.json'))) {$obs.ended_utc=[DateTime]::UtcNow.ToString('o');Save (Join-Path $public 'old-owner-public.json') $obs}
    Save (Join-Path $public 'controller-error.json') ([ordered]@{error=$_.ToString();time_utc=[DateTime]::UtcNow.ToString('o');updater_invocations=$invocations;branch=$branch;updater_exit_code=$updateCode})
} finally {
    Save (Join-Path $public 'controller-exit.json') ([ordered]@{host='C';handoff='cc9f874b';status=$status;finished_utc=[DateTime]::UtcNow.ToString('o');controller_exit_code=$controllerCode;updater_invocations=$invocations;updater_exit_code=$updateCode;branch=$branch;D_touched=$false;collector_started=$false;new_object_sent=$false;initialize_requested=$false})
}
exit $controllerCode