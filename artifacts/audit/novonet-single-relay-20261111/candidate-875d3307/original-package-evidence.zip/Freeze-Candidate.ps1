param([Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{40}$')][string]$Source,[ValidateSet('windows','linux')][string]$OnlyPlatform)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:/WorksArea/SUPERVM'
$short=$Source.Substring(0,8)
$delivery="C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111"
$out="$repo/artifacts/audit/novonet-single-relay-20261111/candidate-$short"
$outputName=if($OnlyPlatform){"candidate-$OnlyPlatform-preparation.json"}else{'candidate-manifest.json'}
if(Test-Path "$out/$outputName"){throw 'Preserve frozen manifest'}
$packages=@()
$platforms=if($OnlyPlatform){@($OnlyPlatform)}else{@('windows','linux')}
foreach($platform in $platforms){
 $v=Get-Content "$delivery/verified-$platform.json" -Raw|ConvertFrom-Json
 $q=Get-Content "$delivery/owner-qualification-$platform.json" -Raw|ConvertFrom-Json
 $name="novonet-observation-$short-$platform-x86_64"
 $root="$repo/artifacts/product-overlay/$name"
 $manifest=Get-Content "$root/release-manifest.json" -Raw|ConvertFrom-Json
 if($v.source_commit -cne $Source -or $q.source_commit -cne $Source -or $manifest.git_commit -cne $Source -or $v.node_sha256 -cne $q.node_sha256 -or (Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant() -cne $v.manifest_sha256){throw 'Actual fixed source/package evidence differs'}
 $expected=@{'owner-with-packaged-aoem'=20;'packaged-node-recovery'=6;'packaged-uca-recovery'=1;'packaged-runtime-startup'=1}
 if($q.results.Count -ne $expected.Count){throw 'Incomplete owner result'}
 foreach($r in $q.results){if(!$expected.ContainsKey($r.name) -or $r.exit -ne 0 -or $r.passed -ne $expected[$r.name]){throw 'Owner gate failed or count differs'}}
 if((Get-Content "$delivery/packaged-native-identity-$platform.log" -Raw) -notmatch 'test result: ok\. 7 passed; 0 failed'){throw 'Packaged identity tests incomplete'}
 $extension=if($platform -eq 'windows'){'.exe'}else{''}
 foreach($pair in @(@('novovm-node',$v.node_sha256),@('novovm-native-client',$v.client_sha256),@('novovmctl',$v.ctl_sha256))){if((Get-FileHash "$root/bin/$($pair[0])$extension").Hash.ToLowerInvariant() -cne $pair[1]){throw 'Packaged executable changed'}}
 $members=@(Get-ChildItem $root -File -Recurse|ForEach-Object {
  if($_.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Redirected package member'}
  [ordered]@{name=[IO.Path]::GetRelativePath($root,$_.FullName).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}
 })
 $checksum="$root/aoem/$platform/CHECKSUMS.sha256"
 $checked=0
 foreach($line in Get-Content $checksum){
  if(!$line.Trim()){continue}
  if($line -notmatch '^([a-fA-F0-9]{64})\s+\*?(.+)$'){throw 'Invalid inherited AOEM checksum'}
  $hash=$Matches[1].ToLowerInvariant();$relative=$Matches[2]
  $base=[IO.Path]::GetFullPath("$root/aoem/$platform")
  $path=[IO.Path]::GetFullPath((Join-Path $base $relative))
  if(!$path.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or (Get-FileHash $path).Hash.ToLowerInvariant() -cne $hash){throw 'Inherited AOEM file differs'}
  $checked++
 }
 $archive=if($platform -eq 'windows'){"$delivery/$name.zip"}else{"$delivery/$name.tar.gz"}
 if($platform -eq 'windows'){
  $z=[IO.Compression.ZipFile]::OpenRead($archive)
  try{
   $entries=@($z.Entries|Where-Object {$_.Name})
   if($entries.Count -ne $members.Count -or @($entries.FullName|Sort-Object -Unique).Count -ne $entries.Count){throw 'ZIP member set differs'}
   foreach($m in $members){
    $entry=@($entries|Where-Object {$_.FullName.Replace('\','/') -ceq "$name/$($m.name)"})
    if($entry.Count -ne 1 -or $entry[0].Length -ne $m.bytes){throw 'ZIP member missing or size differs'}
    $stream=$entry[0].Open()
    try{$digest=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
    if($digest -cne $m.sha256){throw 'ZIP bytes differ from qualified member'}
   }
  }finally{$z.Dispose()}
 }else{
  & wsl -d Ubuntu-24.04 -- tar -df "/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111/$name.tar.gz" -C /mnt/d/WorksArea/SUPERVM/artifacts/product-overlay
  if($LASTEXITCODE -ne 0){throw 'Linux tar content differs'}
  $names=@(& wsl -d Ubuntu-24.04 -- tar -tzf "/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111/$name.tar.gz")
  if($LASTEXITCODE -ne 0){throw 'Cannot list Linux archive'}
  $files=@($names|Where-Object {!$_.EndsWith('/')})
  if($files.Count -ne $members.Count -or @($files|Sort-Object -Unique).Count -ne $files.Count){throw 'Linux tar member count differs'}
  foreach($m in $members){if("$name/$($m.name)" -cnotin $files){throw 'Linux tar member set differs'}}
 }
 $packages += [ordered]@{platform=$platform;source_commit=$Source;source_equivalence=$q.source_equivalence;archive=[IO.Path]::GetFileName($archive);archive_bytes=(Get-Item $archive).Length;archive_sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();manifest_sha256=$v.manifest_sha256;manifest_members=$v.artifacts_verified;total_files=$members.Count;node_sha256=$v.node_sha256;client_sha256=$v.client_sha256;ctl_sha256=$v.ctl_sha256;aoem_sha256=$q.aoem_sha256;aoem_manifest_sha256=(Get-FileHash "$root/aoem/manifest/aoem-manifest.json").Hash.ToLowerInvariant();inherited_aoem_checksum=@{path="aoem/$platform/CHECKSUMS.sha256";entries_verified=$checked;sha256=(Get-FileHash $checksum).Hash.ToLowerInvariant()};package_identity_tests=7;qualification=$q.results;members=$members;deployed=$false}
}
New-Item -ItemType Directory -Path $out -Force|Out-Null
[ordered]@{source_commit=$Source;recorded_utc=[DateTime]::UtcNow.ToString('o');packages=$packages;both_platforms_qualified=(!$OnlyPlatform);full_ci_qualified=$false;deployed=$false;real_relay_accepted=$false;scope='Actual fixed packages and local original-owner gates; independent archive member and AOEM checksum checks. Not cloud or real-machine acceptance.'}|ConvertTo-Json -Depth 15|Out-File "$out/$outputName" -NoClobber -Encoding utf8
$packages|ForEach-Object {[pscustomobject]$_}|Select-Object platform,archive,archive_bytes,archive_sha256,node_sha256|Format-List
