param([Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{40}$')][string]$Source,[switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$short=$Source.Substring(0,8)
$platform=if($Linux){'linux'}else{'windows'}
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$delivery=if($Linux){"/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111"}else{"C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111"}
$v=Get-Content "$delivery/verified-$platform.json" -Raw|ConvertFrom-Json
$extension=if($Linux){''}else{'.exe'}
$ctl="$repo/artifacts/product-overlay/novonet-observation-$short-$platform-x86_64/bin/novovmctl$extension"
if($v.source_commit -cne $source -or (Get-FileHash $ctl).Hash.ToLowerInvariant() -cne $v.ctl_sha256){throw 'Fixed packaged CLI differs'}
$out=Join-Path $delivery "relay-commands-$platform"
if(Test-Path $out){throw 'Preserve prior package command evidence'}
New-Item -ItemType Directory -Path $out|Out-Null
$commands=@(
    @{name='arm';args=@('prepare','--sender',('11'*32),'--recipient',('22'*32),'--via',('33'*32),'--nonce',('44'*32),'--output',"$out/arm.nvprobe")},
    @{name='send';args=@('send-relay','--from',"$out/arm.nvprobe",'--output',"$out/send.nvprobe")},
    @{name='cancel';args=@('cancel','--from',"$out/arm.nvprobe",'--output',"$out/cancel.nvprobe")}
)
$results=@()
foreach($item in $commands){
    $argsList=$item.args
    & $ctl native-network-probe @argsList 1> "$out/$($item.name).json" 2> "$out/$($item.name).stderr"
    $exit=$LASTEXITCODE
    if($exit -ne 0){throw "Packaged $($item.name) failed"}
    $p=Get-Content "$out/$($item.name).json" -Raw|ConvertFrom-Json
    if(!$p.ok -or $p.data.bytes -ne 409 -or $p.data.sent -or $p.data.object_done -or $p.data.business_receipt -or $p.data.node_started -or $p.data.relay.Count -ne 32 -or @($p.data.relay|Where-Object {$_ -ne 51}).Count){throw 'Wrong bounded local relay command semantics'}
    if((Get-Item "$out/$($item.name).nvprobe").Length -ne 409){throw 'Wrong encoded relay command length'}
    $results+=@{command=$item.name;exit_code=$exit;bytes=409;sha256=(Get-FileHash "$out/$($item.name).nvprobe").Hash.ToLowerInvariant()}
}
$send=Get-Content "$out/send.json" -Raw|ConvertFrom-Json
if($send.data.expires_at_ms-$send.data.issued_at_ms -ne 10000){throw 'Original probe lifetime changed'}
[ordered]@{source=$source;platform=$platform;ctl_sha256=$v.ctl_sha256;results=$results;scope='actual packaged CLI, local files only; not a running node or real network';node_changed=$false}|ConvertTo-Json -Depth 8|Set-Content "$out/result.json" -Encoding utf8
Write-Output "PASS packaged relay arm/send/cancel $platform; no object sent"
