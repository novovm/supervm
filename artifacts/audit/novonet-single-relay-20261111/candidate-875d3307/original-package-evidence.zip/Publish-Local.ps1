param([Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{40}$')][string]$Source)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:/WorksArea/SUPERVM';$short=$Source.Substring(0,8)
$delivery="C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111"
$tools="$delivery/update-tools";$out="$repo/artifacts/audit/novonet-single-relay-20261111/candidate-$short"
if(!(Test-Path "$out/candidate-manifest.json")){throw 'Both independent package checks required'}
foreach($file in @('updater-windows-tests.log','updater-linux-tests.log')){if(Test-Path "$delivery/$file"){throw 'Preserve original validation output'}}
& 'C:/Program Files/PowerShell/7/pwsh.exe' -NoProfile -File "$tools/Test-Update-Windows.ps1" -PackageRoot "$repo/artifacts/product-overlay/novonet-observation-$short-windows-x86_64" *>&1|Tee-Object "$delivery/updater-windows-tests.log"
if($LASTEXITCODE -ne 0){throw 'Original Windows updater gates failed'}
& wsl -d Ubuntu-24.04 -- python3 "/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261111/update-tools/test_update_b.py" *>&1|Tee-Object "$delivery/updater-linux-tests.log"
if($LASTEXITCODE -ne 0){throw 'Original Linux updater gates failed'}
$names=@('Update-Windows.ps1','Test-Update-Windows.ps1','NovonetExistingProcess.ps1','Update-B.py','test_update_b.py')
$bundle="$out/existing-update-tools-$short.zip"
if(Test-Path $bundle){throw 'Preserve pinned tools'}
Compress-Archive -LiteralPath @($names|ForEach-Object {Join-Path $tools $_}) -DestinationPath $bundle
[ordered]@{source=$Source;tool_archive=[IO.Path]::GetFileName($bundle);tool_archive_sha256=(Get-FileHash $bundle).Hash.ToLowerInvariant();tool_archive_bytes=(Get-Item $bundle).Length;files=@($names|ForEach-Object {@{name=$_;sha256=(Get-FileHash (Join-Path $tools $_)).Hash.ToLowerInvariant()}});windows_reported_pass_groups=@(Select-String '^PASS ' "$delivery/updater-windows-tests.log").Count;linux_tests=13;scope='Original updater offline gates and actual fixed Windows package; no node changed. First interactive wrapper expanded ErrorActionPreference in its parent, producing Continue=Stop before the same test script; these retained direct-File logs avoid that launcher error.'}|ConvertTo-Json -Depth 8|Out-File "$out/update-tools-manifest.json" -NoClobber -Encoding utf8
$files=@(Get-ChildItem $delivery -File|Where-Object {$_.Extension -in @('.log','.json')})
$files+=@(Get-Item "$PSScriptRoot/Candidate.ps1","$PSScriptRoot/Prepare-Update.ps1","$PSScriptRoot/Freeze-Candidate.ps1","$PSScriptRoot/Publish-Local.ps1","$PSScriptRoot/Check-Packaged-Relay-Commands.ps1","$PSScriptRoot/Send-A-C-D.ps1")
$evidence="$out/original-package-evidence.zip"
if(Test-Path $evidence){throw 'Preserve package evidence'}
$z=[IO.Compression.ZipFile]::Open($evidence,[IO.Compression.ZipArchiveMode]::Create)
try{
 foreach($f in $files){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,$f.FullName,$f.Name,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
 foreach($platform in @('windows','linux')){
  foreach($f in Get-ChildItem "$delivery/relay-commands-$platform" -File){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,$f.FullName,"relay-commands-$platform/$($f.Name)",[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
 }
}finally{$z.Dispose()}
$z=[IO.Compression.ZipFile]::OpenRead($evidence)
try{
 $members=@($z.Entries|ForEach-Object {$s=$_.Open();try{@{name=$_.FullName;bytes=$_.Length;sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($s)).ToLowerInvariant()}}finally{$s.Dispose()}})
 if(@($members.name|Sort-Object -Unique).Count -ne $members.Count){throw 'Duplicate evidence member'}
}finally{$z.Dispose()}
[ordered]@{source=$Source;archive=[IO.Path]::GetFileName($evidence);sha256=(Get-FileHash $evidence).Hash.ToLowerInvariant();members=$members;scope='Package build, qualification, local CLI commands and original updater logs; no real-node state, private keys, database or journal included'}|ConvertTo-Json -Depth 8|Out-File "$out/package-evidence-manifest.json" -NoClobber -Encoding utf8
Write-Output 'PASS local package and original updater evidence archived; not deployed'
