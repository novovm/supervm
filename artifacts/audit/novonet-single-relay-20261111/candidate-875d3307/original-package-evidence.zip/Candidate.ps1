param(
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{40}$')][string]$Source,
 [Parameter(Mandatory)][ValidateSet('Build','Verify','Qualify','Archive','Owner')][string]$Phase,
 [switch]$Linux
)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
if($Phase -ne 'Owner'){
 $script=Get-Content "$repo/target/openssl-security-20261110/Candidate.ps1" -Raw
 if(!$script.Contains('$deliveryName="candidate-observation-$short-20261110"')){throw 'Original candidate wrapper changed'}
 $script=$script.Replace('$deliveryName="candidate-observation-$short-20261110"','$deliveryName="candidate-observation-$short-20261111"')
 & ([scriptblock]::Create($script)) -Source $Source -Phase $Phase -Linux:$Linux
}else{
 $archive=[IO.Compression.ZipFile]::OpenRead("$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/original-package-evidence.zip")
 try{$reader=[IO.StreamReader]::new($archive.GetEntry('Qualify-Fixed-Package.ps1').Open());try{$script=$reader.ReadToEnd()}finally{$reader.Dispose()}}finally{$archive.Dispose()}
 if(!$script.Contains('1ef3189307382ef579775c7ce2b55a08d829d04a') -or !$script.Contains("count=15;ignored=`$false")){throw 'Original owner qualifier changed'}
 $script=$script.Replace('1ef3189307382ef579775c7ce2b55a08d829d04a',$Source).Replace('1ef31893',$Source.Substring(0,8))
 $script=$script.Replace("candidate-observation-$($Source.Substring(0,8))-20261110","candidate-observation-$($Source.Substring(0,8))-20261111")
 # Original15 tests plus five diagnostic boundary/real-hop regressions.
 $script=$script.Replace("count=15;ignored=`$false","count=20;ignored=`$false")
 $script=$script.Replace('target/openssl-security-20261110/Candidate.ps1','target/relay-constraint-20261111/Candidate.ps1')
 # A reviewed docs-only descendant may qualify the unchanged fixed program.
 # Retain clean-tree/ancestor/source equality checks; record both SHAs explicitly.
 $guard=@'
function Assert-FixedProgramSource {
 if(@(git status --porcelain).Count){throw 'Clean qualification checkout required'}
 $head=(git rev-parse HEAD).Trim()
 & git merge-base --is-ancestor $source $head
 if($LASTEXITCODE -ne 0){throw 'Program source is not an ancestor'}
 $allowed=@(
 'docs/NOVORUDP_SHARED_CLIENT_HANDOFF.md',
 'docs/NOVONET_UCA_PQ_IMPLEMENTATION_HANDOFF_2026-10-24.md',
 'artifacts/audit/novonet-single-relay-20261111/README.md',
 'artifacts/audit/novonet-single-relay-20261111/local-pacing-security-evidence.json',
 'artifacts/audit/novonet-single-relay-20261111/local-pacing-security-evidence.zip'
 )
 $changed=@(git diff --name-only $source $head)
 if($LASTEXITCODE -ne 0 -or @($changed|Where-Object {$_ -cnotin $allowed}).Count){throw 'Unreviewed program or qualifier change since fixed source'}
 return @{program_source=$source;qualification_head=$head;reviewed_nonprogram_paths=$changed}
}
$sourceEquivalence=Assert-FixedProgramSource
'@
 $before="if((git rev-parse HEAD).Trim() -cne `$source -or @(git status --porcelain).Count){throw 'Frozen clean source required'}"
 $after="if((git rev-parse HEAD).Trim() -cne `$source -or @(git status --porcelain).Count){throw 'Source changed during qualification'}"
 if(!$script.Contains($before) -or !$script.Contains($after)){throw 'Original source guards changed'}
 $script=$script.Replace($before,$guard)
 $script=$script.Replace($after, @'
$finalEquivalence=Assert-FixedProgramSource
if($finalEquivalence.qualification_head -cne $sourceEquivalence.qualification_head){throw 'Checkout changed during qualification'}
'@)
 $script=$script.Replace('@{source_commit=$source;harness=', '@{source_commit=$source;source_equivalence=$sourceEquivalence;harness=')
 & ([scriptblock]::Create($script)) -Linux:$Linux
}
