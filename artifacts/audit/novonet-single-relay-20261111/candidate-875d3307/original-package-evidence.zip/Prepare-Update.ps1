# Derive the original existing updater; this prepares tools only, never starts nodes.
param([Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{40}$')][string]$Source,[string]$OutputDirectory)
$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$script=Get-Content "$repo/target/native-time-upgrade-20261110/Prepare-Update.ps1" -Raw
$oldManifest='artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/candidate-manifest.json'
if(!$script.Contains($oldManifest) -or !$script.Contains("foreach(`$name in @('Read-Status.ps1','Prepare-OperatorRule.ps1','Check-Full.ps1'))")){throw 'Original generator changed'}
# First move only the new version, then update the old version from actual8fed pins.
$short=$Source.Substring(0,8)
$script=$script.Replace('8fed4b76f518935b30fcfb13930ccd3d7aae7381',$Source).Replace('8fed4b76',$short)
$script=$script.Replace("$short-20261110","$short-20261111")
$script=$script.Replace($oldManifest,'artifacts/audit/novonet-native-session-clock-20261110/candidate-8fed4b76/candidate-manifest.json')
$script=$script.Replace('1ef31893','8fed4b76').Replace('original 1ef','original 8fed').Replace('verified 1ef','verified 8fed').Replace('for 1ef -> 8fed',"for 8fed -> $short")
# Source templates use dates separately from version literals; update NEW targets only.
$marker="function Adapt-Windows([string]`$Text){`r`n"
if(!$script.Contains($marker)){$marker="function Adapt-Windows([string]`$Text){`n"}
if(!$script.Contains($marker)){throw 'Original Windows adapter missing'}
$script=$script.Replace($marker,$marker+"    `$Text=`$Text.Replace('3fa11f94-20261110','3fa11f94-20261111').Replace('3fa11f94-Existing-20261110','3fa11f94-Existing-20261111').Replace('3fa11f94-Existing-Rollback-20261110','3fa11f94-Existing-Rollback-20261111').Replace('3fa11f94-`$HostId-20261110','3fa11f94-`$HostId-20261111')`n")
$marker="`$linux=Get-Content `"`$repo/scripts/linux/update-novonet-existing.py`" -Raw"
if(!$script.Contains($marker)){throw 'Original Linux adapter missing'}
$script=$script.Replace($marker,$marker+"`n`$linux=`$linux.Replace('3fa11f94-20261110','3fa11f94-20261111').Replace('3fa11f94-network-20261110','3fa11f94-network-20261111').Replace('3fa11f94-existing-rollback-20261110','3fa11f94-existing-rollback-20261111')")
# Historical status/full scripts pin an unrelated candidate; do not copy them.
$script=$script.Replace("foreach(`$name in @('Read-Status.ps1','Prepare-OperatorRule.ps1','Check-Full.ps1'))","foreach(`$name in @())")
& ([scriptblock]::Create($script)) -OutputDirectory $OutputDirectory
