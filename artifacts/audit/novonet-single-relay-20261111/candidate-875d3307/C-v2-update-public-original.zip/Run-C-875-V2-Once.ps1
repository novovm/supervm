#Requires -Version 7.0
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference=$false
$work='D:\WEB3_AI\SUPERVM\target\c-875-v2-recovery-20261111T113132Z'
$paths=Get-Content -LiteralPath (Join-Path $work 'paths.json') -Raw | ConvertFrom-Json
$pwsh='C:\Program Files\PowerShell\7\pwsh.exe'
function New-Json([string]$path,$value) {
    $data=[Text.UTF8Encoding]::new($false).GetBytes(($value | ConvertTo-Json -Depth 30))
    $f=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $f.Write($data,0,$data.Length);$f.Flush($true) } finally {$f.Dispose()}
}
$principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {throw 'Administrator PowerShell 7 required'}
if ($paths.package_pending -or $paths.host -cne 'C') {throw 'C fixed package not prepared'}
$script=Join-Path $paths.tools 'Update-Windows.ps1'
if ((Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash.ToLowerInvariant() -cne 'f7c185500abd955089c92b8bd0edefb3cf20a20df65bfbfe53c1c9c0bcd55cb2') {throw 'Original updater hash differs'}
if (Test-Path -LiteralPath $paths.evidence) {throw 'Update evidence exists; do not rerun'}
$public=Join-Path $work 'public'
if (Test-Path -LiteralPath $public) {throw 'Public evidence exists; do not rerun'}
New-Item -ItemType Directory -Path $public | Out-Null
New-Json (Join-Path $work 'invoked-once.json') ([ordered]@{host='C';started_utc=[DateTime]::UtcNow.ToString('o');command='Update-Windows.ps1 -HostId C -PackageRoot <verified fixed package> -EvidenceRoot <fresh evidence> -RecoverCrashed';switches=@('RecoverCrashed');start='existing';initialize_requested=$false;collector_started=$false})
$code=1;$errorText=$null;$projected=$false
try {
    & $pwsh -NoProfile -NonInteractive -File $script -HostId C -PackageRoot $paths.package_root -EvidenceRoot $paths.evidence -RecoverCrashed 1> (Join-Path $public 'update.stdout.log') 2> (Join-Path $public 'update.stderr.log')
    $code=$LASTEXITCODE
    foreach($name in @('result.json','error.json','old-exit.json','firewall.json','rollback-requested.json','recovery-stopped.json','crash-recovery-preflight.json')) {
        $source=Join-Path $paths.evidence $name
        if (Test-Path -LiteralPath $source) { Copy-Item -LiteralPath $source -Destination (Join-Path $public $name) }
    }
    $after=Join-Path $paths.evidence 'after.json'
    if (Test-Path -LiteralPath $after) {
        $a=Get-Content -LiteralPath $after -Raw | ConvertFrom-Json
        $probe=$a.progress.native_network_probe
        $fields=@($probe.transport.psobject.Properties.Name)
        New-Json (Join-Path $public 'after-public.json') ([ordered]@{
            host_id=$a.host_id;source=$a.source;time=$a.time;pid=$a.pid;exe=$a.exe;node_sha256=$a.node_sha256;sid=$a.sid;database=$a.database;start=$a.start
            initialize_executed=$a.initialize_executed;keys_generated=$a.keys_generated;custody_unchanged=$a.custody_unchanged
            aoem_module=$a.aoem_module;aoem_sha256=$a.aoem_sha256;old_task=$a.old_task;new_task=$a.new_task;listeners=$a.listeners
            entry=$a.progress.entry;chain_id=$a.progress.chain_id;current_height=$a.progress.current_height;head=$a.progress.head
            execution_failures=$a.progress.execution_failures;recovery_in_progress=$a.progress.recovery_in_progress
            probe_enabled=$probe.enabled;udp_recovery_event_names_count=@($probe.transport.udp_recovery_event_names).Count
            relay_observation_available=(($fields -contains 'relay_circuits') -and ($fields -contains 'relay_evicted_records') -and ($fields -contains 'relay_omitted_observations'))
            new_command_file_present=$a.new_command_file_present;collector_started=$false;authenticated_status_by_A_pending=$true
        })
        $projected=$true
    }
} catch { $errorText=$_.ToString() }
$label=$null
if ($code -eq 0 -and $projected -and $null -eq $errorText) {$label='C_875_EXISTING_READY_FOR_A_QUERY'}
New-Json (Join-Path $public 'controller-exit.json') ([ordered]@{host='C';finished_utc=[DateTime]::UtcNow.ToString('o');updater_exit_code=$code;public_projection_completed=$projected;wrapper_error=$errorText;status=$label;updater_invocations=1;collector_started=$false;new_object_sent=$false})
if ($null -ne $errorText) {exit 2}
exit $code