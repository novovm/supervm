import json
import subprocess
from pathlib import Path
from datetime import datetime, timezone
base = Path('/var/lib/novovm/selfrun/91129655606029/B/novonet-observation-8fed4b76-20261110')
p = json.loads((base / 'logs-continuous-resume/progress.json').read_text())
unit = 'novovm-B-8fed4b76-network-20261110-continuous.service'
pid = int(subprocess.check_output(['systemctl', 'show', unit, '-p', 'MainPID', '--value']))
env = Path(f'/proc/{pid}/environ').read_bytes().split(b'\0')
result = {'utc': datetime.now(timezone.utc).isoformat(), 'chain_id': p['chain_id'],
          'execution_failures': p['execution_failures'], 'novonet': p.get('novonet'),
          'pid': pid, 'process_deadline_env_present': any(v.startswith(b'NOVOVM_NATIVE_EXECUTION_RUN_MS=') for v in env),
          'unit': subprocess.check_output(['systemctl', 'show', unit, '-p', 'MainPID,ActiveState,SubState,RuntimeMaxUSec']).decode()}
print(json.dumps(result, indent=2))
