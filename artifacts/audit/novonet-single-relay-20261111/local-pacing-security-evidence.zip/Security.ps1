$ErrorActionPreference='Stop'
Set-Location D:/WorksArea/SUPERVM
$root='target/relay-constraint-20261111'
$log="$root/full-42961080141-security.log"
if(!(Test-Path $log)){
 & gh api repos/novovm/supervm/actions/jobs/130327715687/logs | Set-Content $log -Encoding utf8
 if($LASTEXITCODE -ne 0){throw 'CI log read failed'}
}
foreach($id in @('0474','0476','0477')){
 $path="$root/RUSTSEC-2026-$id.md"
 if(!(Test-Path $path)){
  $response=& gh api "repos/RustSec/advisory-db/contents/crates/openssl/RUSTSEC-2026-$id.md" | ConvertFrom-Json
  if($LASTEXITCODE -ne 0){throw 'Advisory read failed'}
  [IO.File]::WriteAllBytes((Join-Path (Get-Location) $path),[Convert]::FromBase64String($response.content))
 }
 Get-Content $path
}
& cargo tree --locked --target x86_64-unknown-linux-gnu -i openssl 2>&1 | Tee-Object "$root/openssl-before-tree.log"
if($LASTEXITCODE -ne 0){throw 'Tree failed'}
& cargo update -p openssl --precise 0.10.80 2>&1 | Tee-Object "$root/openssl-update.log"
if($LASTEXITCODE -ne 0){throw 'Update failed'}
& git diff -- Cargo.lock
