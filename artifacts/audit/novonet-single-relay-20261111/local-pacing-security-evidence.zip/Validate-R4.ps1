param([switch]$Linux)
$ErrorActionPreference='Stop'
foreach($phase in @('owner','nodeclippy')){
    & "$PSScriptRoot/Validate.ps1" -Linux:$Linux -Label r4b -Phase $phase
    if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
}
