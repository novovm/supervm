param([switch]$FetchedDatabase)
$ErrorActionPreference='Stop'
Set-Location D:/WorksArea/SUPERVM
$root='target/relay-constraint-20261111'
$checks=@(
 ,@('audit','--json')
 ,@('audit','--file','runtime/Cargo.lock','--json')
 ,@('deny','check','advisories','bans','licenses','sources')
 ,@('deny','--manifest-path','runtime/Cargo.toml','check','advisories','bans','licenses','sources')
)
for($i=0;$i -lt $checks.Count;$i++){
 if($FetchedDatabase -and $i -lt 2){$checks[$i]+= '--no-fetch'}
 $label=if($FetchedDatabase){'same-db'}else{'fixed'}
 $log="$root/security-$label-$i.log"
 if(Test-Path $log){throw 'Refuse overwrite'}
 & cargo @($checks[$i]) 2>&1 | Tee-Object $log
 $code=$LASTEXITCODE
 [ordered]@{arguments=$checks[$i];exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json" -Encoding utf8
 if($code -ne 0){exit $code}
}
