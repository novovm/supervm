param([switch]$Linux,[string]$Label='final',[ValidateSet('targeted','regressions','clippy','build','owner','nodeclippy')][string]$Phase='targeted')
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
Set-Location $repo
$platform=if($Linux){'linux'}else{'windows'}
$env:CARGO_TARGET_DIR=if($Linux){'/home/aoem-a1/novovm-build-b-20261102'}else{'C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'}
$env:CARGO_BUILD_JOBS='2'
$pkg="$repo/artifacts/product-overlay/novonet-observation-e7b0cca7-$platform-x86_64"
$env:NOVOVM_AOEM_TEST_LIBRARY=if($Linux){"$pkg/aoem/linux/core/bin/libaoem_ffi.so"}else{"$pkg/aoem/windows/core/bin/aoem_ffi.dll"}
$env:AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$checks=@(switch($Phase){
 'owner' {,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::','--','--test-threads=1','--nocapture')}
 'nodeclippy' {,@('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings')}
 'targeted' {,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::diagnostic','--','--test-threads=1','--nocapture'); ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::tests::diagnostic','--','--test-threads=1','--nocapture')}
 'regressions' {,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','service::network::','--','--test-threads=1','--nocapture'); ,@('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','native_lifecycle::probe::','--','--include-ignored','--test-threads=1','--nocapture'); ,@('test','--release','--locked','-p','novovm-network','--lib','--features','iroh-transport','relay::hop::','--','--test-threads=1','--nocapture'); ,@('test','--release','--locked','-p','novovmctl','native_network_probe','--','--test-threads=1','--nocapture')}
 'clippy' {,@('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings'); ,@('clippy','--release','--locked','-p','novovmctl','--bin','novovmctl','--','-D','warnings'); ,@('clippy','--release','--locked','-p','novovm-network','--lib','--tests','--features','iroh-transport','--','-D','warnings')}
 'build' {,@('build','--release','--locked','-p','novovm-node','--bin','novovm-node','--bin','novovm-native-client','--features','iroh-transport'); ,@('build','--release','--locked','-p','novovmctl','--bin','novovmctl')}
})
$index=0
foreach($arguments in $checks){
 $log="$repo/target/relay-constraint-20261111/$platform-$Label-$Phase-$index.log"
 if(Test-Path -LiteralPath $log){throw "Evidence already exists: $log"}
 & cargo @arguments 2>&1 | Tee-Object -FilePath $log
 $code=$LASTEXITCODE
 [ordered]@{platform=$platform;phase=$Phase;arguments=$arguments;exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json" -Encoding utf8
 if($code -ne 0){exit $code}
 $index++
}
