$ErrorActionPreference='Stop'
$repo='/mnt/d/WorksArea/SUPERVM'
& "$repo/target/relay-constraint-20261111/Validate.ps1" -Linux -Label r5 -Phase regressions
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& "$repo/target/relay-constraint-20261111/Validate.ps1" -Linux -Label r5 -Phase clippy
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$log="$repo/target/relay-constraint-20261111/linux-r5-rollout.log"
if(Test-Path $log){throw 'Refuse overwrite'}
& cargo test --release --locked -p novovm-rollout-policy -- --test-threads=1 2>&1 | Tee-Object $log
$code=$LASTEXITCODE
@{exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json"
exit $code
