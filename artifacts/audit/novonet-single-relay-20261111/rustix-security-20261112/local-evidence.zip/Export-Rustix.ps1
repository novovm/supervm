$ErrorActionPreference='Stop'
Set-Location D:/WorksArea/SUPERVM
$root='target/double-relay-20261112/rustix-patch'
$out='artifacts/audit/novonet-single-relay-20261111/rustix-security-20261112'
if(Test-Path $out){throw 'Preserve exported evidence'}
$checks=@()
foreach($platform in @('windows','linux')){
 foreach($i in 0..6){
  $log="$root/$platform-regression-$i.log"
  $r=Get-Content "$log.result.json" -Raw|ConvertFrom-Json
  if($r.exit_code -ne 0){throw 'Regression failed'}
  $passed=$null
  if($i -lt 3){
   $expected=if($platform -eq 'linux'){@(7,3,10)[$i]}else{@(7,3,12)[$i]}
   if((Get-Content $log -Raw) -notmatch "test result: ok\. $expected passed; 0 failed; 0 ignored;"){throw 'Actual test count differs'}
   $passed=$expected
  }
  $checks += [ordered]@{log=[IO.Path]::GetFileName($log);arguments=$r.arguments;exit_code=$r.exit_code;passed=$passed;utc=$r.utc}
 }
}
foreach($i in 0..3){
 $log="$root/windows-security-proxy-$i.log"
 $r=Get-Content "$log.result.json" -Raw|ConvertFrom-Json
 if($r.exit_code -ne 0){throw 'Security failed'}
 $checks += [ordered]@{log=[IO.Path]::GetFileName($log);arguments=$r.arguments;exit_code=$r.exit_code;utc=$r.utc}
}
New-Item -ItemType Directory $out | Out-Null
$files=@(Get-ChildItem $root -File)+@(Get-Item target/double-relay-20261112/Validate-Rustix.ps1,target/double-relay-20261112/Export-Rustix.ps1)+@(Get-ChildItem target/double-relay-20261112 -Filter 'security-fixed-*')
Compress-Archive -LiteralPath $files.FullName -DestinationPath "$out/local-evidence.zip"
$source=@('Cargo.lock','crates/novovm-network/Cargo.toml')|ForEach-Object{[ordered]@{path=$_;sha256=(Get-FileHash $_).Hash.ToLowerInvariant()}}
[ordered]@{base=(git rev-parse HEAD);source_hashes=@($source);advisory='RUSTSEC-2026-0486';rustix='1.1.6';runtime_lock_changed=$false;checks=$checks;raw_files=@($files|ForEach-Object{[ordered]@{name=$_.Name;bytes=$_.Length;sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}});archive_sha256=(Get-FileHash "$out/local-evidence.zip").Hash.ToLowerInvariant();deployed=$false;full_ci_qualified=$false;real_double_relay_qualified=$false}|ConvertTo-Json -Depth 12|Set-Content "$out/results.json"
