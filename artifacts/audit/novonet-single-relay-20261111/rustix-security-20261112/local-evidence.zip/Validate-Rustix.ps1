param([switch]$Linux,[switch]$Security,[string]$Label='')
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
Set-Location $repo
$platform=if($Linux){'linux'}else{'windows'}
$root="$repo/target/double-relay-20261112/rustix-patch"
New-Item -ItemType Directory -Force $root | Out-Null
$env:CARGO_TARGET_DIR=if($Linux){'/home/aoem-a1/novovm-build-b-20261102'}else{'C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'}
$env:CARGO_BUILD_JOBS='2'
if($Linux){$env:PATH="/home/aoem-a1/.cargo/bin:$env:PATH"}
$checks=if($Security){@(
 ,@('audit','--json')
 ,@('audit','--file','runtime/Cargo.lock','--json')
 ,@('deny','check','advisories','bans','licenses','sources')
 ,@('deny','--manifest-path','runtime/Cargo.toml','check','advisories','bans','licenses','sources')
)}else{@(
 ,@('test','--release','--locked','-p','novovm-network','--lib','--features','iroh-transport','product_service_file::tests::','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-network','--lib','--features','iroh-transport','relay::hop::tests','--','--test-threads=1','--nocapture')
 ,@('test','--release','--locked','-p','novovm-storage-budget','--lib','--','--test-threads=1','--nocapture')
 ,@('clippy','--release','--locked','-p','novovm-network','--lib','--tests','--features','iroh-transport','--','-D','warnings')
 ,@('clippy','--release','--locked','-p','novovm-storage-budget','--lib','--tests','--','-D','warnings')
 ,@('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings')
 ,@('clippy','--release','--locked','-p','novovmctl','--bin','novovmctl','--','-D','warnings')
)}
$index=0
foreach($arguments in $checks){
 $kind=if($Security){'security'}else{'regression'}
 $log="$root/$platform-$kind$Label-$index.log"
 if(Test-Path $log){throw "Preserve previous evidence: $log"}
 & cargo @arguments 2>&1 | Tee-Object -FilePath $log
 $code=$LASTEXITCODE
 [ordered]@{arguments=$arguments;exit_code=$code;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content "$log.result.json"
 if($code -ne 0){exit $code}
 if(!$Security -and $index -lt 3 -and (Get-Content $log -Raw) -notmatch 'test result: ok\. [1-9][0-9]* passed; 0 failed;'){throw 'No executed passing tests'}
 $index++
}
