#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export PATH=/home/aoem-a1/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export RUSTUP_TOOLCHAIN=1.94.0 CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102 CARGO_BUILD_JOBS=3 LIBCLANG_PATH=/usr/lib/llvm-18/lib
runuser -u aoem-a1 -- env PATH="$PATH" RUSTUP_TOOLCHAIN="$RUSTUP_TOOLCHAIN" CARGO_TARGET_DIR="$CARGO_TARGET_DIR" CARGO_BUILD_JOBS="$CARGO_BUILD_JOBS" LIBCLANG_PATH="$LIBCLANG_PATH" cargo test --target x86_64-unknown-linux-gnu -p novovm-node --test native_candidate_node_cli --locked --no-run --message-format=json > target/continuous-handoff-build-20261105.jsonl
binary=$(python3 -c 'import json; print(next(m["executable"] for line in open("target/continuous-handoff-build-20261105.jsonl") if (m:=json.loads(line)).get("reason")=="compiler-artifact" and m["target"]["name"]=="native_candidate_node_cli" and m["profile"]["test"]))')
library=/home/aoem-a1/novovm-ci-runtime-20261103.iOetRI/linux/libaoem_ffi.so
manifest=/home/aoem-a1/novovm-ci-runtime-20261103.iOetRI/manifest.json
test -x "$binary" && test -f "$library" && test -f "$manifest"
unshare --net sh -c 'ip link set lo up; exec taskset -c 0,1 env NOVOVM_NATIVE_FRESH_HANDOFF_TRACE=1 NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=1 NOVOVM_AOEM_TEST_LIBRARY="$2" NOVOVM_AOEM_DLL="$2" NOVOVM_AOEM_TEST_MANIFEST="$3" NOVOVM_AOEM_MANIFEST="$3" AOEM_DLL_MANIFEST="$3" AOEM_DLL_MANIFEST_REQUIRED=1 "$1" fresh_genesis_main_nodes_continue_three_heights_without_restart --ignored --test-threads=1 --nocapture' fresh-process-gate "$binary" "$library" "$manifest"
