#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export PATH=/home/aoem-a1/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export RUSTUP_TOOLCHAIN=1.94.0 CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102 CARGO_BUILD_JOBS=3 LIBCLANG_PATH=/usr/lib/llvm-18/lib
cargo test --target x86_64-unknown-linux-gnu -p novovm-node --lib fresh_timing --locked -- --test-threads=1
NOVOVM_NATIVE_FRESH_HANDOFF_TRACE=1 cargo test --target x86_64-unknown-linux-gnu -p novovm-node --lib fresh_handoff_trace --locked -- --test-threads=1
cargo clippy --target x86_64-unknown-linux-gnu -p novovm-node --lib --test native_candidate_node_cli --locked -- -D warnings
