#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=1
export NOVOVM_AOEM_TEST_LIBRARY=/mnt/d/WorksArea/SUPERVM/artifacts/runtime-candidates/native-transport-mldsa65-20261103/linux/libaoem_ffi.so
export NOVOVM_AOEM_DLL="$NOVOVM_AOEM_TEST_LIBRARY"
export NOVOVM_AOEM_TEST_MANIFEST=/mnt/d/WorksArea/SUPERVM/artifacts/runtime-candidates/native-transport-mldsa65-20261103/manifest.json
export NOVOVM_AOEM_MANIFEST="$NOVOVM_AOEM_TEST_MANIFEST"
export AOEM_DLL_MANIFEST="$NOVOVM_AOEM_TEST_MANIFEST"
export AOEM_DLL_MANIFEST_REQUIRED=1
ip link set lo up
if [ "$#" -ge 3 ]; then export NOVOVM_TRANSFER_PARITY_WORKER="$3"; fi
exec taskset -c 0,1 "$1" "${2:-native_seal_main_process::fresh_genesis_main_nodes_continue_three_heights_without_restart}" --exact --ignored --test-threads=1 --nocapture
