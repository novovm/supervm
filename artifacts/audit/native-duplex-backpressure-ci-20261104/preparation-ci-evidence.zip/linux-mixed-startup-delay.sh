#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
node_pid=''
trap 'if [ -n "$node_pid" ]; then kill -CONT "$node_pid" 2>/dev/null || true; fi' EXIT
bash target/native-duplex-backpressure-ci-20261104/linux-continuous-run.sh "$1" native_seal_main_process::fresh_record_transfers_conflict_failure_serial_parity "$2" > "$3" 2>&1 &
parent=$!
until_at=$((SECONDS + 120))
while :; do
  mapfile -t records < <(find artifacts/audit/candidate-node-processes -mindepth 2 -maxdepth 2 -type f -path "*/fresh-validator-*-${parent}-*/three-of-four.process.json" | sort)
  if [ "${#records[@]}" -eq 3 ]; then break; fi
  if ! kill -0 "$parent" 2>/dev/null || [ "$SECONDS" -ge "$until_at" ]; then
    echo 'Original three-node startup records unavailable'; wait "$parent"; exit 1
  fi
  sleep 0.02
done
record=${records[2]}
node_pid=$(sed -E 's/.*"pid":([0-9]+).*/\1/' "$record")
[[ "$node_pid" =~ ^[0-9]+$ ]]
[[ $(awk '/^PPid:/{print $2}' "/proc/$node_pid/status") -eq "$parent" ]]
[[ $(readlink "/proc/$node_pid/exe") == */novovm-node ]]
echo "Pausing owned participant $node_pid from $record for 20s; original parent $parent"
kill -STOP "$node_pid"
sleep 20
kill -CONT "$node_pid" 2>/dev/null || true
echo "Resumed owned participant $node_pid"
node_pid=''
set +e
wait "$parent"
result=$?
echo "Original test exit=$result"
exit "$result"
