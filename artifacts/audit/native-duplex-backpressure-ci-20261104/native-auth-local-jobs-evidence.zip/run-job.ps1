$ErrorActionPreference = 'Stop'
$platform = if ($IsWindows) { 'windows-x86_64' } else { 'linux-x86_64' }
$root = (Get-Location).Path
$out = Join-Path $root 'target/native-auth-local-job-20261106'
$python = if ($IsWindows) { 'python' } else { 'python3' }
$jobJson = & $python -c 'import json,yaml; print(json.dumps(yaml.safe_load(open(".github/workflows/ci.yml", encoding="utf-8"))["jobs"]["native_transport_qualification"]))'
if ($LASTEXITCODE -ne 0) { throw 'Could not read original workflow.' }
$job = $jobJson | ConvertFrom-Json -AsHashtable
$matrix = $job.strategy.matrix.include | Where-Object { $_.platform -ceq $platform }
if (@($matrix).Count -ne 1) { throw 'Expected exactly one original platform matrix.' }
$env:NATIVE_RUNTIME_CANDIDATE_ROOT = $job.env.NATIVE_RUNTIME_CANDIDATE_ROOT
$env:GITHUB_ENV = Join-Path $out "$platform.github-env"
if (Test-Path -LiteralPath $env:GITHUB_ENV) { throw 'Refuse to overwrite previous environment evidence.' }
New-Item -ItemType File -Path $env:GITHUB_ENV | Out-Null
$env:RUNNER_TEMP = Join-Path ([IO.Path]::GetTempPath()) ("novovm-local-auth-$platform-" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $env:RUNNER_TEMP | Out-Null
$env:CARGO_BUILD_JOBS = '4'
$env:RUSTUP_TOOLCHAIN = '1.94.0'
$env:COLUMNS = '120'
$env:LINES = '40'
& rustc --version
if ($LASTEXITCODE -ne 0) { throw 'Pinned toolchain is not installed locally.' }
$index = 0
foreach ($step in $job.steps) {
    if (!$step.run -or $step.name -eq 'Install pinned Rust toolchain') { continue }
    $run = $step.run
    foreach ($key in $matrix.Keys) { $run = $run.Replace(('${{ matrix.' + $key + ' }}'), [string]$matrix[$key]) }
    if ($step.name -eq 'Fetch only the pinned platform candidate and formal counterexample') {
        # Already materialized local artifacts; retain original hash/manifest checks.
        $run = $run -replace '(?m)^git lfs pull[^\r\n]*\r?\nif \(\$LASTEXITCODE -ne 0\) \{ exit \$LASTEXITCODE \}\r?\n', ''
        if ($run -match 'git lfs pull') { throw 'Unexpected artifact preparation shape.' }
    }
    $index++
    Write-Output "STEP $index $($step.name)"
    $log = Join-Path $out "$platform-step-$index.log"
    & (Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })) -NoProfile -Command $run *> $log
    if ($LASTEXITCODE -ne 0) { throw "Original workflow step failed ($LASTEXITCODE): $($step.name); see $log" }
    foreach ($line in Get-Content -LiteralPath $env:GITHUB_ENV) {
        $pair = $line.Split('=', 2)
        if ($pair.Count -ne 2) { throw 'Invalid original GITHUB_ENV record.' }
        [Environment]::SetEnvironmentVariable($pair[0], $pair[1], 'Process')
    }
    Write-Output "PASS $index $($step.name)"
}
if ($index -ne 5) { throw "Original build/test step count drifted: $index" }
Write-Output "PASS original native_transport_qualification local job: $platform"
