#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
phase="$1"
out="$PWD/target/native-runtime-manifest-ci-20261106"
test_binary=/home/aoem-a1/novovm-build-b-20261102/debug/deps/novovm_node-3407aa86bee47a1d
env_file="$out/$phase.github-env"
test -f "$env_file"
env -u AOEM_DLL_MANIFEST -u NOVOVM_AOEM_MANIFEST -u NOVOVM_AOEM_TEST_MANIFEST \
    -u AOEM_DLL -u NOVOVM_AOEM_DLL -u NOVOVM_AOEM_TEST_LIBRARY \
    bash -c '
      set -euo pipefail
      while IFS= read -r line; do
        line="${line%$'\''\r'\''}"
        name="${line%%=*}"; value="${line#*=}"
        if [[ "$value" =~ ^[A-Za-z]: ]]; then value="$(wslpath -u "$value")"; fi
        export "$name=$value"
      done < "$1"
      export AOEM_DLL_MANIFEST_REQUIRED=1 NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0
      export NOVOVM_RESIDENT_NODE_BINARY=/home/aoem-a1/novovm-build-b-20261102/debug/novovm-node
      "$2" native_only_ --ignored --nocapture --test-threads=1
    ' bash "$env_file" "$test_binary" > "$out/$phase.native-process.log" 2>&1
if [[ "$phase" == fixed ]]; then
  env -u AOEM_DLL_MANIFEST -u NOVOVM_AOEM_MANIFEST -u NOVOVM_AOEM_TEST_MANIFEST \
      -u AOEM_DLL -u NOVOVM_AOEM_DLL -u NOVOVM_AOEM_TEST_LIBRARY \
      bash -c '
        set -euo pipefail
        while IFS= read -r line; do
          line="${line%$'\''\r'\''}"
          name="${line%%=*}"; value="${line#*=}"
          if [[ "$value" =~ ^[A-Za-z]: ]]; then value="$(wslpath -u "$value")"; fi
          export "$name=$value"
        done < "$1"
        export AOEM_DLL_MANIFEST_REQUIRED=1 NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0
        export NOVOVM_RESIDENT_NODE_BINARY=/home/aoem-a1/novovm-build-b-20261102/debug/novovm-node
        "$2" native_uca_process_ --ignored --nocapture --test-threads=1
      ' bash "$env_file" "$test_binary" > "$out/fixed.uca-process.log" 2>&1
fi
