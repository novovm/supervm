#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102
export CARGO_BUILD_JOBS=4
export COLUMNS=120 LINES=40
export NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0
export NOVOVM_AOEM_TEST_LIBRARY=/home/aoem-a1/novovm-ci-runtime-20261103.iOetRI/linux/libaoem_ffi.so
export NOVOVM_AOEM_DLL="$NOVOVM_AOEM_TEST_LIBRARY"
export NOVOVM_AOEM_TEST_MANIFEST=/home/aoem-a1/novovm-ci-runtime-20261103.iOetRI/manifest.json
export NOVOVM_AOEM_MANIFEST="$NOVOVM_AOEM_TEST_MANIFEST"
export AOEM_DLL_MANIFEST="$NOVOVM_AOEM_TEST_MANIFEST"
export AOEM_DLL_MANIFEST_REQUIRED=1
export NOVOVM_RESIDENT_NODE_BINARY="$CARGO_TARGET_DIR/debug/novovm-node"
out=target/native-only-retirement-validation
cargo check --locked -p novovm-node --all-targets --message-format=short > "$out/node-check-linux-final.log" 2>&1
cargo clippy --locked -p novovm-node --all-targets --message-format=short -- -D warnings > "$out/node-clippy-linux.log" 2>&1
if [[ "${VALIDATION_PHASE:-full}" == full ]]; then
cargo build --locked -p novovm-node --bin novovm-node --bin novovm-native-client --message-format=short > "$out/node-build-linux.log" 2>&1
sha256sum "$NOVOVM_RESIDENT_NODE_BINARY" "$CARGO_TARGET_DIR/debug/novovm-native-client" "$NOVOVM_AOEM_TEST_LIBRARY" "$NOVOVM_AOEM_TEST_MANIFEST" > "$out/linux-identities.sha256"
cargo test --locked -p novovm-node --test native_candidate_node_cli retired_wss_mainchain_selection_fails_before_opening_state -- --exact --test-threads=1 > "$out/retired-entry-linux.log" 2>&1
fi
cargo test --locked -p novovm-node --lib native_archive_ -- --ignored --list > "$out/archive-list-linux.log" 2>&1
grep -q 'native_archive_control_duplicates_preserve_distinct_votes_and_retry_after_delivery: test' "$out/archive-list-linux.log"
cargo test --locked -p novovm-node --lib native_archive_ -- --ignored --test-threads=1 > "$out/archive-linux.log" 2>&1
cargo test --locked -p novovm-node --lib native_pipeline::consensus::native::tests -- --test-threads=1 > "$out/native-source-binding-linux.log" 2>&1
cargo test --locked -p novovm-consensus --lib round_bft::collector::tests -- --test-threads=1 > "$out/collector-linux.log" 2>&1
cargo test --locked -p novovm-node --lib native_block_seal -- --test-threads=1 > "$out/seal-pure-validation-linux.log" 2>&1
cargo test --locked -p novovm-node --lib native_fresh_rpc -- --test-threads=1 > "$out/shared-rpc-linux.log" 2>&1
cargo test --locked -p novovm-node --lib product_evidence::tests -- --test-threads=1 > "$out/product-evidence-linux.log" 2>&1
cargo test --locked -p novovm-node --lib mainline_preflight::tests -- --test-threads=1 > "$out/mainline-preflight-linux.log" 2>&1
env NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=1 cargo test --locked -p novovm-node --test native_candidate_node_cli -- --test-threads=1 > "$out/offline-cli-linux.log" 2>&1
env NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=1 cargo test --locked -p novovm-node --lib candidate_workspace_execution_fresh_genesis_real_aoem_publication_and_retry -- --test-threads=1 > "$out/offline-publication-linux.log" 2>&1
cargo test --locked -p novovm-node --lib native_only_ -- --ignored --list > "$out/native-process-list-linux.log" 2>&1
grep -q 'native_only_recovery_late_lowest_validator_original_database_and_minority: test' "$out/native-process-list-linux.log"
grep -q 'native_only_recovery_late_highest_validator_original_database_and_minority: test' "$out/native-process-list-linux.log"
cargo test --locked -p novovm-node --lib native_only_ -- --ignored --nocapture --test-threads=1 > "$out/native-process-linux.log" 2>&1
cargo test --locked -p novovm-node --lib native_uca_process_ -- --ignored --nocapture --test-threads=1 > "$out/uca-process-linux.log" 2>&1
