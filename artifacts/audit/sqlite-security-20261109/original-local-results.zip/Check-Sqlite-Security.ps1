param([switch]$Linux,[switch]$SecurityOnly,[switch]$NodeRecovery,[switch]$NetworkFollowup,[switch]$StorageClosure,[switch]$StoreGuardsOnly)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:/WorksArea/SUPERVM'
$out='C:/Users/leadb/AppData/Local/NOVOVM/security-sqlite-20261109'
$platform=if($Linux){'linux'}else{'windows'}
$target=if($Linux){'x86_64-unknown-linux-gnu'}else{'x86_64-pc-windows-msvc'}
if($Linux){
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
}else{
    $env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'
}
$env:CARGO_BUILD_JOBS='2'
$env:RUSTUP_TOOLCHAIN='1.94.0'
Set-Location $repo
$linuxEnvironment=@('PATH=/home/aoem-a1/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102','CARGO_BUILD_JOBS=2','RUSTUP_TOOLCHAIN=1.94.0')
if($NodeRecovery){
    $package=if($Linux){'/mnt/d/WorksArea/SUPERVM/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-linux-x86_64'}else{'D:/WorksArea/SUPERVM/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-windows-x86_64'}
    $library=if($Linux){"$package/aoem/linux/core/bin/libaoem_ffi.so"}else{"$package/aoem/windows/core/bin/aoem_ffi.dll"}
    $manifest="$package/aoem/manifest/aoem-manifest.json"
    foreach($name in @('NOVOVM_AOEM_TEST_LIBRARY','NOVOVM_AOEM_DLL')){[Environment]::SetEnvironmentVariable($name,$library);$linuxEnvironment+="$name=$library"}
    foreach($name in @('AOEM_DLL_MANIFEST','NOVOVM_AOEM_MANIFEST','NOVOVM_AOEM_TEST_MANIFEST')){[Environment]::SetEnvironmentVariable($name,$manifest);$linuxEnvironment+="$name=$manifest"}
    $env:AOEM_DLL_MANIFEST_REQUIRED='1';$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
    $linuxEnvironment+=@('AOEM_DLL_MANIFEST_REQUIRED=1','NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0')
}
function Check([string]$Name,[string[]]$Arguments){
    $stdout="$out/$platform-$Name.stdout"
    $stderr="$out/$platform-$Name.stderr"
    if((Test-Path -LiteralPath $stdout) -or (Test-Path -LiteralPath $stderr)){throw 'Preserve original check evidence'}
    Write-Output "Starting $platform $Name"
    if($Linux){
        & wsl.exe -d Ubuntu-24.04 --cd /mnt/d/WorksArea/SUPERVM -- env @linuxEnvironment /home/aoem-a1/.cargo/bin/cargo @Arguments 1> $stdout 2> $stderr
    }else{
        & cargo @Arguments 1> $stdout 2> $stderr
    }
    $code=$LASTEXITCODE
    Write-Output "Finished $platform $Name exit=$code"
    if($code -ne 0){Get-Content -LiteralPath $stderr -Tail 30; Get-Content -LiteralPath $stdout -Tail 12; throw "$Name failed; preserve raw output"}
    if($Arguments[0] -ceq 'test' -and (Get-Content -LiteralPath $stdout -Raw) -notmatch 'test result: ok\. [1-9][0-9]* passed'){
        throw "$Name did not execute a nonzero test set; not accepted"
    }
}
if($SecurityOnly){
    Check 'audit-root' @('audit','--json')
    Check 'audit-runtime' @('audit','--file','runtime/Cargo.lock','--json')
    Check 'deny-root' @('deny','check','advisories','bans','licenses','sources')
    Check 'deny-runtime' @('deny','--manifest-path','runtime/Cargo.toml','check','advisories','bans','licenses','sources')
}elseif($StoreGuardsOnly){
    Check 'node-store-guards-actual' @('test','--release','--locked','--target',$target,'-p','novovm-node','--lib','native_pipeline::persistence::store::guard_tests','--','--test-threads=1')
}elseif($StorageClosure){
    Check 'mailbox-store-policy' @('test','--release','--locked','--target',$target,'-p','novovm-network','--lib','mailbox_store','--','--test-threads=1')
    Check 'mailbox-store-integration' @('test','--release','--locked','--target',$target,'-p','novovm-network','--test','mailbox_store','--','--test-threads=1')
    Check 'mailbox-runtime-integration' @('test','--release','--locked','--target',$target,'-p','novovm-network','--all-features','--test','mailbox_runtime','--','--test-threads=1')
    Check 'native-mailbox-session' @('test','--release','--locked','--target',$target,'-p','novovm-network','--all-features','--test','native_mailbox_session','--','--test-threads=1')
    Check 'storage-closure-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-storage-budget','--all-targets','--','-D','warnings')
    Check 'network-closure-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-network','--all-targets','--all-features','--','-D','warnings')
}elseif($NodeRecovery){
    Check 'node-store-guards' @('test','--release','--locked','--target',$target,'-p','novovm-node','--lib','store_guard_tests','--','--test-threads=1')
    foreach($case in @('actual_uca_startup_three_pins_reopen_and_legacy_asset_rejection','actual_native_proportional_fee_respend_and_cold_recovery')){
        Check $case @('test','--release','--locked','--target',$target,'-p','novovm-node','--lib',$case,'--','--ignored','--test-threads=1')
        if((Get-Content "$out/$platform-$case.stdout" -Raw) -notmatch 'test result: ok\. 1 passed'){throw 'Actual AOEM recovery test did not execute exactly once'}
    }
}elseif($NetworkFollowup){
    Check 'network-serial-diagnostic' @('test','--release','--locked','--target',$target,'-p','novovm-network','--lib','--','--test-threads=1')
    Check 'network-features-tests' @('test','--release','--locked','--target',$target,'-p','novovm-network','--lib','--all-features')
    Check 'storage-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-storage-budget','--all-targets','--','-D','warnings')
    Check 'network-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-network','--all-targets','--all-features','--','-D','warnings')
}else{
    Check 'storage-tests' @('test','--release','--locked','--target',$target,'-p','novovm-storage-budget','--lib')
    Check 'network-tests' @('test','--release','--locked','--target',$target,'-p','novovm-network','--lib')
    Check 'network-features-tests' @('test','--release','--locked','--target',$target,'-p','novovm-network','--lib','--all-features')
    Check 'storage-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-storage-budget','--all-targets','--','-D','warnings')
    Check 'network-clippy' @('clippy','--release','--locked','--target',$target,'-p','novovm-network','--all-targets','--all-features','--','-D','warnings')
}
