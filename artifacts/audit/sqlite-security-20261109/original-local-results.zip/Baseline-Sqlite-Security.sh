#!/usr/bin/env bash
set -euo pipefail
baseline_dir=$(mktemp -d /tmp/novovm-sqlite-baseline-4ca654cf.XXXXXX)
tar -xf /mnt/c/Users/leadb/AppData/Local/NOVOVM/security-sqlite-20261109/baseline-4ca654cf-source.tar -C "$baseline_dir"
printf 'Read-only committed baseline source: %s\n' "$baseline_dir"
export PATH=/home/aoem-a1/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102
export CARGO_BUILD_JOBS=2 RUSTUP_TOOLCHAIN=1.94.0
cargo test --manifest-path "$baseline_dir/Cargo.toml" --release --locked --target x86_64-unknown-linux-gnu -p novovm-network --lib
