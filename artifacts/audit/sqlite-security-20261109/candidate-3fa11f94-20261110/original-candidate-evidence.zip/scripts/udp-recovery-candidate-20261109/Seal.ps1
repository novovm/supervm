$ErrorActionPreference = 'Stop'
$repo = 'D:\WorksArea\SUPERVM'
$source = '5181da733d59d998afa898bb9964db5deae9e72c'
$zipPath = Join-Path $PSScriptRoot 'novonet-probe-5181da73-windows-x86_64.zip'
$tarPath = Join-Path $PSScriptRoot 'novonet-probe-5181da73-linux-x86_64.tar.gz'
$root = Join-Path $repo 'artifacts\product-overlay\novonet-probe-5181da73-windows-x86_64'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    $files = @(Get-ChildItem -LiteralPath $root -File -Recurse)
    $entries = @($zip.Entries | Where-Object { $_.Name.Length -gt 0 })
    if ($entries.Count -ne $files.Count) { throw 'ZIP member count differs' }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($entry in $entries) {
        if (!$seen.Add($entry.FullName)) { throw 'Duplicate ZIP member' }
        $prefix = 'novonet-probe-5181da73-windows-x86_64/'
        $name = $entry.FullName.Replace('\','/')
        if (!$name.StartsWith($prefix, [StringComparison]::Ordinal)) { throw 'ZIP root differs' }
        $path = [IO.Path]::GetFullPath((Join-Path $root $name.Substring($prefix.Length)))
        if (!$path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'ZIP member escapes root' }
        $item = Get-Item -LiteralPath $path
        if ($item.Length -ne $entry.Length) { throw 'ZIP length differs' }
        $stream = $entry.Open()
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $digest = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
        finally { $sha.Dispose(); $stream.Dispose() }
        if ($digest -cne (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()) { throw 'ZIP member hash differs' }
    }
} finally { $zip.Dispose() }
$platforms = @()
foreach ($platform in @('windows','linux')) {
    $verification = Get-Content -LiteralPath (Join-Path $PSScriptRoot "verified-$platform.json") -Raw | ConvertFrom-Json
    if ($verification.source_commit -cne $source) { throw 'Verification source differs' }
    $archive = if ($platform -ceq 'windows') { $zipPath } else { $tarPath }
    $platforms += [ordered]@{
        platform = $platform
        archive = [IO.Path]::GetFileName($archive)
        archive_bytes = (Get-Item -LiteralPath $archive).Length
        archive_sha256 = (Get-FileHash -LiteralPath $archive).Hash.ToLowerInvariant()
        release_manifest_sha256 = $verification.manifest_sha256
        artifact_count = $verification.artifacts_verified
        node_sha256 = $verification.node_sha256
        client_sha256 = $verification.client_sha256
        ctl_sha256 = $verification.ctl_sha256
        aoem_sha256 = $verification.actual_packaged_runtime.data.library_sha256
        actual_packaged_runtime_verification = $true
        actual_existing_service_contract_verification = $true
        bounded_binary_probe_prepare_cancel = $true
    }
}
$report = [ordered]@{
    source_commit = $source
    created_at = (Get-Date).ToUniversalTime().ToString('o')
    archive_directory_on_A = $PSScriptRoot
    platforms = $platforms
    installed = $false
    running_nodes_updated = $false
    actual_udp_recovery_root_cause_resolved = $false
    new_four_host_acceptance = $false
    new_object_done = $false
    new_tps = $false
}
$output = Join-Path $PSScriptRoot 'candidate-manifest.json'
$bytes = [Text.UTF8Encoding]::new($false).GetBytes(($report | ConvertTo-Json -Depth 8))
$file = [IO.File]::Open($output,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try { $file.Write($bytes,0,$bytes.Length); $file.Flush($true) } finally { $file.Dispose() }
Write-Output "PASS ZIP contents and candidate hashes: $output"
