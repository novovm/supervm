$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$out='C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$source='3fa11f940b18e54b46e6b927d3d66294bea37088'
$newId='2026-10-16 14:45:20 555e07ef33f69a0957d24d8e555b702464a131d6f1607f4c3c1e4551e8e6ca76'
$oldId='2026-06-03 19:12:13 d6e03d8c777cfa2d35e3b60d8ec3e0187f3e9f99d8e2ee9cac695fd6fcdf1a24'
$ci=Get-Content "$out/original-ci.json" -Raw|ConvertFrom-Json
if($ci.head_sha -cne $source -or $ci.conclusion -cne 'success' -or $ci.run_attempt -ne 1){throw 'Fixed-source CI not qualified'}
$items=@()
foreach($platform in @('windows','linux')){
    $root="$repo/artifacts/product-overlay/novonet-sqlite-3fa11f94-$platform-x86_64"
    $m=Get-Content "$root/release-manifest.json" -Raw|ConvertFrom-Json
    $v=Get-Content "$out/verified-$platform.json" -Raw|ConvertFrom-Json
    if($m.git_commit -cne $source -or (Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant() -cne $v.manifest_sha256){throw 'Actual verified package differs'}
    foreach($contract in $m.build_contracts){
        $extension=if($platform -ceq 'windows'){'.exe'}else{''}
        $path="$root/bin/$($contract.binary)$extension"
        $hash=(Get-FileHash $path).Hash.ToLowerInvariant()
        $listed=@($m.artifacts|Where-Object path -CEQ "bin/$($contract.binary)$extension")
        if($listed.Count -ne 1 -or $listed[0].sha256 -cne $hash){throw 'Executable hash differs from original manifest'}
        $text=[Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($path))
        $new=$text.Contains($newId);$old=$text.Contains($oldId)
        if($old){throw 'Old bundled SQLite source ID retained in candidate'}
        if($contract.binary -ceq 'novovm-node' -and (!$new -or !$text.Contains('3.54.1'))){throw 'Node lacks expected updated SQLite markers'}
        $items+=@{platform=$platform;binary=$contract.binary;sha256=$hash;sqlite_3_54_1_version_marker=$text.Contains('3.54.1');sqlite_3_54_1_source_id=$new;old_sqlite_source_id=$old;marker_absence_does_not_prove_no_sqlite=(!$new)}
    }
}
$node='/mnt/d/WorksArea/SUPERVM/artifacts/product-overlay/novonet-sqlite-3fa11f94-linux-x86_64/bin/novovm-node'
$symbols=@(& wsl.exe -d Ubuntu-24.04 -- nm $node)
if($LASTEXITCODE -ne 0){throw 'Actual ELF symbol inspection failed'}
$selected=@($symbols|Where-Object {$_ -match ' (sqlite3_libversion(_number)?|sqlite3_sourceid|novovm_quota_(refresh|reserve|release))$'})
if($selected.Count -ne 6){throw 'Original SQLite/quota code not identified in actual node ELF'}
$linked=@(& wsl.exe -d Ubuntu-24.04 -- ldd $node)
if($LASTEXITCODE -ne 0 -or ($linked -join "`n") -match 'libsqlite'){throw 'Unexpected dynamic SQLite dependency'}
$report=[ordered]@{source_commit=$source;required_ci=$ci.id;rusqlite='0.41.0';libsqlite3_sys='0.39.1';sqlite_version='3.54.1';sqlite_source_id=$newId;method='Actual executable source/version markers, fixed Cargo build contracts and manifest hashes; actual ELF SQLite/quota symbols and dynamic dependency list';node_runtime_sql_version_api_invoked=$false;companion_real_sql_and_quota_tests='frozen 3fa source checks in sqlite-security-20261109; not an added node API';artifacts=$items;linux_node_sqlite_and_quota_symbols=$selected;linux_node_dynamic_libraries=$linked;database_opened=$false;node_started=$false;new_product_interface=$false}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($report|ConvertTo-Json -Depth 9))
$file=[IO.File]::Open("$out/sqlite-binary-provenance.json",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
Write-Output ('PASS actual executable marker/link inspection: '+$items.Count+' programs; no node/DB started; not runtime API readback')
