param([switch]$Linux)
$ErrorActionPreference='Stop'
$delivery=if($Linux){'/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'}else{'C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'}
$base=Join-Path $PSScriptRoot '../novonet-probe-candidate-20261108/Verify.ps1'
$script=Get-Content -LiteralPath $base -Raw
if(!$script.Contains('ddd89e8e05721a2ddb8a7ae9255405d395b39a46')){throw 'Original verifier source changed'}
$script=$script.Replace('ddd89e8e05721a2ddb8a7ae9255405d395b39a46','3fa11f940b18e54b46e6b927d3d66294bea37088')
$script=$script.Replace('novonet-probe-ddd89e8e','novonet-sqlite-3fa11f94')
$script=$script.Replace('$PSScriptRoot',("'"+$delivery.Replace("'","''")+"'"))
& ([scriptblock]::Create($script)) -Linux:$Linux
