$ErrorActionPreference='Stop'
$root='D:/WorksArea/SUPERVM'
$out='C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$archive="$root/artifacts/audit/sqlite-security-20261109/original-local-results.zip"
if((Get-FileHash $archive).Hash.ToLowerInvariant() -cne '3de4cc2dc2cf854a7a0cc2a411de795f347b0291f9569fab1f139881214d6bb7'){throw 'Original negative evidence changed'}
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
$records=@()
try{
    foreach($name in @('linux-network-tests.stdout','windows-network-features-tests.stdout','linux-network-features-tests.stdout')){
        $entries=@($zip.Entries|Where-Object FullName -CEQ $name)
        if($entries.Count -ne 1){throw 'Original evidence member missing/duplicate'}
        $reader=[IO.StreamReader]::new($entries[0].Open())
        try{$raw=$reader.ReadToEnd()}finally{$reader.Dispose()}
        $failures=[regex]::Matches($raw,'(?ms)^---- (?<test>[^\r\n]+) stdout ----\r?\n(?<body>.*?)(?=^---- |^failures:\s*$|\z)')
        $expected=if($name -ceq 'linux-network-tests.stdout'){3}elseif($name.StartsWith('windows')){26}else{27}
        if($failures.Count -ne $expected){throw 'Failure enumeration differs from original result'}
        foreach($failure in $failures){$records+=@{run=$name;test=$failure.Groups['test'].Value;body=$failure.Groups['body'].Value.Trim()}}
    }
}finally{$zip.Dispose()}
$report=[ordered]@{source='3fa11f940b18e54b46e6b927d3d66294bea37088';original_evidence_sha256='3de4cc2dc2cf854a7a0cc2a411de795f347b0291f9569fab1f139881214d6bb7';occurrences=$records;unique_failed_tests=@($records.test|Sort-Object -Unique)}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($report|ConvertTo-Json -Depth 9))
$file=[IO.File]::Open("$out/parallel-failure-extract.json",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
foreach($name in $report.unique_failed_tests){
    $events=@($records|Where-Object test -CEQ $name)
    Write-Output ("TEST $name ["+($events.run -join ',')+"]")
    Write-Output $events[0].body
}
