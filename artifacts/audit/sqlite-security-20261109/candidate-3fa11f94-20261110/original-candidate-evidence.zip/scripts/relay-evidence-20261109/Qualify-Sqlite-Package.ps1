param([switch]$Linux)
$ErrorActionPreference='Stop'
$base=Join-Path $PSScriptRoot 'Qualify-Coordinated-Package.ps1'
$script=Get-Content -LiteralPath $base -Raw
$script=$script.Replace('2b97fc8e5d1f83c521669e6f82803794ad4fd5ed','3fa11f940b18e54b46e6b927d3d66294bea37088')
$script=$script.Replace('delivery-2b97fc8e-20261109','candidate-sqlite-3fa11f94-20261110')
$script=$script.Replace('novonet-relay-evidence-2b97fc8e','novonet-sqlite-3fa11f94')
$script=$script.Replace('$env:CARGO_TARGET_DIR="$repo/target/runtime-rebuild"',"`$env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'")
$target=if($Linux){'x86_64-unknown-linux-gnu'}else{'x86_64-pc-windows-msvc'}
$script=$script.Replace('& cargo test --locked',"& cargo test --release --target $target --locked")
& ([scriptblock]::Create($script)) -Linux:$Linux
