param([switch]$Linux)
$ErrorActionPreference='Stop'
$name=if($Linux){'Archive-Coordinated-Linux.ps1'}else{'Archive-Coordinated-Windows.ps1'}
$script=Get-Content (Join-Path $PSScriptRoot $name) -Raw
$script=$script.Replace('delivery-2b97fc8e-20261109','candidate-sqlite-3fa11f94-20261110')
$script=$script.Replace('novonet-relay-evidence-2b97fc8e','novonet-sqlite-3fa11f94')
& ([scriptblock]::Create($script))
