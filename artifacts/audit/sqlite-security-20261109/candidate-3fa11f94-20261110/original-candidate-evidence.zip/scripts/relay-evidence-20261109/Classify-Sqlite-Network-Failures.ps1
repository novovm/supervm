$ErrorActionPreference='Stop'
$out='C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$original=Get-Content "$out/parallel-failure-extract.json" -Raw|ConvertFrom-Json
$isolated=@(Get-Content "$out/isolated-windows.json" -Raw|ConvertFrom-Json)+@(Get-Content "$out/isolated-linux.json" -Raw|ConvertFrom-Json)
if($isolated.Count -ne 56 -or @($isolated|Where-Object {-not $_.passed}).Count){throw 'Isolation did not cover the 56 original occurrences'}
$rows=@()
foreach($failure in $original.occurrences){
    $body=$failure.body;$name=$failure.test
    if($body -match 'carrier endpoint limit'){
        $category='R1';$reason='原日志直接记录全局端点额度拒绝；生产上限4工作中。原日志没有记录当时具体占用者，不认定业务泄漏已排除。'
        $reference='iroh_transport.rs:404,1128-1133; lib.rs:6-8'
    }elseif($body -match 'journal exclusive lock unavailable'){
        $category='U1';$reason='真实journal锁拒绝；这些用例使用独立临时路径，不归咎路径重名。原现场缺锁持有者/inode/fd时间线，保留未知原因。'
        $reference='product_service_file.rs:261-285; product_service_native_tests.rs:256,897,1196; product_service_lease_tests.rs:363,604'
    }elseif($name -like 'iroh_transport::*' -and $body -match 'assertion `left == right` failed'){
        $category='R2';$reason='断言直接读取进程全局available_permits，模块SERIAL不覆盖其他消费者。并行时精确空闲数不是该用例独占计数；不以此证明生产没有泄漏。'
        $reference='iroh_transport.rs:2263,2873,3168,3230,3500; lib.rs:6-8'
    }elseif($body -match 'IrohAddressV1'){
        $category='U2';$reason='fixture oneshot发送给已关闭接收者而unwrap失败，地址本身不是协议拒绝原因；对端先退出的原始错误未保存，不将其全部归为额度。'
        $reference='iroh_transport.rs:3802,4037,4252,4345,4425,4522'
    }elseif($name -like '*capacity_rejected_bootstrap_peer_rotates*'){
        $category='S1';$reason='确认三个测试复用chain_id=99160322，其中native_bodies_phase会清除该链peer状态，构成实际测试命名域冲突；原失败没有清理先后记录，不补写必然因果。'
        $reference='eth_fullnode.rs:5428,5710,6900,1750; runtime_status.rs:6844,6938'
    }elseif($name -like '*rlpx_new_block_hashes_gate_v3' -or $name -like '*rlpx_tx_outbound_broadcast_gate_v3'){
        $category='T1';$reason='原2秒跟进/响应观察未完成，其中outbound明确read_timeout；阶段日志不等于实际发包或收包证据。未定位调度、队列、IO还是逻辑原因。'
        $reference='transport.rs:21335,21384-21402,25045-25064'
    }elseif($body -match 'carrier scope expired'){
        $category='T2';$reason='有限scope实际过期；原记录不足以区分调度拖延、用例准备和流处理原因。原期限不改。'
        $reference='product_service_lease::host::control_chunk_tests; product_bootstrap_recovery_tests.rs:239 (see row.test for the actual case)'
    }elseif($name -like 'tls_transport::*'){
        $category='T3';$reason='部分头测试期待request expired，实际为TLS stream failed；是终止原因/时限相关反例，不凭隔离通过断言线程安全或状态机已正确。'
        $reference='tls_transport_tests.rs:35-60'
    }elseif($name -like '*bootstrap_recovery_revocation_during_backoff_stops_redial'){
        $category='U3';$reason='Connecting计数0而预期1，说明预期阶段没有被观察到；原记录不能证明是额度、过期、并发状态还是真实逻辑。'
        $reference='product_bootstrap_recovery_tests.rs:287-324'
    }elseif($name -like '*v6_idle_still_observes_owner_revocation'){
        $category='U4';$reason='仅有channel closed，缺少服务任务第一错误；不能从未收到完成信息推出认证失败或统一归为资源冲突。'
        $reference='mailbox_idle_tests.rs:25-55'
    }else{throw "Explicit classification required: $name"}
    $match=@($isolated|Where-Object {$_.test -ceq $name -and $_.original_run -ceq $failure.run})
    if($match.Count -ne 1){throw 'Isolation/original mapping differs'}
    $rows+=@{original_run=$failure.run;test=$name;category=$category;observed_boundary_and_remaining_uncertainty=$reason;source_reference=$reference;isolated=$match[0];original_parallel_failure_preserved=$true;original_failure_rewritten_as_pass=$false;production_change_made=$false}
}
$summary=@($rows|Group-Object category|Sort-Object Name|ForEach-Object {@{category=$_.Name;occurrences=$_.Count;distinct_tests=@($_.Group.test|Sort-Object -Unique).Count}})
$report=[ordered]@{source=$original.source;original_evidence_sha256=$original.original_evidence_sha256;original_occurrences=$rows.Count;distinct_tests=$original.unique_failed_tests.Count;isolated_once_passed=$isolated.Count;changed_limits_or_timeouts=$false;full_parallel_rerun_claimed_pass=$false;all_parallel_root_causes_resolved=$false;new_proven_production_concurrency_defect=$false;absence_of_concurrency_defects_proven=$false;summary=$summary;rows=$rows}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($report|ConvertTo-Json -Depth 12))
$file=[IO.File]::Open("$out/parallel-classification.json",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
foreach($item in $summary){Write-Output ($item|ConvertTo-Json -Compress)}
