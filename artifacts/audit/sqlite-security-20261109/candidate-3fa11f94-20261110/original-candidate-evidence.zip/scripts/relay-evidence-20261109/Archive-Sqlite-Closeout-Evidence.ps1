$ErrorActionPreference = 'Stop'
$repo = 'D:/WorksArea/SUPERVM'
$delivery = 'C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$audit = "$repo/artifacts/audit/sqlite-security-20261109/candidate-3fa11f94-20261110"
$destination = "$audit/original-candidate-evidence.zip"
if (Test-Path -LiteralPath $destination) { throw 'Preserve existing evidence archive' }
$items = [Collections.Generic.List[object]]::new()
foreach ($name in @('build-windows.log','build-linux.log','packaged-native-identity-windows.log','packaged-native-identity-linux.log','candidate-manifest.json','original-ci.json','original-ci-jobs.json','verified-windows.json','verified-linux.json','sqlite-binary-provenance.json','parallel-failure-extract.json','parallel-classification.json','isolated-windows.json','isolated-linux.json')) {
    $items.Add(@{Path="$delivery/$name"; Entry="results/$name"})
}
foreach ($platform in @('windows','linux')) {
    $files = @(Get-ChildItem -LiteralPath "$delivery/isolation-$platform" -File | Where-Object Name -Match '^\d+\.(list|list\.stderr|stdout|stderr)$')
    $expected = if ($platform -eq 'windows') { 104 } else { 120 }
    if ($files.Count -ne $expected) { throw "Incomplete isolated logs: $platform" }
    foreach ($file in $files) { $items.Add(@{Path=$file.FullName; Entry="results/isolation-$platform/$($file.Name)"}) }
}
foreach ($name in @('Build-Sqlite-Candidate.ps1','Verify-Sqlite-Candidate.ps1','Qualify-Sqlite-Package.ps1','Qualify-Coordinated-Package.ps1','Archive-Sqlite-Candidate.ps1','Archive-Coordinated-Windows.ps1','Archive-Coordinated-Linux.ps1','Seal-Sqlite-Candidate.ps1','Verify-Packaged-Sqlite.ps1','Extract-Sqlite-Network-Failures.ps1','Isolate-Sqlite-Network-Failures.ps1','Classify-Sqlite-Network-Failures.ps1','Archive-Sqlite-Closeout-Evidence.ps1')) {
    $items.Add(@{Path="$repo/target/relay-evidence-20261109/$name"; Entry="scripts/relay-evidence-20261109/$name"})
}
foreach ($relative in @('novonet-probe-candidate-20261108/Verify.ps1','udp-recovery-candidate-20261109/Seal.ps1')) {
    $items.Add(@{Path="$repo/target/$relative"; Entry="scripts/$relative"})
}
foreach ($item in $items) {
    $file = Get-Item -LiteralPath $item.Path
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -gt 2MB) { throw 'Unexpected evidence item' }
    $content = Get-Content -LiteralPath $item.Path -Raw
    if ($content -match '-----BEGIN (?:[A-Z ]+)?PRIVATE KEY-----|(?:ghp_|github_pat_)[A-Za-z0-9_]{20,}|\bAKIA[A-Z0-9]{16}\b') { throw "Possible secret in evidence: $($item.Entry)" }
}
$archive = [IO.Compression.ZipFile]::Open($destination,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($item in $items) { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$item.Path,$item.Entry,[IO.Compression.CompressionLevel]::Optimal) }
} finally { $archive.Dispose() }
$archive = [IO.Compression.ZipFile]::OpenRead($destination)
try {
    if ($archive.Entries.Count -ne $items.Count) { throw 'Archive member count differs' }
    foreach ($item in $items) {
        $stream = $archive.GetEntry($item.Entry).Open()
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $actual = [Convert]::ToHexString($sha.ComputeHash($stream)).ToLowerInvariant() } finally { $stream.Dispose(); $sha.Dispose() }
        if ($actual -cne (Get-FileHash -LiteralPath $item.Path -Algorithm SHA256).Hash.ToLowerInvariant()) { throw "Archived bytes differ: $($item.Entry)" }
    }
} finally { $archive.Dispose() }
[ordered]@{archive=$destination;items=$items.Count;bytes=(Get-Item -LiteralPath $destination).Length;sha256=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant();members_verified=$true;nodes_changed=$false} | ConvertTo-Json
