param([switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$root='C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$old='C:/Users/leadb/AppData/Local/NOVOVM/security-sqlite-20261109'
$platform=if($Linux){'linux'}else{'windows'}
$extracted=Get-Content "$root/parallel-failure-extract.json" -Raw|ConvertFrom-Json
$pins=Get-Content 'D:/WorksArea/SUPERVM/artifacts/audit/sqlite-security-20261109/local-verification.json' -Raw|ConvertFrom-Json
foreach($property in $pins.source_pins.PSObject.Properties){
    if((Get-FileHash "D:/WorksArea/SUPERVM/$($property.Name)").Hash.ToLowerInvariant() -cne $property.Value){throw 'Original tested source content changed'}
}
$directory="$root/isolation-$platform"
if(Test-Path $directory){throw 'Preserve original isolation results'}
New-Item -ItemType Directory -Path $directory|Out-Null
$records=@()
foreach($run in @($extracted.occurrences.run|Sort-Object -Unique|Where-Object {$_.StartsWith($platform)})){
    $log=Get-Content "$old/$($run.Replace('.stdout','.stderr'))" -Raw
    $path=[regex]::Match($log,'Running unittests[^\r\n]*\((?<path>[^()\r\n]+)\)').Groups['path'].Value
    if(!$path){throw 'Original Cargo test executable not recorded'}
    $tag=if($run -ceq 'linux-network-tests.stdout'){'default'}else{'all-features'}
    if($Linux){
        $destination="/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110/isolation-$platform/network-$tag"
        $sourceHash=(& wsl.exe -d Ubuntu-24.04 -- sha256sum $path).Split(' ')[0]
        & wsl.exe -d Ubuntu-24.04 -- cp --no-clobber $path $destination
        if($LASTEXITCODE -ne 0){throw 'Test executable snapshot failed'}
        $copiedHash=(Get-FileHash "$directory/network-$tag").Hash.ToLowerInvariant()
    }else{
        $sourceHash=(Get-FileHash $path).Hash.ToLowerInvariant()
        $destination="$directory/network-$tag.exe"
        Copy-Item -LiteralPath $path -Destination $destination
        $copiedHash=(Get-FileHash $destination).Hash.ToLowerInvariant()
    }
    if($copiedHash -cne $sourceHash){throw 'Test executable changed during snapshot'}
    foreach($item in @($extracted.occurrences|Where-Object run -CEQ $run)){
        $index=$records.Count+1
        $stdout="$directory/$index.stdout";$stderr="$directory/$index.stderr"
        $list="$directory/$index.list"
        if($Linux){
            & wsl.exe -d Ubuntu-24.04 -- env CARGO_MANIFEST_DIR=/mnt/d/WorksArea/SUPERVM/crates/novovm-network $destination $item.test --exact --list 1> $list 2> "$directory/$index.list.stderr"
        }else{
            $env:CARGO_MANIFEST_DIR='D:/WorksArea/SUPERVM/crates/novovm-network'
            & $destination $item.test --exact --list 1> $list 2> "$directory/$index.list.stderr"
        }
        if($LASTEXITCODE -ne 0 -or (Get-Content $list -Raw) -notmatch '1 test, 0 benchmarks'){throw 'Exact failed test not enumerated'}
        $start=(Get-Date).ToUniversalTime()
        if($Linux){
            & wsl.exe -d Ubuntu-24.04 -- env CARGO_MANIFEST_DIR=/mnt/d/WorksArea/SUPERVM/crates/novovm-network $destination $item.test --exact --test-threads=1 --nocapture 1> $stdout 2> $stderr
        }else{
            & $destination $item.test --exact --test-threads=1 --nocapture 1> $stdout 2> $stderr
        }
        $code=$LASTEXITCODE
        $passed=$code -eq 0 -and (Get-Content $stdout -Raw) -match 'test result: ok\. 1 passed; 0 failed'
        $records+=@{platform=$platform;original_run=$run;test=$item.test;binary_sha256=$copiedHash;features=$tag;isolated_new_process=$true;original_deadlines_and_limits_unchanged=$true;execution_started_at=$start.ToString('o');exit_code=$code;passed=$passed;stdout="$index.stdout";stderr="$index.stderr"}
        Write-Output "$platform isolated $index $($item.test) passed=$passed"
    }
}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($records|ConvertTo-Json -Depth 9))
$file=[IO.File]::Open("$root/isolated-$platform.json",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
Write-Output "Complete $platform isolation; not a rerun/overwrite of original parallel result"
