$ErrorActionPreference='Stop'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'
$base=Join-Path $PSScriptRoot '../udp-recovery-candidate-20261109/Seal.ps1'
$script=Get-Content -LiteralPath $base -Raw
$script=$script.Replace('5181da733d59d998afa898bb9964db5deae9e72c','3fa11f940b18e54b46e6b927d3d66294bea37088')
$script=$script.Replace('novonet-probe-5181da73','novonet-sqlite-3fa11f94')
$script=$script.Replace('$PSScriptRoot',("'"+$delivery+"'"))
& ([scriptblock]::Create($script))
