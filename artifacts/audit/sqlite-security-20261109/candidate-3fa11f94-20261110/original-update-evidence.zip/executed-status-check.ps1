param([Parameter(Mandatory=$true)][ValidateSet('A','B')][string]$HostId,[Parameter(Mandatory=$true)][ValidateSet('before','after')][string]$Phase)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/update-sqlite-3fa11f94-20261110'
$client='D:/WorksArea/SUPERVM/artifacts/product-overlay/novonet-sqlite-3fa11f94-windows-x86_64/bin/novovm-native-client.exe'
if((Get-FileHash -LiteralPath $client).Hash.ToLowerInvariant() -cne '9d8ae5db7532c59f3ae445c8176a66bc0f608d6d97e2133977b2f13065109cc2'){throw 'Fixed operator client changed'}
# Reuse the original independent operator identity, config and reply rule.
$base='D:/WorksArea/SUPERVM/target/novonet-four-host-live-20261108'
$config=if($HostId -ceq 'B'){Join-Path $base 'client-B-capture-41190.json'}else{Join-Path $base 'client-A.json'}
$env:AOEM_DLL_MANIFEST='D:/WorksArea/SUPERVM/artifacts/product-overlay/novonet-08236129-windows-x86_64/aoem/manifest/aoem-manifest.json'
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$out=Join-Path $delivery "authenticated-$HostId-$Phase"
if(Test-Path -LiteralPath $out){throw 'Preserve the original health check; no silent retry'}
New-Item -ItemType Directory -Path $out|Out-Null
& $client $config status 1> "$out/original.json" 2> "$out/original.stderr"
if($LASTEXITCODE -ne 0){throw 'Authenticated native Status failed; preserve output'}
$result=Get-Content -LiteralPath "$out/original.json" -Raw|ConvertFrom-Json
$status=$result.result.answer.Status
$root=[Convert]::ToHexString([byte[]]$status.state_root).ToLowerInvariant()
if($result.scope -cne 'native_sdk_operator_v1' -or $result.chain_id -ne 91129655606029 -or $root -cne 'f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333' -or $status.recovering -or $status.projection_failed -or $status.height -ne 0 -or $status.current_height -ne 1){throw 'Original state/health differs; stop next-host update'}
Write-Output "PASS $HostId $Phase authenticated Status: $($result.elapsed_ms)ms; original root $root; not Object DONE/finality"
