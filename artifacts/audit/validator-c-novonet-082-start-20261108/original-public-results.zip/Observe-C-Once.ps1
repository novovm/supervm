﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$out=Join-Path $root 'C-start-observed'
New-Item -ItemType Directory -Path $out -ErrorAction Stop | Out-Null
$result=[ordered]@{host_id='C';started_utc=(Get-Date).ToUniversalTime().ToString('o');launcher_exit_code=$null;observation_complete=$false}
try {
 $ErrorActionPreference='Continue'
 & 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy RemoteSigned -File (Join-Path $root 'Start-NovonetFixedHost.ps1') -HostId C -PackageRoot (Join-Path $root 'novonet-08236129-windows-x86_64') -InputsRoot (Join-Path $root 'public-inputs') 1> (Join-Path $out 'launcher.stdout') 2> (Join-Path $out 'launcher.stderr')
 $code=$LASTEXITCODE
 $ErrorActionPreference='Stop'
 $result.launcher_exit_code=$code
 if($code -ne 0){throw 'Packaged launcher failed; preserve original state without retry'}
 $work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-08236129-20261108'
 $taskName='NOVOVM-C-08236129-Network-20261108'
 $deadline=(Get-Date).AddSeconds(45)
 do {
  $task=Get-ScheduledTask -TaskName $taskName
  if((Test-Path -LiteralPath (Join-Path $work 'locator.json')) -and (Test-Path -LiteralPath (Join-Path $work 'progress.json'))){break}
  if($task.State -ne 'Running'){break}
  Start-Sleep -Milliseconds 1000
 } while((Get-Date) -lt $deadline)
 $info=Get-ScheduledTaskInfo -TaskName $taskName
 $result['task_state']=[string]$task.State
 $result['last_task_result']=$info.LastTaskResult
 $result['copied_public_files']=@()
 $result['missing_public_files']=@()
 foreach($name in @('owner.json','initialize.stdout','initialize.stderr','locator.json','progress.json','node.stderr')){
  $p=Join-Path $work $name
  if(Test-Path -LiteralPath $p){Copy-Item -LiteralPath $p -Destination (Join-Path $out $name);$result.copied_public_files+=@($name)}else{$result.missing_public_files+=@($name)}
 }
 $result.observation_complete=$true
} catch {$result['error']=$_.Exception.Message}
$result['finished_utc']=(Get-Date).ToUniversalTime().ToString('o')
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'observation.json') -Encoding UTF8
if($result.Contains('error')){exit 1}