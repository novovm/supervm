import collections
import datetime
import hashlib
import ipaddress
import json
from pathlib import Path
import struct

root = Path(__file__).parent
data = (root / 'C-AC-UDP.pcapng').read_bytes()
offset = 0
interfaces = []
packets = []
groups = {}
unsupported = collections.Counter()
while offset < len(data):
    kind, length = struct.unpack_from('<II', data, offset)
    assert length >= 12 and offset + length <= len(data)
    assert struct.unpack_from('<I', data, offset + length - 4)[0] == length
    block = data[offset + 8:offset + length - 4]
    if kind == 0x0A0D0D0A:
        assert block[:4] == b'\x4d\x3c\x2b\x1a'
        interfaces = []
    elif kind == 1:
        link, _, snap = struct.unpack_from('<HHI', block)
        resolution = 1e-6
        option = 8
        while option + 4 <= len(block):
            code, size = struct.unpack_from('<HH', block, option)
            value = block[option + 4:option + 4 + size]
            if code == 9:
                resolution = 2 ** -(value[0] & 127) if value[0] & 128 else 10 ** -value[0]
            if code == 0:
                break
            option += 4 + ((size + 3) // 4) * 4
        interfaces.append((link, resolution))
    elif kind == 6:
        interface, hi, lo, captured, original = struct.unpack_from('<IIIII', block)
        link, resolution = interfaces[interface]
        frame = block[20:20 + captured]
        stamp = ((hi << 32) + lo) * resolution
        if link != 1:
            unsupported[str(link)] += 1
            offset += length
            continue
        cursor = 14
        ether = struct.unpack_from('>H', frame, 12)[0]
        while ether in (0x8100, 0x88a8):
            ether = struct.unpack_from('>H', frame, cursor + 2)[0]
            cursor += 4
        if ether != 0x0800:
            unsupported['non-ipv4'] += 1
            offset += length
            continue
        ip = frame[cursor:]
        assert ip[0] >> 4 == 4 and ip[9] == 17
        assert struct.unpack_from('>H', ip, 6)[0] & 0x3fff == 0, 'IP fragmentation needs separate reassembly'
        source = str(ipaddress.ip_address(ip[12:16]))
        destination = str(ipaddress.ip_address(ip[16:20]))
        udp = ip[(ip[0] & 15) * 4:]
        sport, dport, size = struct.unpack_from('>HHH', udp)
        assert {source, destination} == {'192.168.71.74', '192.168.71.125'}
        assert {sport, dport} == {41051, 41052}
        payload = udp[8:size]
        assert len(payload) == size - 8
        row = dict(utc=datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).isoformat(),
                   source=source, source_port=sport, destination=destination, destination_port=dport,
                   wire_bytes=original, payload_bytes=len(payload), payload_sha256=hashlib.sha256(payload).hexdigest(),
                   magic=payload[:8].decode('ascii', errors='replace'))
        if payload.startswith(b'NVHCONT1') and len(payload) >= 99:
            tag = payload[8]
            transfer = payload[9:25].hex()
            digest = payload[25:57].hex()
            total = int.from_bytes(payload[57:59], 'big')
            row.update(continuation_tag=tag, transfer=transfer, transcript_sha256=digest, transcript_bytes=total)
            key = (source, destination, transfer, digest)
            group = groups.setdefault(key, dict(source=source, destination=destination, transfer=transfer,
                                               transcript_sha256=digest, transcript_bytes=total, parts={}, tags=collections.Counter()))
            group['tags'][str(tag)] += 1
            if tag == 3:
                index = payload[99]
                chunk = payload[100:]
                row['part_index'] = index
                if index in group['parts']:
                    assert group['parts'][index] == chunk, 'conflicting continuation part'
                group['parts'][index] = chunk
        packets.append(row)
    offset += length
transcripts = []
for group in groups.values():
    chunks = group.pop('parts')
    count = (group['transcript_bytes'] + 1023) // 1024
    group['part_indices'] = sorted(chunks)
    group['complete'] = set(chunks) == set(range(count))
    if group['complete']:
        transcript = b''.join(chunks[i] for i in range(count))
        group['digest_matches'] = len(transcript) == group['transcript_bytes'] and hashlib.sha256(transcript).hexdigest() == group['transcript_sha256']
        if group['digest_matches'] and transcript.startswith(b'NVHSHK02'):
            group['message_tag'] = transcript[8]
            group['version'] = int.from_bytes(transcript[9:11], 'big')
            group['suite'] = int.from_bytes(transcript[11:13], 'big')
            group['session_id'] = transcript[13:29].hex()
            group['initiator_peer'] = transcript[29:108].decode('ascii')
            group['responder_peer'] = transcript[108:187].decode('ascii')
    transcripts.append(group)
before = json.loads((root / 'before-progress.json').read_text(encoding='utf-8-sig'))
after = json.loads((root / 'after-progress.json').read_text(encoding='utf-8-sig'))
summary = dict(packet_count=len(packets), unsupported_link_records=dict(unsupported),
               directions=dict(collections.Counter(f"{p['source']}:{p['source_port']} -> {p['destination']}:{p['destination_port']}" for p in packets)),
               magic_counts=dict(collections.Counter(p['magic'] for p in packets)), transcripts=transcripts,
               before_network=before.get('novonet'), after_network=after.get('novonet'),
               authentication_verified_by_offline_parser=False,
               files={p.name: dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir() if p.is_file() and p.suffix in ('.etl', '.pcapng', '.json', '.ps1', '.txt')})
(root / 'packet-metadata.json').write_text(json.dumps(packets, indent=2) + '\n', encoding='utf-8')
(root / 'capture-analysis.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in summary.items() if k not in ('files', 'transcripts')}, indent=2))
print('transcript_groups', len(transcripts))
