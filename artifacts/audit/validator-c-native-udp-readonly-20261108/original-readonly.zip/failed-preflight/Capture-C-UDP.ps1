#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-ddd89e8e-20261108'
$filter='NOVOVM-C-AC-readonly-20261108'
$started=$false
$added=$false
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');duration_seconds=90;expected_pid=23024;capture_started=$false}
function Snapshot($name) {
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=23024'
 if(!$node -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe' -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'C process identity changed'}
 $data=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');pid=$node.ProcessId;exe=$node.ExecutablePath;sha256=(Get-FileHash -LiteralPath $node.ExecutablePath).Hash;listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -eq 23024|Select-Object LocalAddress,LocalPort,OwningProcess)}
 $network=Get-Content -LiteralPath (Join-Path $work 'network.json') -Raw|ConvertFrom-Json
 $data['network_public']=$network|Select-Object bind,peers,udp_bind,udp_peers,public_record_file,local_validator,fallback_after_ms,udp_recovery_ms,retry_ms
 $data|ConvertTo-Json -Depth 30|Set-Content (Join-Path $out "$name.json") -Encoding utf8
 Copy-Item -LiteralPath (Join-Path $work 'logs\progress.json') -Destination (Join-Path $out "$name-progress.json") -ErrorAction Stop
 Copy-Item -LiteralPath (Join-Path $work 'logs\node.stderr') -Destination (Join-Path $out "$name-stderr.txt") -ErrorAction Stop
}
try {
 Snapshot 'before'
 $status=(& pktmon status 2>&1|Out-String);$status|Set-Content (Join-Path $out 'pktmon-before.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon status failed'}
 $sessions=(& logman query -ets 2>&1|Out-String)
 if($sessions -match '(?im)^\s*PktMon\s'){throw 'Existing PktMon session retained; capture not started'}
 $filters=(& pktmon filter list 2>&1|Out-String);$filters|Set-Content (Join-Path $out 'filters-before.txt')
 if($LASTEXITCODE -ne 0 -or $filters -notmatch '没有|No filters|无筛选|未配置'){throw 'Cannot confirm empty PktMon filters; original filters retained'}
 & pktmon filter add $filter -t UDP -i 192.168.71.74 192.168.71.125 -p 41051 41052 *> (Join-Path $out 'filter-add.txt')
 if($LASTEXITCODE -ne 0){throw 'Exact filter add failed'}
 $added=$true
 & pktmon start --capture --comp nics --pkt-size 0 --file-name (Join-Path $out 'C-AC-UDP.etl') --file-size 32 *> (Join-Path $out 'capture-start.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon start failed'}
 $started=$true;$result.capture_started=$true
 Start-Sleep -Seconds 90
 & pktmon counters *> (Join-Path $out 'counters.txt')
 & pktmon stop *> (Join-Path $out 'capture-stop.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon stop failed'}
 $started=$false
 & pktmon etl2pcap (Join-Path $out 'C-AC-UDP.etl') --out (Join-Path $out 'C-AC-UDP.pcapng') *> (Join-Path $out 'convert.txt')
 if($LASTEXITCODE -ne 0){throw 'Pcap conversion failed'}
 Snapshot 'after'
 $result['success']=$true
} catch {$result['success']=$false;$result['error']=$_.Exception.Message}
finally {
 if($started){& pktmon stop *> (Join-Path $out 'cleanup-stop.txt')}
 if($added){& pktmon filter remove $filter *> (Join-Path $out 'filter-remove.txt')}
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'result.json') -Encoding utf8
}
if(!$result.success){exit 1}
