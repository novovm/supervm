#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$out=Join-Path $PSScriptRoot 'A-UDP-counter-compare-20261108'
if(Test-Path $out){throw 'Preserve prior comparison; no rerun'}
New-Item -ItemType Directory -Path $out|Out-Null
$filter='NOVOVM-A-UDP-count-only-20261108'
$added=$false;$started=$false
$result=[ordered]@{started_at=(Get-Date).ToString('o');counters_only=$true;payload_recorded=$false;node_restarted=$false;network_changed=$false;new_object_sent=$false;phases=@()}
try{
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=24444'
 if(!$node -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe' -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Original node owner changed'}
 & pktmon list *> "$out/components.txt"
 if(!(Select-String "$out/components.txt" -Pattern '132\s+5C-B4-7E-BF-78-FE')){throw 'NIC component changed'}
 $sessions=(& logman query -ets 2>&1|Out-String)
 if($sessions -match '(?im)^\s*PktMon\s'){throw 'Existing capture retained'}
 $filters=(& pktmon filter list 2>&1|Out-String);$filters|Set-Content "$out/filters-before.txt"
 if($LASTEXITCODE -ne 0 -or $filters -notmatch '没有|No filters|无筛选|未配置|(?m)^\s*无\s*$'){throw 'Existing filters retained'}
 $phases=@(
  @{name='both-ports';ports=@('41051','41052')},
  @{name='C-port-only';ports=@('41052')},
  @{name='A-port-only';ports=@('41051')},
  @{name='pair-UDP-no-ports';ports=@()},
  @{name='both-ports-repeat';ports=@('41051','41052')}
 )
 foreach($phase in $phases){
  $name=$phase.name;$at=(Get-Date).ToString('o')
  $arguments=@('filter','add',$filter,'-t','UDP','-i','192.168.71.74','192.168.71.125')
  if($phase.ports.Count){$arguments+=@('-p')+$phase.ports}
  & pktmon @arguments *> "$out/$name-filter.txt"
  if($LASTEXITCODE -ne 0){throw 'Filter add failed'};$added=$true
  & pktmon start --capture --counters-only --comp 132 *> "$out/$name-start.txt"
  if($LASTEXITCODE -ne 0){throw 'Counters start failed'};$started=$true
  Start-Sleep -Seconds 10
  & pktmon counters *> "$out/$name-counters.txt"
  if($LASTEXITCODE -ne 0){throw 'Counters read failed'}
  & pktmon stop *> "$out/$name-stop.txt"
  if($LASTEXITCODE -ne 0){throw 'Counters stop failed'};$started=$false
  & pktmon filter remove $filter *> "$out/$name-remove.txt"
  if($LASTEXITCODE -ne 0){throw 'Filter remove failed'};$added=$false
  $result.phases+=@{name=$name;started_at=$at;finished_at=(Get-Date).ToString('o');ports=$phase.ports}
 }
 $result['completed']=$true
}catch{$result['error']=$_.ToString()}
finally{
 if($started){& pktmon stop *> "$out/cleanup-stop.txt"}
 if($added){& pktmon filter remove $filter *> "$out/cleanup-filter.txt"}
 $result['finished_at']=(Get-Date).ToString('o')
 $result|ConvertTo-Json -Depth 8|Set-Content "$out/result.json"
}
