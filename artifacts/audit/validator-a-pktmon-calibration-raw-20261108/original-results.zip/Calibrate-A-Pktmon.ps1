#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$out=Join-Path $PSScriptRoot 'A-pktmon-calibration-raw-20261108'
if(Test-Path $out){throw 'Preserve previous calibration'}
New-Item -ItemType Directory -Path $out|Out-Null
$added=$false;$started=$false;$filter='NOVOVM-A-ICMP-calibration-20261108'
$result=[ordered]@{started_at=(Get-Date).ToString('o');node_restarted=$false;firewall_changed=$false;vpn_changed=$false;novonet_object_sent=$false}
try{
 if((Get-Volume -DriveLetter D).SizeRemaining -lt 2GB){throw 'Insufficient bounded capture space'}
 $adapter=Get-NetAdapter -Name WLAN
 if($adapter.MacAddress -cne '5C-B4-7E-BF-78-FE'){throw 'Original WLAN changed'}
 & pktmon list *> "$out/components.txt"
 if(!(Select-String "$out/components.txt" -Pattern '132\s+5C-B4-7E-BF-78-FE')){throw 'Original observed NIC component changed'}
 $sessions=(& logman query -ets 2>&1|Out-String)
 if($sessions -match '(?im)^\s*PktMon\s'){throw 'Existing capture retained'}
 $filters=(& pktmon filter list 2>&1|Out-String);$filters|Set-Content "$out/filters-before.txt"
 if($LASTEXITCODE -ne 0 -or $filters -notmatch '没有|No filters|无筛选|未配置|(?m)^\s*无\s*$'){throw 'Existing filters retained'}
 & pktmon filter add $filter -t ICMP -i 192.168.71.74 192.168.71.125 *> "$out/filter-add.txt"
 if($LASTEXITCODE -ne 0){throw 'ICMP filter failed'};$added=$true
 & pktmon start --capture --comp 132 --pkt-size 128 --flags 0x010 --file-name "$out/A-ICMP.etl" --file-size 1024 *> "$out/start.txt"
 if($LASTEXITCODE -ne 0){throw 'Calibration capture failed'};$started=$true
 & ping.exe -n 2 -w 1000 192.168.71.125 *> "$out/ping.txt"
 $result['ping_exit_code']=$LASTEXITCODE
 Start-Sleep -Seconds 1
 & pktmon counters *> "$out/counters.txt"
 & pktmon stop *> "$out/stop.txt"
 if($LASTEXITCODE -ne 0){throw 'Calibration stop failed'};$started=$false
 & pktmon etl2pcap "$out/A-ICMP.etl" --out "$out/A-ICMP.pcapng" *> "$out/convert.txt"
 if($LASTEXITCODE -ne 0){throw 'Calibration convert failed'}
 $result['completed']=$true
}catch{$result['error']=$_.ToString()}
finally{
 if($started){& pktmon stop *> "$out/cleanup-stop.txt"}
 if($added){& pktmon filter remove $filter *> "$out/filter-remove.txt"}
 $result['finished_at']=(Get-Date).ToString('o')
 $result|ConvertTo-Json|Set-Content "$out/result.json"
}
