#Requires -Version 7.0
#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$repo='D:\WEB3_AI\SUPERVM'
$out=Join-Path $repo 'target\novonet-5181-update-20261109\C-receive-5181'
if(Test-Path -LiteralPath $out){throw 'Fresh evidence required; existing evidence retained'}
New-Item -ItemType Directory -Path $out|Out-Null
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');success=$false}
function Hex($value) {
 if($null -eq $value){return ''}
 if($value -is [string]){return $value.ToLowerInvariant()}
 return [Convert]::ToHexString([byte[]]$value).ToLowerInvariant()
}
try {
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=34844'
 $expected='C:\ProgramData\NOVOVM\releases\novonet-probe-5181da73-windows-x86_64\bin\novovm-node.exe'
 if(!$node -or $node.ExecutablePath -cne $expected -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Current original C node identity differs'}
 $hash=(Get-FileHash -LiteralPath $node.ExecutablePath).Hash.ToLowerInvariant()
 if($hash -cne 'ff68c5930b9b205b25ba5351a17ad08aa68f51d7cf71779d0507b6269f4087f3'){throw 'Current original C program hash differs'}
 $path='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-5181da73-20261109\logs\progress.json'
 $readUtc=[DateTime]::UtcNow.ToString('o')
 $mtime=(Get-Item -LiteralPath $path).LastWriteTimeUtc.ToString('o')
 $bytes=[IO.File]::ReadAllBytes($path)
 [IO.File]::WriteAllBytes((Join-Path $out 'progress-private-original.json'),$bytes)
 $p=[Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xfeff)|ConvertFrom-Json
 $object='6cdfebd7bf6555c6a60962d3f11a51863d1fe9246dd41fed50f2e5d363de4524'
 $session='624b3e7ba0878c772d60c1ade8ef9212'
 $sender='b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43'
 $recipient='1c054a44ee79b50bf5d059a2f8fc15dd45afcdf8fa10d44a5e12c07afab89a2a'
 $tag='9260805feef25d32b491140a426cddedc48fdf47bbb52d1e75449f6278a153a5'
 $probe=$p.native_network_probe
 $matching=@($probe.events|Where-Object {(Hex $_.object_id) -ceq $object})
 $exact=@($matching|Where-Object {$_.event -ceq 'probe_received_integrity_verified' -and (Hex $_.session_id) -ceq $session -and (Hex $_.sender) -ceq $sender -and (Hex $_.recipient) -ceq $recipient})
 $transport=$probe.transport
 $objects=@($transport.objects|Where-Object {(Hex $_.tag) -ceq $tag})
 $stage=$p.stage_profile.native_delivery
 $stageMatches=@($stage.events|Where-Object {(($_|ConvertTo-Json -Depth 35 -Compress) -match $object) -or (($_|ConvertTo-Json -Depth 35 -Compress) -match $tag) -or ((Hex $_.object_id) -ceq $object) -or ((Hex $_.tag) -ceq $tag)})
 $projection=[ordered]@{
  read_utc=$readUtc;progress_last_write_utc=$mtime;progress_sha256=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
  node=[ordered]@{pid=$node.ProcessId;parent_pid=$node.ParentProcessId;exe=$node.ExecutablePath;sha256=$hash;sid='S-1-5-19';listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -eq $node.ProcessId|Select-Object LocalAddress,LocalPort,OwningProcess)}
  object_id=$object;session_id=$session;transfer_tag=$tag;sender=$sender;recipient=$recipient
  matching_probe_events=$matching;exact_receive_events=$exact
  probe_retention=($probe|Select-Object enabled,scope,max_active,max_events,evicted_events)
  matching_transport_objects=$objects
  transport_coverage=($transport|Select-Object elapsed_us,contended_observations,omitted_records,evicted_records,expired_records)
  receive_totals=$transport.receive_totals;rejection_names=$transport.rejection_names;rejections=$transport.rejections
  stage_native_delivery_retention=($stage|Select-Object enabled,capacity,evicted,contended_events,scope)
  matching_stage_native_delivery_events=$stageMatches
  novonet_present=($null -ne $p.PSObject.Properties['novonet']);novonet=$p.novonet
 }
 $projection|ConvertTo-Json -Depth 85|Set-Content (Join-Path $out 'receive-public.json') -Encoding utf8
 $result['exact_receive_event_count']=$exact.Count
 $result['matching_transport_object_count']=$objects.Count
 $result['matching_stage_event_count']=$stageMatches.Count
 $result.success=$true
} catch {$result['error']=$_.Exception.Message}
finally {
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'result.json') -Encoding utf8
}
if(!$result.success){exit 1}
