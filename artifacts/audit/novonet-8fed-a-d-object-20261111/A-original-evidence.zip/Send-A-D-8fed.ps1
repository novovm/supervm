#Requires -Version 7.0
#Requires -RunAsAdministrator
# One original-owner diagnostic object; never opens a socket or submits assets.
param([Parameter(Mandatory)][string]$ReceiverReadyFile,[Parameter(Mandatory)][string]$EvidenceRoot)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference=$false
$out=[IO.Path]::GetFullPath($EvidenceRoot)
if(Test-Path -LiteralPath $out){throw 'Fresh evidence directory required; do not resend'}
$ready=Get-Content -LiteralPath $ReceiverReadyFile -Raw|ConvertFrom-Json
if($ready.status -cne 'D_RECEIVER_ARMED' -or $ready.source -cne '8fed4b76' -or !$ready.read_only){throw 'D collector readiness required'}
$work='C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-observation-8fed4b76-20261110'
$root='C:/ProgramData/NOVOVM/releases/novonet-observation-8fed4b76-windows-x86_64'
$command="$work/commands/control.nvprobe"
if(Test-Path -LiteralPath $command){throw 'Command slot occupied; inspect without overwrite'}
if((Get-FileHash "$root/bin/novovm-node.exe").Hash.ToLowerInvariant() -cne '021e7f8b0b41d8b72577d7394cd9c1fb9edb8388c4ae90903dca6f86a53a8a32' -or (Get-FileHash "$root/bin/novovmctl.exe").Hash.ToLowerInvariant() -cne '6201c4a18a7fa8cdd176cb9715ceedfe6912e8538761aefc263140a4506d77ec'){throw 'Fixed program differs'}
$nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"|Where-Object ExecutablePath -IEQ "$root/bin/novovm-node.exe".Replace('/','\'))
if($nodes.Count -ne 1 -or (Invoke-CimMethod $nodes[0] -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Live original A owner required'}
function Hex($Bytes){[Convert]::ToHexString([byte[]]$Bytes).ToLowerInvariant()}
$config=Get-Content "$work/run.json" -Raw|ConvertFrom-Json
$net=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
if($net.probe_control_file.Replace('\','/') -cne $command){throw 'Original command owner differs'}
$before=Get-Content "$work/logs/progress.json" -Raw|ConvertFrom-Json
if($before.chain_id -ne 91129655606029 -or $before.execution_failures -ne 0 -or ((Get-Date)-(Get-Item "$work/logs/progress.json").LastWriteTime).TotalSeconds -gt 30){throw 'A progress not healthy/current'}
$ids=@(0,3|ForEach-Object {Hex ([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("novovm-round-bft/v2/mldsa65/validator-id`0")+[byte[]]$config.genesis.validators[$_].public_key)))})
if($ids[0] -cne 'b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43'){throw 'Wrong A identity'}
New-Item -ItemType Directory -Path $out|Out-Null
$before.native_network_probe|ConvertTo-Json -Depth 60|Set-Content "$out/sender-before.json" -Encoding utf8
Copy-Item -LiteralPath $ReceiverReadyFile -Destination "$out/receiver-ready.json"
# This is an observation-window coordination check, not protocol validity.
if(([DateTime]::UtcNow-([DateTime]$ready.utc).ToUniversalTime()).TotalSeconds -ge 1740){throw 'Receiver observation window too old; do not send'}
& "$root/bin/novovmctl.exe" native-network-probe prepare --sender $ids[0] --recipient $ids[1] --output $command 1> "$out/command.json" 2> "$out/command.stderr"
if($LASTEXITCODE -ne 0){throw 'Original command preparation failed; do not retry'}
Copy-Item -LiteralPath $command -Destination "$out/command-raw.nvprobe"
$prepared=Get-Content "$out/command.json" -Raw|ConvertFrom-Json
$nonce=Hex $prepared.data.nonce
$clock=[Diagnostics.Stopwatch]::StartNew()
do {
    Start-Sleep -Milliseconds 500
    $after=Get-Content "$work/logs/progress.json" -Raw|ConvertFrom-Json
    $events=@($after.native_network_probe.events|Where-Object {(Hex $_.nonce) -ceq $nonce})
    $terminal=@($events|Where-Object {$_.event -ceq 'probe_object_done' -or $_.event -match 'expired|rejected|cancelled'})
}while(!$terminal.Count -and $clock.Elapsed.TotalSeconds -lt 30)
$done=@($events|Where-Object event -CEQ 'probe_object_done')
[ordered]@{utc=[DateTime]::UtcNow.ToString('o');source='8fed4b76';sender='A';recipient='D';pid=$nodes[0].ProcessId;nonce=$nonce;events=$events;native_network_probe=$after.native_network_probe;sender_done=($done.Count -eq 1);receiver_evidence_required=$true;business_receipt=$false;execution_failures=$after.execution_failures;node_restarted=$false}|ConvertTo-Json -Depth 60|Set-Content "$out/sender-result.json" -Encoding utf8
if($done.Count -ne 1){throw 'No sender DONE; retain first failure, do not resend'}
Write-Output "A->D sender DONE object=$(Hex $done[0].object_id) session=$(Hex $done[0].session_id) path=$($done[0].path); receiver acceptance pending"
