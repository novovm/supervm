$ErrorActionPreference='Stop'
$base='D:\WorksArea\SUPERVM\target\native-time-upgrade-20261110'
$record=Join-Path $base 'A-D-send-exit-20261111.json'
if(Test-Path -LiteralPath $record){throw 'Preserve previous attempt; no resend'}
$r=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');exit_code=1}
try {
    & "$base\Send-A-D-8fed.ps1" -ReceiverReadyFile 'D:\WorksArea\SUPERVM\artifacts\audit\validator-d-8fed-receiver-armed-20261111\ready.json' -EvidenceRoot "$base\A-D-object-20261111" *> "$base\A-D-send-20261111.log"
    $r.exit_code=0
}catch{$r.error=$_.Exception.Message}
$r.completed_utc=[DateTime]::UtcNow.ToString('o')
$r|ConvertTo-Json|Set-Content -LiteralPath $record -Encoding utf8
exit $r.exit_code
