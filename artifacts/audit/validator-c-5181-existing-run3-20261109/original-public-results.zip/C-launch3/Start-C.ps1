#Requires -Version 7.0
#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$repo='D:\WEB3_AI\SUPERVM'
$out=Join-Path $repo 'target\novonet-5181-update-20261109\C-run3'
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-5181da73-20261109'
$updater=Join-Path $repo 'scripts\windows\Update-Novonet5181Existing.ps1'
$package='E:\区块链四机通讯\novonet-5181-update-20261109\novonet-probe-5181da73-windows-x86_64'
$result=[ordered]@{host_id='C';run='C-run3';started_utc=[DateTime]::UtcNow.ToString('o');update_success=$false;observation_completed=$false}
try {
 if(Test-Path -LiteralPath $out){throw 'C-run3 already exists; preserve evidence'}
 if((Get-FileHash -LiteralPath $updater).Hash -cne '86D2E818ACC5ABD403B8D5987CBD564E79E957840976582F650AF99E53148CD3'){throw 'Reviewed fixed updater changed'}
 & $updater -HostId C -PackageRoot $package -EvidenceRoot $out -RecoverCrashed *> (Join-Path $PSScriptRoot 'update-output.txt')
 $u=Get-Content -LiteralPath "$out/result.json" -Raw|ConvertFrom-Json
 if(!$u.update_completed){throw 'Fixed updater completion missing'}
 $result.update_success=$true;$result['pid']=$u.pid
 $result['observation_started_utc']=[DateTime]::UtcNow.ToString('o')
 $deadline=[DateTime]::UtcNow.AddSeconds(120)
 $stream=[IO.File]::Open("$out/recovery-samples.jsonl",[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 $writer=[IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($false))
 $index=0
 try {
  do {
   $row=[ordered]@{index=$index;utc=[DateTime]::UtcNow.ToString('o');read_ok=$false}
   try {
    $path=Join-Path $work 'logs\progress.json'
    $row['file_last_write_utc']=(Get-Item -LiteralPath $path).LastWriteTimeUtc.ToString('o')
    $p=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
    $t=$p.native_network_probe.transport
    foreach($name in @('head','current_height','round','ticks','execution_failures','novonet')){$row[$name]=$p.$name}
    foreach($name in @('udp_recovery_event_names','udp_recovery','udp_recovery_omitted','contended_observations')){$row[$name]=$t.$name}
    $row.read_ok=$true
   } catch {$row['error']=$_.Exception.Message}
   $writer.WriteLine(($row|ConvertTo-Json -Depth 60 -Compress));$writer.Flush()
   $index++
   if([DateTime]::UtcNow -ge $deadline){break}
   Start-Sleep -Seconds 5
  } while($true)
 } finally {$writer.Dispose()}
 $result['sample_count']=$index
 $result['observation_finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result.observation_completed=$true
 $before=Get-Content -LiteralPath "$out/before.json" -Raw|ConvertFrom-Json
 $after=Get-Content -LiteralPath "$out/after.json" -Raw|ConvertFrom-Json
 $before|Select-Object host_id,time,pid,exe,node_sha256,sid,database,custody_sha256,firewall_profiles,progress_age_seconds,prior_owner_crashed,crash|ConvertTo-Json -Depth 40|Set-Content "$out/before-public.json" -Encoding utf8
 $after|Select-Object host_id,time,source,pid,exe,node_sha256,sid,database,start,initialize_executed,keys_generated,custody_unchanged,aoem_module,aoem_sha256,old_task,new_task,prior_owner_crashed,terminated_process_observations,listeners,new_command_file_present|ConvertTo-Json -Depth 40|Set-Content "$out/after-public.json" -Encoding utf8
 [ordered]@{configured_peers=$before.config.peers;network_peer_records=$before.network.peer_records;discovery=$before.network.discovery;discovery_seeds=$before.network.discovery_seeds}|ConvertTo-Json -Depth 45|Set-Content "$out/peer-map-public.json" -Encoding utf8
 Copy-Item -LiteralPath "$work/logs/owner.json" -Destination "$out/owner-public.json"
 Copy-Item -LiteralPath "$work/logs/node.stderr" -Destination "$out/node-stderr.txt"
 $result['final_processes']=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"|Select-Object ProcessId,ParentProcessId,ExecutablePath)
} catch {$result['error']=$_.Exception.Message}
finally {
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json -Depth 30|Set-Content (Join-Path $PSScriptRoot 'operation-result.json') -Encoding utf8
}
if($result.Contains('error')){exit 1}
