## CI scope: sync

Source synchronization only; product/platform/security tests NOT EXECUTED. Not release qualification.
