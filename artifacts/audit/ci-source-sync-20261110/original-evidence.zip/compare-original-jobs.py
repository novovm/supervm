"""Read-only comparison of original product jobs against the input commit."""
import json
from pathlib import Path
import re
import subprocess

baseline = "5c6a6b48db817f7ef2f9dd6c759698a7083423c6"
workflow = ".github/workflows/ci.yml"
old = subprocess.check_output(["git", "show", f"{baseline}:{workflow}"]).decode()
new = Path(workflow).read_text(encoding="utf-8")
pattern = r"^  (\w+):\n(.*?)(?=^  \w+:\n|\Z)"
before = dict(re.findall(pattern, old.split("\njobs:\n", 1)[1], re.M | re.S))
after = dict(re.findall(pattern, new.split("\njobs:\n", 1)[1], re.M | re.S))
preserved = sorted(set(before) - {"detect", "result"})
for name in preserved:
    assert before[name] == after[name], name
auth = ".github/workflows/native-auth-relation.yml"
old_auth = subprocess.check_output(["git", "show", f"{baseline}:{auth}"]).decode()
new_auth = Path(auth).read_text(encoding="utf-8")
assert old_auth.split("jobs:\n", 1)[1] == new_auth.split("jobs:\n", 1)[1]
print(json.dumps({"baseline": baseline, "original_jobs_byte_equal": preserved,
                  "native_auth_job_byte_equal": True, "changed_product_code": False}))
