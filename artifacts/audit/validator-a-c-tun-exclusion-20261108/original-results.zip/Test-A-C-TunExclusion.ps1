$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'A-C-tun-exclusion-20261108'
if(Test-Path $out){throw 'Preserve prior attempt; no automatic rerun'}
New-Item -ItemType Directory -Path $out|Out-Null
$uri='http://127.0.0.1:39798/configs'
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\A\novonet-probe-ddd89e8e-20261108'
$changed=$false;$original=$null
$result=[ordered]@{started_at=(Get-Date).ToString('o');approved_exclusion='192.168.71.125/32';node_restarted=$false;firewall_changed=$false;new_object_sent=$false}
function Snapshot($name){
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=24444'
 if(!$node -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19' -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe'){throw 'Original A owner changed'}
 Copy-Item "$work/logs/progress.json" "$out/$name-progress.json"
 Find-NetRoute -RemoteIPAddress 192.168.71.125|Select-Object InterfaceAlias,InterfaceIndex,IPAddress,DestinationPrefix,NextHop,RouteMetric|ConvertTo-Json|Set-Content "$out/$name-route.json"
 [ordered]@{at=(Get-Date).ToString('o');pid=$node.ProcessId;sid='S-1-5-19'}|ConvertTo-Json|Set-Content "$out/$name-owner.json"
}
try{
 Snapshot 'before'
 $original=Invoke-RestMethod -Uri $uri -NoProxy -TimeoutSec 5
 [ordered]@{mode=$original.mode;tun=$original.tun}|ConvertTo-Json -Depth 12|Set-Content "$out/tun-before.json"
 if(!$original.tun.enable -or $original.tun.device -cne 'Meta'){throw 'Expected original enabled Meta TUN missing'}
 $tun=($original.tun|ConvertTo-Json -Depth 12)|ConvertFrom-Json
 $existing=@($original.tun.'route-exclude-address'|Where-Object {$_})
 if($existing -contains '192.168.71.125/32'){throw 'Exclusion already present; not an independent intervention'}
 $tun|Add-Member -NotePropertyName 'route-exclude-address' -NotePropertyValue @($existing+'192.168.71.125/32') -Force
 $body=@{tun=$tun}|ConvertTo-Json -Depth 12 -Compress
 $changed=$true
 Invoke-RestMethod -Method Patch -Uri $uri -NoProxy -TimeoutSec 10 -ContentType 'application/json' -Body $body|Out-Null
 $effective=Invoke-RestMethod -Uri $uri -NoProxy -TimeoutSec 5
 [ordered]@{mode=$effective.mode;tun=$effective.tun}|ConvertTo-Json -Depth 12|Set-Content "$out/tun-effective.json"
 if(!$effective.tun.enable -or $effective.mode -cne $original.mode){throw 'Unexpected mode or enabled change; restore immediately'}
 if(@($effective.tun.'route-exclude-address') -notcontains '192.168.71.125/32'){throw 'Runtime API does not confirm requested exclusion; no effective-bypass claim'}
 $result['exclusion_readback_verified']=$true
 Start-Sleep -Seconds 40
 Snapshot 'during'
 $result['observation_completed']=$true
}catch{$result['error']=$_.ToString()}
finally{
 if($changed -and $original){
  try{
   $restore=($original.tun|ConvertTo-Json -Depth 12)|ConvertFrom-Json
   if(!$restore.PSObject.Properties['route-exclude-address']){$restore|Add-Member -NotePropertyName 'route-exclude-address' -NotePropertyValue @()}
   Invoke-RestMethod -Method Patch -Uri $uri -NoProxy -TimeoutSec 10 -ContentType 'application/json' -Body (@{tun=$restore}|ConvertTo-Json -Depth 12 -Compress)|Out-Null
   $after=Invoke-RestMethod -Uri $uri -NoProxy -TimeoutSec 5
   [ordered]@{mode=$after.mode;tun=$after.tun}|ConvertTo-Json -Depth 12|Set-Content "$out/tun-restored.json"
   if($after.mode -cne $original.mode -or $after.tun.enable -ne $original.tun.enable -or (@($after.tun.'route-exclude-address'|Where-Object {$_}) -join ',') -cne ($existing -join ',')){throw 'Original TUN state readback differs'}
   $result['restoration_readback_verified']=$true
  }catch{$result['restore_error']=$_.ToString()}
 }
 try{Snapshot 'after'}catch{$result['after_snapshot_error']=$_.ToString()}
 $result['finished_at']=(Get-Date).ToString('o')
 $result|ConvertTo-Json -Depth 8|Set-Content "$out/result.json"
}
