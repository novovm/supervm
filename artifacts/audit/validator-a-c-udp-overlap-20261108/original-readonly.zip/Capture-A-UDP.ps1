#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$out=Join-Path $PSScriptRoot 'A-UDP-overlap-20261108'
if(Test-Path $out){throw 'Preserve existing capture; no automatic rerun'}
New-Item -ItemType Directory -Path $out|Out-Null
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\A\novonet-probe-ddd89e8e-20261108'
$filter='NOVOVM-A-AC-readonly-20261108'
$started=$false;$added=$false
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');max_seconds=40;read_only_node=$true;new_object_sent=$false;node_restarted=$false}
function Snapshot($name){
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=24444'
 if(!$node -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe' -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Original A owner changed'}
 if((Get-FileHash $node.ExecutablePath).Hash.ToLowerInvariant() -cne '19883c8b95fc059ec7838ff0556284b1ddd434b7a72bfbe93e3f3410f458a0fc'){throw 'Fixed node differs'}
 [ordered]@{utc=[DateTime]::UtcNow.ToString('o');pid=$node.ProcessId;exe=$node.ExecutablePath;listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -eq 24444|Select-Object LocalAddress,LocalPort,OwningProcess)}|ConvertTo-Json -Depth 6|Set-Content "$out/$name.json"
 Copy-Item "$work/logs/progress.json" "$out/$name-progress.json"
 Copy-Item "$work/logs/node.stderr" "$out/$name-stderr.txt"
}
try{
 Snapshot 'before'
 & pktmon status *> "$out/status-before.txt"
 $sessions=(& logman query -ets 2>&1|Out-String)
 if($sessions -match '(?im)^\s*PktMon\s'){throw 'Existing capture retained; no changes'}
 $filters=(& pktmon filter list 2>&1|Out-String);$filters|Set-Content "$out/filters-before.txt"
 if($LASTEXITCODE -ne 0 -or $filters -notmatch '没有|No filters|无筛选|未配置|(?m)^\s*无\s*$'){throw 'Cannot confirm empty filters; no changes'}
 & pktmon filter add $filter -t UDP -i 192.168.71.74 192.168.71.125 -p 41051 41052 *> "$out/filter-add.txt"
 if($LASTEXITCODE -ne 0){throw 'Exact filter failed'};$added=$true
 & pktmon start --capture --comp nics --pkt-size 0 --file-name "$out/A-AC-UDP.etl" --file-size 64 *> "$out/start.txt"
 if($LASTEXITCODE -ne 0){throw 'Capture start failed'};$started=$true
 $end=(Get-Date).AddSeconds(40)
 do{Start-Sleep -Milliseconds 500; if((Get-Item "$out/A-AC-UDP.etl").Length -gt 16MB){$result['size_bound_reached']=$true;break}}while((Get-Date) -lt $end)
 & pktmon counters *> "$out/counters.txt"
 & pktmon stop *> "$out/stop.txt"
 if($LASTEXITCODE -ne 0){throw 'Capture stop failed'};$started=$false
 & pktmon etl2pcap "$out/A-AC-UDP.etl" --out "$out/A-AC-UDP.pcapng" *> "$out/convert.txt"
 if($LASTEXITCODE -ne 0){throw 'Convert failed'}
 Snapshot 'after'
 $result['success']=$true
}catch{$result['success']=$false;$result['error']=$_.ToString()}
finally{
 if($started){& pktmon stop *> "$out/cleanup-stop.txt"}
 if($added){& pktmon filter remove $filter *> "$out/filter-remove.txt"}
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json|Set-Content "$out/result.json"
}
