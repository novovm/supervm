﻿$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$started=(Get-Date).ToUniversalTime().ToString('o')
& 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy RemoteSigned -File (Join-Path $root 'Install-Selfrun-Windows-20261106.ps1') -HostId C -PackageRoot (Join-Path $root 'selfrun-9a6153f1-windows-x86_64') 1> (Join-Path $root 'c-installer.stdout.txt') 2> (Join-Path $root 'c-installer.stderr.txt')
$code=$LASTEXITCODE
[ordered]@{started_utc=$started;finished_utc=(Get-Date).ToUniversalTime().ToString('o');exit_code=$code;host_id='C'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'c-launch-result.json') -Encoding UTF8
exit $code