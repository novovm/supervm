#Requires -Version 7.0
#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$base='D:\WEB3_AI\SUPERVM\target\novonet-1ef31893-C-preflight-20261110'
$tool=Join-Path $base 'tools\Update-CD.ps1'
$out=Join-Path $base 'C-run1'
$report=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');success=$false}
try {
 if((Get-FileHash -LiteralPath $tool).Hash -cne 'C2E954AE34DB3B4C67F717A7E9DC5DDE9DD8000EF35CD61E3346A4315EB4C33A'){throw 'Reviewed fixed tool changed'}
 . (Join-Path $base 'tools\NovonetExistingProcess.ps1')
 $task=Get-ScheduledTask -TaskName 'NOVOVM-C-5181da73-Existing-20261109'
 $info=Get-ScheduledTaskInfo -TaskName $task.TaskName
 $execution=Get-NovonetNodeExecutionState
 [ordered]@{utc=[DateTime]::UtcNow.ToString('o');task_state=$task.State.ToString();last_result=$info.LastTaskResult;last_run=$info.LastRunTime;execution=$execution}|ConvertTo-Json -Depth 30|Set-Content (Join-Path $PSScriptRoot 'state-before.json') -Encoding utf8
 $args=@{HostId='C';PackageRoot='E:\区块链四机通讯\novonet-1ef31893-C-20261110\novonet-observation-1ef31893-windows-x86_64';EvidenceRoot=$out}
 if($task.State -eq 'Ready' -and [uint32]$info.LastTaskResult -eq 0){$args.ResumeStopped=$true;$report['selected_branch']='ResumeStopped'}
 elseif($task.State -eq 'Ready' -and [uint32]$info.LastTaskResult -eq 3221225477){$args.RecoverCrashed=$true;$report['selected_branch']='RecoverCrashed'}
 elseif($task.State -eq 'Running'){$report['selected_branch']='live_existing'}
 else{throw 'Original task state not supported by fixed guards'}
 & $tool @args *> (Join-Path $PSScriptRoot 'update-output.txt')
 $r=Get-Content -LiteralPath "$out/result.json" -Raw|ConvertFrom-Json
 if(!$r.update_completed){throw 'Fixed updater did not complete'}
 $before=Get-Content -LiteralPath "$out/before.json" -Raw|ConvertFrom-Json
 $after=Get-Content -LiteralPath "$out/after.json" -Raw|ConvertFrom-Json
 $before|Select-Object host_id,time,pid,exe,node_sha256,sid,database,custody_sha256,progress_age_seconds,prior_owner_crashed,prior_owner_cleanly_stopped,crash,firewall_profiles|ConvertTo-Json -Depth 40|Set-Content "$out/before-public.json" -Encoding utf8
 $after|Select-Object * -ExcludeProperty progress|ConvertTo-Json -Depth 40|Set-Content "$out/after-public.json" -Encoding utf8
 $work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-observation-1ef31893-20261110'
 $snapshots=@(foreach($index in 0..2){
  if($index){Start-Sleep -Seconds 5}
  $p=Get-Content -LiteralPath "$work/logs/progress.json" -Raw|ConvertFrom-Json
  [ordered]@{utc=[DateTime]::UtcNow.ToString('o');last_write=(Get-Item -LiteralPath "$work/logs/progress.json").LastWriteTimeUtc.ToString('o');progress=$p}
 })
 $snapshots|ConvertTo-Json -Depth 85|Set-Content "$out/progress-public.json" -Encoding utf8
 $config=Get-Content -LiteralPath "$work/network.json" -Raw|ConvertFrom-Json
 Copy-Item -LiteralPath $config.public_record_file -Destination "$out/locator-public.json"
 Copy-Item -LiteralPath "$work/logs/node.stderr" -Destination "$out/node-stderr.txt"
 Copy-Item -LiteralPath "$work/logs/owner.json" -Destination "$out/owner-public.json"
 $report.success=$true;$report['pid']=$r.pid;$report['status']='C_1EF_EXISTING_READY_FOR_A_QUERY'
} catch {$report['error']=$_.Exception.Message}
finally {$report['finished_utc']=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 15|Set-Content (Join-Path $PSScriptRoot 'operation-result.json') -Encoding utf8}
if(!$report.success){exit 1}
