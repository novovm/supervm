#Requires -Version 7.0
#Requires -RunAsAdministrator
param([Parameter(Mandatory=$true)][ValidateSet('C','D')][string]$Recipient)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$PSNativeCommandUseErrorActionPreference=$false
$work='C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-observation-1ef31893-20261110'
$root='C:/ProgramData/NOVOVM/releases/novonet-observation-1ef31893-windows-x86_64'
$out=Join-Path $PSScriptRoot "A-$Recipient"
$command="$work/commands/control.nvprobe"
$previous=if($Recipient -ceq 'C'){'C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110/update-tools/actual-A-B-1ef'}else{Join-Path $PSScriptRoot 'A-C'}
if(Test-Path -LiteralPath $out){throw 'Evidence already exists; do not resend'}
function Hex($Bytes){[Convert]::ToHexString([byte[]]$Bytes).ToLowerInvariant()}
$nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"|Where-Object {$_.ExecutablePath -ieq "$root/bin/novovm-node.exe".Replace('/','\')})
if($nodes.Count -ne 1 -or (Invoke-CimMethod $nodes[0] -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Original A owner not confirmed'}
if((Get-FileHash "$root/bin/novovm-node.exe").Hash -ine 'd419df614d6b804136eca82fd7427d84155241c82b7f74c3c00bf2fdb3ea6087' -or (Get-FileHash "$root/bin/novovmctl.exe").Hash -ine '00955e09f3f610df00745ade00f8438d2cb650ab721ed88854efefafe3e1a730'){throw 'Fixed program differs'}
$config=Get-Content "$work/run.json" -Raw|ConvertFrom-Json
$net=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
if($net.probe_control_file.Replace('\','/') -cne $command){throw 'Command owner differs'}
$before=Get-Content "$work/logs/progress.json" -Raw|ConvertFrom-Json
if($before.chain_id -ne 91129655606029 -or $before.execution_failures -ne 0 -or ((Get-Date)-(Get-Item "$work/logs/progress.json").LastWriteTime).TotalSeconds -gt 30){throw 'A not live/healthy'}
$previousCommand=Get-Content "$previous/command.json" -Raw|ConvertFrom-Json
$priorNonce=Hex $previousCommand.data.nonce
$priorDone=@($before.native_network_probe.events|Where-Object {$_.event -ceq 'probe_object_done' -and (Hex $_.nonce) -ceq $priorNonce})
if($priorDone.Count -ne 1 -or $previousCommand.data.expires_at_ms -ge [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()){throw 'Previous command has not completed and expired'}
if((Get-Item -LiteralPath $command).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Redirected command'}
if((Get-FileHash -LiteralPath $command).Hash -cne (Get-FileHash -LiteralPath "$previous/command-raw.nvprobe").Hash){throw 'Command slot no longer matches archived completed command'}
$index=if($Recipient -ceq 'C'){2}else{3}
$ids=@(0,$index|ForEach-Object {Hex ([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("novovm-round-bft/v2/mldsa65/validator-id`0")+[byte[]]$config.genesis.validators[$_].public_key)))})
if($ids[0] -cne 'b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43'){throw 'A identity differs'}
New-Item -ItemType Directory -Path $out|Out-Null
Copy-Item -LiteralPath "$work/logs/progress.json" -Destination "$out/A-before.json"
# Retain the exact expired and completed command; never overwrite pending work.
Move-Item -LiteralPath $command -Destination "$out/previous-command.nvprobe"
& "$root/bin/novovmctl.exe" native-network-probe prepare --sender $ids[0] --recipient $ids[1] --output $command 1> "$out/command.json" 2> "$out/command.stderr"
if($LASTEXITCODE -ne 0){throw 'Original ctl failed; preserve evidence and do not retry'}
Copy-Item -LiteralPath $command -Destination "$out/command-raw.nvprobe"
$prepared=Get-Content "$out/command.json" -Raw|ConvertFrom-Json
$nonce=Hex $prepared.data.nonce
Start-Sleep -Seconds 13
Copy-Item -LiteralPath "$work/logs/progress.json" -Destination "$out/A-after.json"
$after=Get-Content "$out/A-after.json" -Raw|ConvertFrom-Json
$events=@($after.native_network_probe.events|Where-Object {(Hex $_.nonce) -ceq $nonce})
$done=@($events|Where-Object event -CEQ 'probe_object_done')
[ordered]@{utc=[DateTime]::UtcNow.ToString('o');source='1ef3189307382ef579775c7ce2b55a08d829d04a';sender='A';recipient=$Recipient;pid=$nodes[0].ProcessId;nonce=$nonce;events=$events;sender_done=($done.Count -eq 1);receiver_evidence_required=$true;business_receipt=$false;execution_failures=$after.execution_failures;previous_completed_command_archived=$true;node_restarted=$false}|ConvertTo-Json -Depth 30|Set-Content "$out/result.json" -Encoding utf8NoBOM
if($done.Count -ne 1){throw 'No sender DONE for this command; preserve first failure, do not resend'}
Write-Output "A->$Recipient sender DONE; object=$(Hex $done[0].object_id); session=$(Hex $done[0].session_id); path=$($done[0].path); receiver evidence pending"
