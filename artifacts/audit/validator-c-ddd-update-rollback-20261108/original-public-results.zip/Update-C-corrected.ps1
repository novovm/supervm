﻿param([switch]$Owner,[switch]$Rollback,[switch]$ResumePrepared)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$out=$PSScriptRoot
$state='C:\ProgramData\NOVOVM\selfrun\91129655606029\C'
$oldWork=Join-Path $state 'novonet-08236129-20261108'
$work=Join-Path $state 'novonet-probe-ddd89e8e-20261108'
$oldRelease='C:\ProgramData\NOVOVM\releases\novonet-08236129-windows-x86_64'
$release='C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64'
$taskName='NOVOVM-C-ddd89e8e-Existing-20261108'
$rollbackTask='NOVOVM-C-08236129-Existing-Rollback-20261108'
$core='1b764a36c1f782425237d40446d4ea827f56a66fb341b870855d84c15acdce50'
function Write-NewJson([string]$Path,$Value){
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 85))
    $file=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
}
function Assert-Package([string]$Root){
    if((Get-FileHash "$Root/release-manifest.json").Hash.ToLowerInvariant() -cne 'badaf819c3a8cc03a0e4e200d45f9f37a15c1c34937b3482b3940b6491c83d1f'){throw 'Candidate manifest differs'}
    $m=Get-Content "$Root/release-manifest.json" -Raw|ConvertFrom-Json
    if($m.git_commit -cne 'ddd89e8e05721a2ddb8a7ae9255405d395b39a46' -or $m.artifacts.Count -ne 77){throw 'Candidate source/count differs'}
    foreach($entry in $m.artifacts){
        $p=[IO.Path]::GetFullPath((Join-Path $Root $entry.path));$item=Get-Item -LiteralPath $p -Force
        if(!$p.StartsWith($Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase) -or $item.Length -ne $entry.bytes -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or (Get-FileHash $p).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'Candidate member differs'}
    }
}
function Set-OwnerAcl([string]$Path,[switch]$Writable){
    $item=Get-Item -LiteralPath $Path -Force
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Refuse redirected installation path'}
    $acl=if($item.PSIsContainer){[Security.AccessControl.DirectorySecurity]::new()}else{[Security.AccessControl.FileSecurity]::new()}
    $acl.SetAccessRuleProtection($true,$false)
    foreach($sid in @('S-1-5-18','S-1-5-32-544','S-1-5-19')){
        $rights=if($sid -ceq 'S-1-5-19'){if($Writable){[Security.AccessControl.FileSystemRights]::Modify}else{[Security.AccessControl.FileSystemRights]::ReadAndExecute}}else{[Security.AccessControl.FileSystemRights]::FullControl}
        $inherit=if($item.PSIsContainer){[Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'}else{[Security.AccessControl.InheritanceFlags]::None}
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sid),$rights,$inherit,[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}
function Custody-Hashes($config,$network){
    $keys=@{};foreach($p in @($config.signing_key_file,$config.transport_key_file,$network.carrier_identity_file)){$keys[$p]=(Get-FileHash -LiteralPath $p).Hash.ToLowerInvariant()};return $keys
}
function Register-ExistingTask([string]$Name,[switch]$Old){
    if(Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue){throw 'Task already exists; no repeat start'}
    $args='-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "'+(Join-Path $work 'ExistingOwner.ps1')+'" -Owner'
    if($Old){$args+=' -Rollback'}
    $action=New-ScheduledTaskAction -Execute 'C:\Program Files\PowerShell\7\pwsh.exe' -Argument $args
    $principal=New-ScheduledTaskPrincipal -UserId 'NT AUTHORITY\LOCAL SERVICE' -LogonType ServiceAccount
    $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 24 -Minutes 3) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $Name -Action $action -Principal $principal -Settings $settings|Out-Null
    Start-ScheduledTask -TaskName $Name
}
if($Owner){
    if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne 'S-1-5-19'){throw 'Actual LocalService required'}
    $root=if($Rollback){$oldRelease}else{$release}
    $configPath=if($Rollback){Join-Path $oldWork 'run.json'}else{Join-Path $work 'run.json'}
    $logs=if($Rollback){Join-Path $work 'rollback-logs'}else{Join-Path $work 'logs'}
    $config=Get-Content $configPath -Raw|ConvertFrom-Json
    if($config.database -cne (Join-Path $state 'chain-state') -or !(Test-Path $config.database -PathType Container)){throw 'Original database required; never initialize'}
    if((Get-FileHash $config.library).Hash.ToLowerInvariant() -cne $core){throw 'AOEM mismatch'}
    if(!$Rollback){Assert-Package $root}
    Write-NewJson "$logs/owner.json" ([ordered]@{sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;start='existing';config=$configPath;database=$config.database;initialize_executed=$false;keys_generated=$false})
    $env:AOEM_DLL_MANIFEST=Join-Path $root 'aoem\manifest\aoem-manifest.json';$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST;$env:AOEM_DLL_MANIFEST_REQUIRED='1';$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='1'
    $env:NOVOVM_NODE_MODE='native_execution_tick';$env:NOVOVM_NATIVE_EXECUTION_CONFIG=$configPath;$env:NOVOVM_NATIVE_EXECUTION_START='existing';$env:NOVOVM_NATIVE_EXECUTION_RUN_MS='86400000';$env:NOVOVM_NATIVE_EXECUTION_PIPELINE_PROGRESS_REPORT_PATH=Join-Path $logs 'progress.json'
    & "$root/bin/novovm-node.exe" 1> "$logs/node.stdout" 2> "$logs/node.stderr"
    $code=$LASTEXITCODE
    Write-NewJson "$logs/exit.json" ([ordered]@{exit_code=$code;start='existing';time=(Get-Date).ToString('o')})
    exit $code
}
$principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator required'}
if($Rollback){
    if((Get-FileHash "$oldRelease/bin/novovm-node.exe").Hash.ToLowerInvariant() -cne '9040ac63828c30011e8e7c4801be31183ecb69960854dd4974671df3d5d14d51'){throw 'Original rollback binary differs'}
    $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
    foreach($p in $nodes){if($p.ExecutablePath -cne "$release\bin\novovm-node.exe" -or (Invoke-CimMethod $p -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'Rollback target ownership differs'};Stop-Process -Id $p.ProcessId -Force}
    for($i=0;$i -lt 50 -and (Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'");$i++){Start-Sleep -Milliseconds 100}
    if(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"){throw 'Node remains; refuse concurrent rollback open'}
    Register-ExistingTask $rollbackTask -Old
    Write-NewJson "$out/C-explicit-rollback.json" ([ordered]@{start='existing';old_config=(Join-Path $oldWork 'run.json');task=$rollbackTask;initialize_executed=$false;firewall_old_rule_preserved=$true})
    exit
}
$stopped=$false
try{
    $before=Get-Content "$out/C-before.json" -Raw|ConvertFrom-Json
    $config=Get-Content "$oldWork/run.json" -Raw|ConvertFrom-Json
    $network=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
    $keys=Custody-Hashes $config $network
    foreach($p in $keys.Keys){if($keys[$p] -cne $before.custody_sha256.$p){throw 'Original custody differs'}}
    $target=Get-CimInstance Win32_Process -Filter "ProcessId=$($before.pid)"
    if(!$target -or $target.ExecutablePath -cne $before.exe -or (Invoke-CimMethod $target -MethodName GetOwnerSid).Sid -cne 'S-1-5-19' -or (Get-FileHash $target.ExecutablePath).Hash.ToLowerInvariant() -cne $before.node_sha256){throw 'Original process identity differs'}
    if(@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'").Count -gt 1){throw 'Unexpected concurrent node'}
    if((Test-Path $work) -and !$ResumePrepared){throw 'New work already exists; inspect instead of repeat update'}
    $source='D:\WEB3_AI\SUPERVM\target\novonet-probe-C-update-20261108\novonet-probe-ddd89e8e-windows-x86_64'
    Assert-Package $source
    if(Test-Path $release){if(!$ResumePrepared){throw 'Candidate install already exists'}}else{Copy-Item -LiteralPath $source -Destination $release -Recurse};Assert-Package $release
    foreach($item in @((Get-Item $release))+@(Get-ChildItem $release -Recurse -Force)){Set-OwnerAcl $item.FullName}
    if(!(Test-Path $work)){New-Item -ItemType Directory -Path $work|Out-Null};Set-OwnerAcl $work
    foreach($dir in @('logs','rollback-logs','commands')){if(!(Test-Path "$work/$dir")){New-Item -ItemType Directory -Path "$work/$dir"|Out-Null};Set-OwnerAcl "$work/$dir" -Writable:($dir -ne 'commands')}
    if(Test-Path "$work/logs/owner.json"){throw 'Owner already started; cannot repeat update'}
    Copy-Item -LiteralPath $PSCommandPath -Destination "$work/ExistingOwner.ps1" -Force;Set-OwnerAcl "$work/ExistingOwner.ps1"
    $config.library=Join-Path $release 'aoem\windows\core\bin\aoem_ffi.dll';$config.novonet_config_file=Join-Path $work 'network.json'
    $network|Add-Member -NotePropertyName probe_control_file -NotePropertyValue (Join-Path $work 'commands\control.nvprobe')
    if($ResumePrepared){
        foreach($pair in @(@('run.json',$config),@('network.json',$network))){
            $existing=Get-Content (Join-Path $work $pair[0]) -Raw|ConvertFrom-Json
            if(($existing|ConvertTo-Json -Depth 85 -Compress) -cne ($pair[1]|ConvertTo-Json -Depth 85 -Compress)){throw 'Prepared configuration differs; do not overwrite'}
        }
    }else{Write-NewJson "$work/run.json" $config;Write-NewJson "$work/network.json" $network}
    Set-OwnerAcl "$work/run.json";Set-OwnerAcl "$work/network.json"
    $rule=Get-NetFirewallRule -Name 'NOVOVM-08236129-C-20261108'
    $ports=$rule|Get-NetFirewallPortFilter;$addresses=$rule|Get-NetFirewallAddressFilter;$app=$rule|Get-NetFirewallApplicationFilter
    if($rule.Action -ne 'Allow' -or $rule.Direction -ne 'Inbound' -or $ports.Protocol -ne 'UDP' -or (@(Compare-Object @($ports.LocalPort) @('41052','42052'))).Count -or (@(Compare-Object @($addresses.RemoteAddress) @('192.168.71.0/255.255.255.0','47.103.59.206'))).Count -or $app.Program -ine "$oldRelease\bin\novovm-node.exe"){throw 'Existing narrow rule differs from inspected contract'}
    $newRule='NOVOVM-ddd89e8e-C-20261108'
    if(Get-NetFirewallRule -Name $newRule -ErrorAction SilentlyContinue){throw 'New rule already exists'}
    New-NetFirewallRule -Name $newRule -DisplayName $newRule -Direction Inbound -Action Allow -Protocol UDP -Program "$release\bin\novovm-node.exe" -LocalAddress '192.168.71.125' -LocalPort 41052,42052 -RemoteAddress $addresses.RemoteAddress -Profile Any|Out-Null
    $profilesBefore=@(Get-NetFirewallProfile|Select-Object Name,Enabled)
    Write-NewJson "$out/C-firewall.json" ([ordered]@{profiles_before=$profilesBefore;profiles_after=@(Get-NetFirewallProfile|Select-Object Name,Enabled);old_rule_preserved=$true;new_rule=$newRule;ports=@(41052,42052);remotes=@('192.168.71.0/24','47.103.59.206')})
    if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'New task exists'}
    $target=Get-CimInstance Win32_Process -Filter "ProcessId=$($before.pid)"
    if(!$target -or $target.ExecutablePath -cne $before.exe){throw 'Original target changed before termination'}
    Stop-Process -Id $before.pid -Force
    for($i=0;$i -lt 50 -and (Get-Process -Id $before.pid -ErrorAction SilentlyContinue);$i++){Start-Sleep -Milliseconds 100}
    if(Get-Process -Id $before.pid -ErrorAction SilentlyContinue){throw 'Old process remains'}
    $stopped=$true
    Write-NewJson "$out/C-old-exit.json" ([ordered]@{pid=$before.pid;exe=$before.exe;terminated=$true;scope='authorized exact interrupted-process recovery; not certified graceful drain';time=(Get-Date).ToString('o')})
    if(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"){throw 'Another node remains; no shared DB open'}
    Register-ExistingTask $taskName
    for($i=0;$i -lt 120 -and !(Test-Path "$work/logs/progress.json");$i++){Start-Sleep -Milliseconds 500}
    if(!(Test-Path "$work/logs/progress.json")){throw 'New owner has no progress'}
    $new=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
    if($new.Count -ne 1 -or $new[0].ExecutablePath -cne "$release\bin\novovm-node.exe"){throw 'New process identity differs'}
    if((Invoke-CimMethod $new[0] -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'New process not LocalService'}
    $progress=Get-Content "$work/logs/progress.json" -Raw|ConvertFrom-Json
    if($progress.chain_id -ne 91129655606029 -or $progress.execution_failures -ne 0){throw 'Recovered health differs'}
    $afterKeys=Custody-Hashes $config $network
    foreach($p in $keys.Keys){if($keys[$p] -cne $afterKeys[$p]){throw 'Custody changed'}}
    $module=@((Get-Process -Id $new[0].ProcessId).Modules|Where-Object ModuleName -EQ 'aoem_ffi.dll')
    if($module.Count -ne 1 -or (Get-FileHash $module[0].FileName).Hash.ToLowerInvariant() -cne $core){throw 'Actual AOEM module differs'}
    Write-NewJson "$out/C-after.json" ([ordered]@{pid=$new[0].ProcessId;exe=$new[0].ExecutablePath;sid='S-1-5-19';source='ddd89e8e05721a2ddb8a7ae9255405d395b39a46';node_sha256=(Get-FileHash $new[0].ExecutablePath).Hash.ToLowerInvariant();aoem_module=$module[0].FileName;aoem_sha256=$core;database=$config.database;start='existing';initialize_executed=$false;custody_unchanged=$true;progress=$progress;listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -EQ $new[0].ProcessId|Select-Object LocalAddress,LocalPort,OwningProcess);old_task=(Get-ScheduledTask -TaskName 'NOVOVM-C-08236129-Network-20261108').State.ToString();new_task=(Get-ScheduledTask -TaskName $taskName).State.ToString()})
    'PASS C candidate running original database existing; verify authenticated Status'|Set-Content "$out/C-update-result.txt"
}catch{
    $_.ToString()|Set-Content "$out/C-update-error.txt"
    if($stopped){
        $new=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
        foreach($p in $new){if($p.ExecutablePath -cne "$release\bin\novovm-node.exe"){throw 'Unknown process; preserve and stop'};Stop-Process -Id $p.ProcessId -Force}
        if(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"){throw 'Node remains; no rollback concurrent open'}
        Register-ExistingTask $rollbackTask -Old
        'Original 082 rollback requested with existing and old config; inspect logs, never rerun old initializer task'|Set-Content "$out/C-rollback.txt"
    }
    throw
}
