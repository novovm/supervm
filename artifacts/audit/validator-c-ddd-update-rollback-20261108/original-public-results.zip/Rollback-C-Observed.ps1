﻿#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
try {
 $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
 if($nodes.Count){throw 'Node present before rollback; preserve for review'}
 & (Join-Path $out 'Update-C-corrected.ps1') -Rollback
 $work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-ddd89e8e-20261108'
 $deadline=(Get-Date).AddSeconds(60)
 while(!(Test-Path "$work/rollback-logs/progress.json") -and (Get-Date) -lt $deadline){Start-Sleep -Milliseconds 500}
 if(!(Test-Path "$work/rollback-logs/progress.json")){throw 'Rollback progress unavailable'}
 $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
 if($nodes.Count -ne 1 -or $nodes[0].ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-08236129-windows-x86_64\bin\novovm-node.exe'){throw 'Rollback process identity differs'}
 $sid=(Invoke-CimMethod $nodes[0] -MethodName GetOwnerSid).Sid
 if($sid -cne 'S-1-5-19'){throw 'Rollback owner differs'}
 foreach($name in @('owner.json','progress.json','node.stderr')){Copy-Item -LiteralPath "$work/rollback-logs/$name" -Destination (Join-Path $out ('rollback-'+$name))}
 $config=Get-Content 'C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-08236129-20261108\run.json' -Raw|ConvertFrom-Json
 $net=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
 $prior=Get-Content (Join-Path $out 'C-before.json') -Raw|ConvertFrom-Json
 foreach($path in @($config.signing_key_file,$config.transport_key_file,$net.carrier_identity_file)){if((Get-FileHash $path).Hash.ToLowerInvariant() -cne $prior.custody_sha256.$path){throw 'Custody mismatch after rollback'}}
 Copy-Item -LiteralPath $net.public_record_file -Destination (Join-Path $out 'rollback-locator.json')
 [ordered]@{success=$true;pid=$nodes[0].ProcessId;exe=$nodes[0].ExecutablePath;sid=$sid;node_sha256=(Get-FileHash $nodes[0].ExecutablePath).Hash.ToLowerInvariant();start='existing';database=$config.database;custody_unchanged=$true;initialize_executed=$false;time=[DateTime]::UtcNow.ToString('o');task=(Get-ScheduledTask -TaskName 'NOVOVM-C-08236129-Existing-Rollback-20261108').State.ToString()}|ConvertTo-Json|Set-Content (Join-Path $out 'C-rollback-observation.json') -Encoding utf8
} catch { $_.Exception.Message|Set-Content (Join-Path $out 'C-rollback-error.txt');throw }
