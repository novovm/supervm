#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = $PSScriptRoot
$installer = Join-Path $root 'Install-Selfrun-Windows-20261106.ps1'
$package = Join-Path $root 'selfrun-9a6153f1-windows-x86_64'
$launchPath = Join-Path $root 'd-launch-result.json'
$stdout = Join-Path $root 'd-installer.stdout.txt'
$stderr = Join-Path $root 'd-installer.stderr.txt'
foreach ($path in @($launchPath, $stdout, $stderr)) {
    if (Test-Path -LiteralPath $path) { throw 'Existing launch evidence; do not repeat deployment' }
}
if ((Get-FileHash -LiteralPath $installer).Hash.ToLowerInvariant() -ne '3edee735b7c208b93a9a65b3a12da0744f8b613af50fa1e506ea5478d928deec') {
    throw 'Reviewed installer changed'
}
$report = [ordered]@{
    host_id = 'D'
    started_utc = [DateTime]::UtcNow.ToString('o')
    elevated = $true
    installer_exit_code = $null
}
$oldKey = 'C:\Users\ASUS\AppData\Local\NOVOVM\four-host-167999907280566\transport.sealed'
$oldBefore = Get-Item -LiteralPath $oldKey -Force
$serviceBefore = Get-CimInstance Win32_Service -Filter "Name='NOVOVMExecution'"
try {
    $arguments = '-NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "' + $installer + '" -HostId D -PackageRoot "' + $package + '"'
    $process = Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $arguments -RedirectStandardOutput $stdout -RedirectStandardError $stderr -Wait -PassThru -WindowStyle Hidden
    $report.installer_exit_code = $process.ExitCode
    $report['node_service_exists'] = [bool](Get-Service -Name 'NOVOVM-D' -ErrorAction SilentlyContinue)
    $report['temporary_task_exists'] = [bool](Get-ScheduledTask -TaskName 'NOVOVM-D-KeyPreparation-91129655606029' -ErrorAction SilentlyContinue)
    $oldAfter = Get-Item -LiteralPath $oldKey -Force
    $report['old_transport_metadata_unchanged'] = ($oldBefore.Length -eq $oldAfter.Length -and $oldBefore.LastWriteTimeUtc.Ticks -eq $oldAfter.LastWriteTimeUtc.Ticks)
    $report['old_transport_length'] = $oldAfter.Length
    $report['old_transport_last_write_utc'] = $oldAfter.LastWriteTimeUtc.ToString('o')
    $serviceAfter = Get-CimInstance Win32_Service -Filter "Name='NOVOVMExecution'"
    $report['existing_execution_service'] = [ordered]@{
        before_state = $serviceBefore.State
        after_state = $serviceAfter.State
        before_pid = $serviceBefore.ProcessId
        after_pid = $serviceAfter.ProcessId
        unchanged = ($serviceBefore.State -eq $serviceAfter.State -and $serviceBefore.ProcessId -eq $serviceAfter.ProcessId)
    }
    if ($process.ExitCode -eq 0) {
        $state = 'C:\ProgramData\NOVOVM\selfrun\91129655606029\D'
        $metadata = @()
        foreach ($path in @($state, (Join-Path $state 'validator.protected'), (Join-Path $state 'transport.protected'))) {
            $item = Get-Item -LiteralPath $path -Force
            $acl = Get-Acl -LiteralPath $path
            $metadata += [ordered]@{
                name = $item.Name
                is_directory = $item.PSIsContainer
                inheritance_protected = $acl.AreAccessRulesProtected
                access = @($acl.Access | ForEach-Object {
                    [ordered]@{
                        sid = $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
                        rights = $_.FileSystemRights.ToString()
                        type = $_.AccessControlType.ToString()
                        inherited = $_.IsInherited
                    }
                })
            }
        }
        $report['private_state_acl_metadata'] = $metadata
    }
} catch {
    $report['wrapper_error'] = $_.Exception.Message
} finally {
    $report['finished_utc'] = [DateTime]::UtcNow.ToString('o')
    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $launchPath -Encoding UTF8
}
if ($report.installer_exit_code -ne 0 -or $report.Contains('wrapper_error')) { exit 1 }
