﻿#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-ddd89e8e-20261108'
$out=Join-Path $PSScriptRoot 'A-C-observation'
New-Item -ItemType Directory -Path $out -ErrorAction Stop|Out-Null
$report=[ordered]@{pid=23024;started_utc=[DateTime]::UtcNow.ToString('o');received=$false;read_errors=0}
try {
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=23024'
 if(!$node -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe' -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'C receiver process changed'}
 $source=Join-Path $work 'logs\progress.json'
 Copy-Item -LiteralPath $source -Destination (Join-Path $out 'C-before.json')
 $deadline=(Get-Date).AddMinutes(10)
 do {
  try {$data=[IO.File]::ReadAllBytes($source);$progress=[Text.Encoding]::UTF8.GetString($data).TrimStart([char]0xfeff)|ConvertFrom-Json} catch {$report.read_errors++;Start-Sleep -Milliseconds 2000;continue}
  $received=@($progress.native_network_probe.events|Where-Object {
   $_.event -eq 'probe_received_integrity_verified' -and [Convert]::ToHexString([byte[]]$_.sender).ToLowerInvariant() -ceq 'b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43' -and [Convert]::ToHexString([byte[]]$_.recipient).ToLowerInvariant() -ceq '1c054a44ee79b50bf5d059a2f8fc15dd45afcdf8fa10d44a5e12c07afab89a2a'
  })
  if($received.Count){
   [IO.File]::WriteAllBytes((Join-Path $out 'C-received-progress.json'),$data)
   $report.received=$true
   $report['matching_events']=$received
   Start-Sleep -Seconds 2
   Copy-Item -LiteralPath $source -Destination (Join-Path $out 'C-after-progress.json')
   $network=Get-Content (Join-Path $work 'network.json') -Raw|ConvertFrom-Json
   Copy-Item -LiteralPath $network.public_record_file -Destination (Join-Path $out 'C-locator.json')
   break
  }
  Start-Sleep -Seconds 2
 }while((Get-Date) -lt $deadline)
 if(!$report.received){Copy-Item -LiteralPath $source -Destination (Join-Path $out 'C-window-ended-progress.json')}
} catch {$report['error']=$_.Exception.Message}
$report['finished_utc']=[DateTime]::UtcNow.ToString('o')
$report|ConvertTo-Json -Depth 70|Set-Content (Join-Path $out 'watch.json') -Encoding utf8
if($report.Contains('error')){exit 1}
