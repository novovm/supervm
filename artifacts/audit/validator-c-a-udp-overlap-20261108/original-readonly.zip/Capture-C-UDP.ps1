#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$out=$PSScriptRoot
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-ddd89e8e-20261108'
$filter='NOVOVM-C-AC-overlap-20261108-1647'
$started=$false
$added=$false
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');duration_seconds=300;expected_pid=23024;capture_started=$false;log_mode='multi-file';segment_mib=16;space_stop_threshold_mib=224;space_budget_mib=256}
function Snapshot($name) {
 $node=Get-CimInstance Win32_Process -Filter 'ProcessId=23024'
 if(!$node -or $node.ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe' -or (Invoke-CimMethod $node -MethodName GetOwnerSid).Sid -cne 'S-1-5-19'){throw 'C process identity changed'}
 $data=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');pid=$node.ProcessId;exe=$node.ExecutablePath;sha256=(Get-FileHash -LiteralPath $node.ExecutablePath).Hash;listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -eq 23024|Select-Object LocalAddress,LocalPort,OwningProcess)}
 if(!@($data.listeners|Where-Object {$_.LocalAddress -ceq '192.168.71.125' -and $_.LocalPort -eq 41052}).Count){throw 'Original C UDP listener missing'}
 $network=Get-Content -LiteralPath (Join-Path $work 'network.json') -Raw|ConvertFrom-Json
 $data['network_public']=$network|Select-Object bind_address,peer_records,public_record_file,fallback_after_ms,udp_recovery_ms,retry_ms
 $data|ConvertTo-Json -Depth 30|Set-Content (Join-Path $out "$name.json") -Encoding utf8
 Copy-Item -LiteralPath (Join-Path $work 'logs\progress.json') -Destination (Join-Path $out "$name-progress.json") -ErrorAction Stop
 Copy-Item -LiteralPath (Join-Path $work 'logs\node.stderr') -Destination (Join-Path $out "$name-stderr.txt") -ErrorAction Stop
}
try {
 Snapshot 'before'
 $status=(& pktmon status 2>&1|Out-String);$status|Set-Content (Join-Path $out 'pktmon-before.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon status failed'}
 $sessions=(& logman query -ets 2>&1|Out-String)
 if($sessions -match '(?im)^\s*PktMon\s'){throw 'Existing PktMon session retained; capture not started'}
 $filters=(& pktmon filter list 2>&1|Out-String);$filters|Set-Content (Join-Path $out 'filters-before.txt')
 if($LASTEXITCODE -ne 0 -or $filters -notmatch '没有|No filters|无筛选|未配置|(?m)^\s*无\s*$'){throw 'Cannot confirm empty PktMon filters; original filters retained'}
 & pktmon filter add $filter -t UDP -i 192.168.71.74 192.168.71.125 -p 41051 41052 *> (Join-Path $out 'filter-add.txt')
 if($LASTEXITCODE -ne 0){throw 'Exact filter add failed'}
 $added=$true
 & pktmon start --capture --comp nics --pkt-size 0 --file-name (Join-Path $out 'C-AC-UDP.etl') --file-size 16 --log-mode multi-file *> (Join-Path $out 'capture-start.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon start failed'}
 $started=$true;$result.capture_started=$true
 $captureStart=[DateTime]::UtcNow
 $deadline=$captureStart.AddSeconds(300)
 $result['capture_started_utc']=$captureStart.ToString('o')
 $result['latest_stop_utc']=$deadline.ToString('o')
 $result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'STARTED.json') -Encoding utf8
 $result['stop_reason']='five_minute_limit'
 do {
  Start-Sleep -Milliseconds 100
  $total=(Get-ChildItem -LiteralPath $out -Filter '*.etl'|Measure-Object Length -Sum).Sum
  if($total -ge 224MB){$result['stop_reason']='space_threshold';break}
  if((Get-PSDrive D).Free -lt 512MB){$result['stop_reason']='low_disk_space';break}
 } while([DateTime]::UtcNow -lt $deadline)
 & pktmon counters *> (Join-Path $out 'counters.txt')
 & pktmon stop *> (Join-Path $out 'capture-stop.txt')
 if($LASTEXITCODE -ne 0){throw 'Pktmon stop failed'}
 $started=$false
 $result['capture_stopped_utc']=[DateTime]::UtcNow.ToString('o')
 foreach($segment in @(Get-ChildItem -LiteralPath $out -Filter '*.etl'|Sort-Object Name)) {
  & pktmon etl2pcap $segment.FullName --out (Join-Path $out ($segment.BaseName+'.pcapng')) *> (Join-Path $out ($segment.BaseName+'-convert.txt'))
  if($LASTEXITCODE -ne 0){throw ('Pcap conversion failed: '+$segment.Name)}
 }
 $result['segments']=@(Get-ChildItem -LiteralPath $out -Filter '*.etl'|Select-Object Name,Length)
 Snapshot 'after'
 $result['success']=$true
} catch {$result['success']=$false;$result['error']=$_.Exception.Message}
finally {
 if($started){& pktmon stop *> (Join-Path $out 'cleanup-stop.txt')}
 if($added){& pktmon filter remove $filter *> (Join-Path $out 'filter-remove.txt')}
 & pktmon status *> (Join-Path $out 'pktmon-after.txt')
 & pktmon filter list *> (Join-Path $out 'filters-after.txt')
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'result.json') -Encoding utf8
}
if(!$result.success){exit 1}
