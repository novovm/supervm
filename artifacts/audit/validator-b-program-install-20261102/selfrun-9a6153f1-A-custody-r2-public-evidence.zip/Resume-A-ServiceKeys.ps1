#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$release='C:\ProgramData\NOVOVM\releases\selfrun-9a6153f1-windows-x86_64'
$state='C:\ProgramData\NOVOVM\selfrun\91129655606029\A'
$out='D:\WorksArea\SUPERVM\target\selfrun-delivery-20261106'
$taskName='NOVOVM-A-KeyPreparation-91129655606029'
$result=[ordered]@{action='repair-release-file-aces-and-resume-existing-key-task';success=$false;program_reinstalled=$false;key_overwritten=$false;node_started=$false;genesis_created=$false;private_material_exported=$false}
try {
    if(Test-Path -LiteralPath (Join-Path $out 'a-service-key-resume-result.json')) {throw 'Existing resume result: inspect before any retry'}
    $fixture=Join-Path $out 'acl-fixture'
    if(Test-Path -LiteralPath $fixture) {
        $fixtureEntries=@((Get-Item -LiteralPath $fixture -Force))+@(Get-ChildItem -LiteralPath $fixture -Force -Recurse)
        if($fixtureEntries.Count -ne 2 -or $fixtureEntries[1].Name -ne 'sample.txt' -or @($fixtureEntries|Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count) {throw 'Unexpected permission-test fixture; do not reset'}
        & icacls.exe $fixture /reset /T /Q | Out-Null
        if($LASTEXITCODE -ne 0) {throw 'Could not restore isolated permission-test fixture ACLs'}
        $result['isolated_permission_fixture_acls_restored']=$true
    }
    foreach($purpose in @('validator','transport')) {if(Test-Path -LiteralPath (Join-Path $state ($purpose+'.protected'))) {throw 'Existing purpose key: do not regenerate'}}
    if((Get-ScheduledTask -TaskName $taskName).State -eq 'Running') {throw 'Task already running'}
    # Execute precisely the repaired ACL step from the same reviewed installer.
    $installer=Join-Path $out 'Install-Selfrun-Windows-20261106.ps1'
    $tokens=$null;$errors=$null
    $ast=[Management.Automation.Language.Parser]::ParseFile($installer,[ref]$tokens,[ref]$errors)
    if($errors.Count) {throw 'Installer parse failure'}
    $steps=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.ForEachStatementAst] -and $n.Extent.Text.Contains('New-Object Security.AccessControl.DirectorySecurity')},$true))
    if($steps.Count -ne 1) {throw 'Expected one original release ACL step'}
    & ([scriptblock]::Create($steps[0].Extent.Text))
    $manifest=Get-Content -LiteralPath (Join-Path $release 'release-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if((Get-FileHash -LiteralPath (Join-Path $release 'release-manifest.json')).Hash.ToLowerInvariant() -ne '58c92085ca738c1e3e280960df9f16d5432ff38fabcf08fa1dca170b905eff5d') {throw 'Release manifest changed'}
    foreach($file in $manifest.artifacts) {
        $path=[IO.Path]::GetFullPath((Join-Path $release $file.path))
        if(-not $path.StartsWith($release+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Artifact outside installed release'}
        $item=Get-Item -LiteralPath $path -Force
        if($item.Length -ne $file.bytes -or (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ne $file.sha256) {throw 'Installed artifact changed'}
    }
    $result['artifacts_verified']=$manifest.artifacts.Count
    $result['ctl_sddl']=(Get-Acl -LiteralPath (Join-Path $release 'bin\novovmctl.exe')).Sddl
    foreach($name in @('key-preparation-result.json','runtime.stderr')) {
        if(Test-Path -LiteralPath (Join-Path $state $name)) {Copy-Item -LiteralPath (Join-Path $state $name) -Destination (Join-Path $out ('a-before-file-acl-fix-'+$name))}
    }
    $started=Get-Date
    Start-ScheduledTask -TaskName $taskName
    $deadline=$started.AddMinutes(3)
    do {
        Start-Sleep -Milliseconds 500
        $task=Get-ScheduledTask -TaskName $taskName
        $info=Get-ScheduledTaskInfo -TaskName $taskName
        $reportFile=Get-Item -LiteralPath (Join-Path $state 'key-preparation-result.json') -ErrorAction SilentlyContinue
        if($task.State -ne 'Running' -and $reportFile -and $reportFile.LastWriteTime -ge $started) {break}
    } while((Get-Date) -lt $deadline)
    if($task.State -eq 'Running' -or -not $reportFile -or $reportFile.LastWriteTime -lt $started) {throw 'No completed fresh key task result; preserve task'}
    $keyResult=Get-Content -LiteralPath $reportFile.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    $result['key_preparation']=$keyResult
    $result['task_exit_code']=$info.LastTaskResult
    if(-not $keyResult.success -or $keyResult.sid -ne 'S-1-5-19' -or $info.LastTaskResult -ne 0) {throw 'Actual LocalService key task failed; preserve files'}
    foreach($name in @('runtime.json','validator-generate.json','validator-inspect.json','transport-generate.json','transport-inspect.json','key-preparation-result.json')) {Copy-Item -LiteralPath (Join-Path $state $name) -Destination (Join-Path $out ('a-'+$name))}
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    $result['temporary_task_removed']=$true
    $result.success=$true
} catch {$result['error']=$_.Exception.Message}
$result|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $out 'a-service-key-resume-result.json') -Encoding UTF8
if(-not $result.success){exit 1}
