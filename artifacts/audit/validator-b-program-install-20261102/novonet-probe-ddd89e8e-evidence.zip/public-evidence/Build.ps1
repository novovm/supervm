param([Parameter(Mandatory=$true)][string]$Source,[switch]$Linux)
$ErrorActionPreference='Stop'
if($Linux){
    function global:git { & '/mnt/c/Program Files/Git/cmd/git.exe' @args; if($LASTEXITCODE -ne 0){throw 'Original Windows Git failed'} }
    $repo='/mnt/d/WorksArea/SUPERVM';$platform='linux';$target='x86_64-unknown-linux-gnu'
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
    $pin='d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33'
}else{
    $repo='D:/WorksArea/SUPERVM';$platform='windows';$target='x86_64-pc-windows-msvc'
    $pin='1b764a36c1f782425237d40446d4ea827f56a66fb341b870855d84c15acdce50'
}
Set-Location $repo
if((git rev-parse HEAD).Trim() -cne $Source){throw 'Frozen source changed'}
$env:CARGO_BUILD_JOBS='4';$env:RUSTUP_TOOLCHAIN='1.94.0'
$runtime="$repo/artifacts/product-overlay/novonet-08236129-$platform-x86_64/aoem"
$env:AOEM_DLL_MANIFEST="$runtime/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST;$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$short=$Source.Substring(0,8)
& ./scripts/novovm-package-product-linux.ps1 -Target $target -PackageDir "artifacts/product-overlay/novonet-probe-$short-$platform-x86_64" -AoemPackageRoot $runtime -AoemCoreSha256 $pin
