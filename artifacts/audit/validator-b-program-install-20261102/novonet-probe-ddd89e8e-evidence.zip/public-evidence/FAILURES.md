# 本轮失败记录（控制台摘录，不冒充完整原始stderr）

1. 初次Node测试编译：legacy_encode独立旧格式oracle未穷尽新增NetworkProbe；将其加入
   “旧oracle不接受新tag”的明确拒绝组，没有删除旧六tag字节等价断言。
2. CLI all-targets检查：原native_genesis_cli夹具遗漏已有ResidentConfig.novonet_config_file；
   显式补None，未改产品启动或关闭门禁。Windows/Linux CLI严格检查随后通过。
3. Node tests严格Clippy：items_after_test_module，原本新Control单测块位于impl之前；
   仅移至模块末尾，未增加allow。后继严格检查通过。
4. 首个7项原网络回归：6通过、单中继新夹具失败，末项错误
   `Error: relay reconnect did not reauthenticate`，总280.01秒。该编译版本单中继省略了
   原双中继恢复夹具已有的61秒滚动资源窗口分隔。恢复原分隔，不加生产超时/额度，
   单例定向复验81.19秒通过。原失败保留，不据此归因部署中的四机网络。
5. Linux第一次check启动Shell的PATH含Windows路径空格，bash解析失败，尚未执行cargo。
   后改用wsl --cd + env argv直接调用cargo，无全局PATH/网络设置修改；Linux检查通过。

当前节点仍为08236129；上述都是本地构建/组件回归，没有在运行节点重试初始化。
