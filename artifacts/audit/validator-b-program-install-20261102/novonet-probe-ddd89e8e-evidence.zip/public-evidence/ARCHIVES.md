# 固定分发包

源码 ddd89e8e05721a2ddb8a7ae9255405d395b39a46；生成后未安装或启动。

- Windows ZIP 150476966字节，SHA256
  9841a060ab37dc6fbca174ee91048f3e3e54d106957d6e9e0781e7fe44a9115e
- Linux tar.gz 359196043字节，SHA256
  38f520b3110691cafdb690ff46cb56578c1a7d2682b98ae688b0c5e6dcc03a94

独立Verify.ps1核对Windows包77项和Linux包80项实际文件、CHECKSUMS索引、
运行库路径/hash/KAT、原node --service-contract及原ctl prepare/cancel。
另外Windows ZIP以ZipFile.OpenRead读取每项压缩成员，77项尺寸和SHA256均匹配
原manifest；Linux压缩归档gzip -t通过CRC完整性检查，未声称再解包核对全部成员。

这只是程序分发包及离线资格，不是四机交付、SCM部署或Business Receipt。
