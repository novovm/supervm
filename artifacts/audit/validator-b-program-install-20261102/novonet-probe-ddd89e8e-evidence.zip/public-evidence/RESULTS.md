# 原owner有界Probe候选：本地结果

源码：ddd89e8e05721a2ddb8a7ae9255405d395b39a46。基线：adf3b64e。
本文件是本地实测汇总，不是云端CI、四机实网或业务最终性通过凭证。
运行节点仍08236129；无服务重启、用途钥/库/防火墙/现行算法变化。

## 最终检查

- Windows/Linux node lib+tests、network lib+tests、ctl all-targets严格Clippy通过。
- cargo fmt --all -- --check、git diff --check通过。
- 原生命周期真实AOEM store+Native组件的3项定向测试，两平台各3/3通过。
  Windows最后0.84s，Linux最后1.76s；完整输出见各自probe-lifecycle.log。
  传输签名是原显式标记的ML-DSA-shaped组件provider，不是实际AOEM ML-DSA握手
  或四个物理节点运行。实际包内ML-DSA验证资格由独立verified平台JSON记录。
- codec固定格式、每处截断、尾部/图样变动、无效身份与过期拒绝通过。
- 固定命令解码与原reactor异步读取/相同文件不重放通过。
- Windows probe筛选共4通过/4忽略（81.27s），忽略的3项生命周期已用--ignored
  单独执行；另外原protected-NAT测试未在本轮该筛选执行，不能算已通过。
- 原底层diagnostics两平台各7/7通过；包括竞争时不等待、不伪造DONE。
- CLI原子发布/取消/非诊断文件保护两平台各1项通过；固定包另做原CLI离线冒烟。
- Windows原三高度CPU业务、默认关闭诊断回归1项通过（1.04s，前序控制台记录）。

## 原网络IO组（控制台结果摘要，不冒充保留了完整原始日志）

命令：cargo test -p novovm-node --lib --features iroh-transport
service::network::tests --offline -- --nocapture --test-threads=1

Windows首个组6通过/1失败，280.01s；失败详见FAILURES.md，不覆盖。
恢复原fixture 61秒滚动额度窗口分隔后，单中继定向1/1通过81.19s；最终probe
筛选又执行该同一单中继测试并通过，输出保留于windows-probe-unit.log。
其余6项包含原双中继、并发普通及固定对象、断开后重认证、原发现交付、冷恢复、
错误域拒绝、备用托底，均在原首次组通过；不是修正后整组又跑出7/7。

Linux原网络IO组最终7/7通过，233.23s。末尾控制台原文：

```
test result: ok. 7 passed; 0 failed; 0 ignored; 0 measured; 1765 filtered out; finished in 233.23s
```

本地IO使用原reactor、QUIC/Finished及原中继转发，不是纯内存模拟；但仍为
localhost组件测试，不是A/B/C/D实网，也不代表跨公网ML-DSA中继验收。

## 已覆盖的语义

- 原NativeLifecycle并发直连：相同Object ID/Session ID、实际ACK反馈与Object DONE；
  业务执行计数0，head仍无确认，不能冒充Business Receipt。
- 重复nonce拒绝、认证来源/声明接收者校验、1个活动发送、1次/s、接收4次/s、
  10s原期限、64条事件淘汰、无任意业务payload。
- 未准入取消/到期释放；准入后取消仍沿原sender排空，可出现取消后远端已DONE，
  不声称撤回远端数据；会话更替不续TTL。
- 单/双中继保留普通对象，追加2个固定Probe；以原对象接收和原DONE核对，并
  重新认证后再交付。逐对象观察只报告实际会话和首跳，不能推导全部物理跳证据。
- 诊断默认关闭；新增配置明确opt-in，旧运行进程不能从外部热改OnceLock。

## 交付限制

本轮不安装、不更新、不停止任何现有节点。existing更新/回滚、副作用和需要后继
C接收新tag的条件，已写入原共享交接第18节；不另建计划套计划。
两平台候选与独立运行库核验、离线命令冒烟按各自manifest/hash绑定；本地通过不
等于云端门禁通过。保留全部首错，不为得到绿灯重跑完整CI。
