import base64
import datetime
import json
from pathlib import Path

work = Path('/var/lib/novovm/selfrun/91129655606029/B/novonet-ce1-20261108')
run = json.loads((work / 'run-fixed-08236129.json').read_text())
network = json.loads(Path(run['novonet_config_file']).read_text())
files = {}
for name in ('progress-B-steady.json', 'locator-B.json', 'locator-B.discovery-cache.json'):
    path = work / name
    files[name] = dict(exists=path.exists())
    if path.exists():
        data = path.read_bytes()
        files[name].update(bytes=len(data), raw_base64=base64.b64encode(data).decode())
stderr = work / 'fixed-steady.stderr'
print(json.dumps(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     host='B', runtime=dict(udp_addr=run['udp_addr'], native_client_limit=run['native_client_limit'],
                     peers=run['peers'], learn_authenticated_peer_routes=run.get('learn_authenticated_peer_routes')),
                     network={key: network.get(key) for key in ('discovery', 'discovery_seeds', 'peer_records', 'relay_forwarding', 'public_record_file')},
                     public_files=files, stderr_bytes=stderr.stat().st_size)))
