import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).parent
names = ['Read-B-Public.py', 'Compare-B-Public.py', 'Collect-Public.py', 'B-snapshot-1.json',
         'B-snapshot-2.json', 'B-comparison.json', 'B-owner-listeners.txt', 'A-listeners.json']
files = {name: (root / name).read_bytes() for name in names}
comparison = json.loads(files['B-comparison.json'].decode('utf-8-sig'))
assert comparison['counters']['native_rejected_messages']['delta'] == 0
assert comparison['counters']['native_expired_sends']['delta'] == 0
assert comparison['locator_publication']['fresh_at_snapshot']
assert comparison['stage_profile']['native_delivery']['enabled'] is False
manifest = dict(scope='passive-discovery-and-counter-evidence-not-object-DONE-acceptance',
                source='08236129320da2e71c5fa112d249fa7afc741e78',
                status_queries_repeated=False, services_restarted=False, identities_changed=False,
                test_object_sent=False, full_mesh_discovery_accepted=False,
                files=[dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in files.items()])
destination = root.parents[1] / 'artifacts/audit/validator-b-program-install-20261102/novonet-082-passive-object-audit-20261108.zip'
with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
    archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, data in files.items():
        assert archive.read(name) == data
print(json.dumps(dict(bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest(), entries=len(files)+1)))
