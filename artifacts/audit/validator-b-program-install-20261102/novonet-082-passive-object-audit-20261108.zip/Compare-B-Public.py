import base64
import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
common = json.loads((root.parents[1] / 'target/novonet-clock-fixed-08236129-20261108/public-inputs/common-approved.json').read_text())
keys = {bytes(v['transport_public_key']): host for host, v in zip('ABCD', common['genesis']['validators'])}
def read_snapshot(index):
    snap = json.loads((root / f'B-snapshot-{index}.json').read_text(encoding='utf-8-sig'))
    parsed = {name: json.loads(base64.b64decode(value['raw_base64'])) for name, value in snap['public_files'].items() if value['exists']}
    return snap, parsed

one, old = read_snapshot(1)
two, new = read_snapshot(2)
metrics = ('native_pending_deliveries', 'native_rejected_messages', 'native_expired_sends', 'current_height', 'executed_batches', 'execution_failures')
delta = {name: dict(before=old['progress-B-steady.json'][name], after=new['progress-B-steady.json'][name],
                   delta=new['progress-B-steady.json'][name] - old['progress-B-steady.json'][name]) for name in metrics}
records = []
for name, value in new.items():
    if name == 'progress-B-steady.json':
        continue
    for record in value if isinstance(value, list) else [value]:
        public = bytes(record['relay_public_key'])
        records.append(dict(file=name, expected_host=keys.get(public), key_sha256=hashlib.sha256(public).hexdigest(),
                            record_id=record['record_id'], sequence=record['sequence'], issued_at_ms=record['issued_at_ms'], expires_at_ms=record['expires_at_ms']))
progress = new['progress-B-steady.json']
report = dict(start=one['observed_utc'], end=two['observed_utc'], counters=delta,
              locator_publication=dict(before=old['locator-B.json']['sequence'], after=new['locator-B.json']['sequence'],
                   fresh_at_snapshot=new['locator-B.json']['issued_at_ms'] <= datetime.datetime.fromisoformat(two['observed_utc']).timestamp()*1000 < new['locator-B.json']['expires_at_ms']),
              network_before=old['progress-B-steady.json'].get('novonet'), network_after=progress.get('novonet'),
              configuration=two['network'], stderr_bytes=two['stderr_bytes'], records=records,
              delivery_traffic_available='native_delivery_traffic' in progress,
              stage_profile=progress.get('stage_profile'),
              scope='public snapshots and source mapping; no pool-memory inspection or independent locator signature verification')
print(json.dumps(report, indent=2))
