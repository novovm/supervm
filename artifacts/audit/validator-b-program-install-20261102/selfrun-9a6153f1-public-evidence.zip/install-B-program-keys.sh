#!/bin/bash
# One approved installation operation; no node is started by this script.
set -euo pipefail
umask 077
test "$(id -u)" = 0
test "$#" = 3
archive=$(realpath "$1")
archive_pin=$2
manifest_pin=$3
name=selfrun-9a6153f1-linux-x86_64
release=/opt/novovm/releases/$name
state=/var/lib/novovm/selfrun/91129655606029/B
config=/etc/novovm
credential=$config/credentials/node-owner-key.cred
for path in "$release" /var/lib/novovm "$config"; do
    test ! -e "$path" && test ! -L "$path" || { echo "Existing target requires inspection, not overwrite: $path" >&2; exit 1; }
done
if getent passwd novovm >/dev/null; then echo 'Existing novovm account requires inspection' >&2; exit 1; fi
printf '%s  %s\n' "$archive_pin" "$archive" | sha256sum -c -
for service in novonet-mailbox.service supervm-relay.service nginx.service docker.service; do
    systemctl is-active --quiet "$service"
done
before=$(systemctl show novonet-mailbox.service supervm-relay.service nginx.service docker.service --property=Id,ActiveState,MainPID --no-pager)
# The externally pinned archive comes from A's original packager. Constrain its members.
if tar -tzf "$archive" | awk -v prefix="$name/" 'index($0,prefix)!=1 || $0 ~ /(^|\/)\.\.(\/|$)/ {bad=1} END {exit bad?0:1}'; then
    echo 'Archive path outside this release' >&2; exit 1
fi
tar -xzf "$archive" -C /opt/novovm/releases --no-same-owner --no-same-permissions
test -z "$(find "$release" -type l -print -quit)"
printf '%s  %s\n' "$manifest_pin" "$release/release-manifest.json" | sha256sum -c -
test "$(jq -r .git_commit "$release/release-manifest.json")" = 9a6153f1eebda4da5c10829abf77575aa106ba8f
(cd "$release" && sha256sum -c CHECKSUMS.sha256)
chown -R root:root "$release"
find "$release" -type d -exec chmod 0755 {} +
find "$release" -type f -exec chmod 0644 {} +
chmod 0755 "$release"/bin/*
useradd --system --user-group --home-dir /var/lib/novovm --shell /usr/sbin/nologin novovm
install -d -m 0750 -o root -g novovm "$config" "$config/credentials"
install -d -m 0700 -o novovm -g novovm /var/lib/novovm /var/lib/novovm/selfrun /var/lib/novovm/selfrun/91129655606029 "$state"
# Reuse the repository's original systemd encrypted credential custody recipe.
systemd-creds setup
openssl rand 32 | systemd-creds encrypt --with-key=host --name=owner-key - "$credential"
chmod 0600 "$credential"
lib=$release/aoem/linux/core/bin/libaoem_ffi.so
core_pin=d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33
manifest=$release/aoem/manifest/aoem-manifest.json
ctl=$release/bin/novovmctl
run_owner() {
    systemd-run --quiet --wait --pipe --collect --unit="novovm-B-keyprep-$1-91129655606029" \
        -p User=novovm -p Group=novovm -p UMask=0077 \
        -p "LoadCredentialEncrypted=owner-key:$credential" \
        -p "Environment=AOEM_DLL_MANIFEST=$manifest NOVOVM_AOEM_MANIFEST=$manifest AOEM_DLL_MANIFEST_REQUIRED=1" \
        "$ctl" "${@:2}"
}
run_owner runtime native-identity qualify-runtime --library "$lib" --library-sha256 "$core_pin" > "$state/runtime.json"
for purpose in validator transport; do
    run_owner "generate-$purpose" native-identity generate --key-file "$state/$purpose.protected" --purpose "$purpose" --chain-id 91129655606029 --library "$lib" --library-sha256 "$core_pin" > "$state/$purpose-generate.json"
    run_owner "inspect-$purpose" native-identity inspect --key-file "$state/$purpose.protected" --purpose "$purpose" --chain-id 91129655606029 --library "$lib" --library-sha256 "$core_pin" > "$state/$purpose-inspect.json"
done
after=$(systemctl show novonet-mailbox.service supervm-relay.service nginx.service docker.service --property=Id,ActiveState,MainPID --no-pager)
test "$before" = "$after" || { echo 'Existing service state/PID changed: inspect before further action' >&2; exit 1; }
printf '%s\n' "$after"
printf 'PROGRAM_INSTALLED_AND_PURPOSE_KEYS_VERIFIED; node_started=false; genesis_created=false; service_installed=false\n'
for purpose in validator transport; do cat "$state/$purpose-inspect.json"; done
