"""Offline, read-only analysis of the bounded B capture; not a product decoder."""
import collections
import datetime
import hashlib
import json
import socket
import struct
from pathlib import Path

root = Path(__file__).parent
raw = (root / 'B-query-0500-correlated.pcap').read_bytes()
assert raw[:4] == b'\xd4\xc3\xb2\xa1'
assert struct.unpack_from('<I', raw, 20)[0] == 1  # Ethernet
packets = []
assemblies = {}
offset = 24
while offset < len(raw):
    sec, usec, size, original_size = struct.unpack_from('<IIII', raw, offset)
    offset += 16
    frame = raw[offset:offset + size]
    offset += size
    assert len(frame) == size
    if len(frame) < 42 or frame[12:14] != b'\x08\x00':
        continue
    ip = frame[14:]
    header = (ip[0] & 15) * 4
    if ip[9] != 17 or struct.unpack_from('!H', ip, 6)[0] & 0x3fff:
        continue
    sport, dport, length, _ = struct.unpack_from('!HHHH', ip, header)
    body = ip[header + 8:header + length]
    source = f'{socket.inet_ntoa(ip[12:16])}:{sport}'
    target = f'{socket.inet_ntoa(ip[16:20])}:{dport}'
    when = datetime.datetime.fromtimestamp(sec + usec / 1e6, datetime.timezone.utc).isoformat()
    packets.append(dict(time=when, source=source, target=target, bytes=len(body)))
    if body.startswith(b'NVHCONT1') and len(body) >= 100 and body[8] == 3:
        key = (source, target, body[9:25].hex(), body[25:57].hex())
        assembly = assemblies.setdefault(key, dict(parts={}, times=[], length=int.from_bytes(body[57:59], 'big')))
        index = body[99]
        old = assembly['parts'].setdefault(index, body[100:])
        assert old == body[100:]
        assembly['times'].append(when)

query_public = bytes(json.loads((root / 'client-public-generated.json').read_text(encoding='utf-8-sig'))['data']['identity']['public_key'])
matched = []
for (source, target, transfer, digest), assembly in assemblies.items():
    count = (assembly['length'] + 1023) // 1024
    if sorted(assembly['parts']) != list(range(count)):
        continue
    transcript = b''.join(assembly['parts'][i] for i in range(count))
    assert len(transcript) == assembly['length']
    assert hashlib.sha256(transcript).hexdigest() == digest
    if query_public in transcript:
        matched.append(dict(first=assembly['times'][0], last=assembly['times'][-1], source=source,
                            target=target, transfer=transfer, transcript_sha256=digest,
                            public_client_key_matches=True, transcript_tag=transcript[8],
                            signature_independently_verified=False))
flows = collections.Counter((p['source'], p['target']) for p in packets)
report = dict(scope='B-NIC-bounded-capture-not-global-network-acceptance',
              sha256=hashlib.sha256(raw).hexdigest(), packets=len(packets),
              first=packets[0]['time'], last=packets[-1]['time'],
              operator_handshake_transcripts=matched,
              flows=[dict(source=s, target=t, packets=n) for (s, t), n in flows.items()],
              operator_timing=json.loads((root / 'status-B-correlated-0500-timing.json').read_text(encoding='utf-8-sig')))
assert matched, 'No complete handshake with the actual operator public key captured'
print(json.dumps(report, indent=2))
