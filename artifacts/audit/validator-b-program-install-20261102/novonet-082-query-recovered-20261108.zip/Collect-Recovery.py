import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).parent
selected = ['A-firewall-now-Allow.json', 'B-query-0500-correlated.pcap',
            'B-correlated-pcap-analysis.json', 'Inspect-Correlated-Pcap.py',
            'status-B-correlated-0500.json', 'status-B-correlated-0500.stderr',
            'status-B-correlated-0500-timing.json', 'B-progress-0501.json', 'Collect-Recovery.py']
selected += [f'status-{host}-after-Allow.{ext}' for host in 'BCD' for ext in ('json', 'stderr')]
selected += [f'status-{host}-live-0456.{ext}' for host in 'CD' for ext in ('json', 'stderr')]
selected += ['status-B-pcap-0456.json', 'status-B-pcap-0456.stderr']
files = {name: (root / name).read_bytes() for name in selected}
# Only public key material, not the protected custody file or operator config.
generated = json.loads((root / 'client-public-generated.json').read_text(encoding='utf-8-sig'))
files['client-public-generated.json'] = json.dumps(dict(data=dict(identity=dict(public_key=generated['data']['identity']['public_key'])))).encode()
results = []
for host in 'BCD':
    name = 'status-B-pcap-0456.json' if host == 'B' else f'status-{host}-live-0456.json'
    result = json.loads(files[name].decode('utf-8-sig'))
    status = result['result']['answer']['Status']
    assert bytes(status['state_root']).hex() == 'f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333'
    assert result['result']['independently_verified_finality'] is False
    results.append(dict(host=host, elapsed_ms=result['elapsed_ms'], height=status['height'],
                        current_height=status['current_height'], projection_failed=status['projection_failed']))
manifest = dict(scope='read-only-connectivity-recovery-not-validator-mesh-finality-or-performance',
                user_reported_disconnect=True, historical_timeout_root_cause_proven=False,
                firewall_changed=False, node_restarted=False, source='08236129320da2e71c5fa112d249fa7afc741e78',
                results=results,
                files=[dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in files.items()])
destination = root.parents[1] / 'artifacts/audit/validator-b-program-install-20261102/novonet-082-query-recovered-20261108.zip'
with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
    archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, data in files.items():
        assert archive.read(name) == data
print(json.dumps(dict(bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest(), results=results, entries=len(files)+1), indent=2))
