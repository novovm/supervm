"""Fixed candidate reception and one original-owner, same-database run on B."""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

assert os.getuid() == 0
incoming = Path('/home/ecs-user/novovm-incoming-08236129-20261108')
archive = incoming / 'novonet-08236129-linux-x86_64.tar.gz'
release = Path('/opt/novovm/releases/novonet-08236129-linux-x86_64')
state = Path('/var/lib/novovm/selfrun/91129655606029/B')
work = state / 'novonet-ce1-20261108'
output = incoming / 'fixed-evidence'
core = 'd73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33'
manifest_pin = 'ed2705ac1943ed231fd17d6a79e5a13126739474d08049bb1976c2f05f476483'

def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            sha.update(block)
    return sha.hexdigest()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def write(name, value):
    with (output / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)

require(len(sys.argv) == 2 and digest(archive) == sys.argv[1], 'Independently pinned archive differs')
require(not release.exists() and not release.is_symlink(), 'Refuse overwriting any release')
require((state / 'chain-state').is_dir(), 'Original initialized database is required; never create')
output.mkdir(mode=0o700, exist_ok=False)
with tarfile.open(archive) as bundle:
    for entry in bundle.getmembers():
        parts = Path(entry.name).parts
        require(parts and parts[0] == release.name and '..' not in parts and not entry.name.startswith('/'),
                'Archive member outside frozen release')
        require(entry.isdir() or entry.isfile(), 'Redirected or special archive member')
    bundle.extractall(release.parent, filter='data')
for item in (release, *release.rglob('*')):
    require(not item.is_symlink(), 'Redirected installed candidate')
    item.chmod(0o755 if item.is_dir() or item.parent == release / 'bin' else 0o644)
require(digest(release / 'release-manifest.json') == manifest_pin, 'Manifest pin mismatch')
manifest = json.loads((release / 'release-manifest.json').read_text())
require(manifest['git_commit'] == '08236129320da2e71c5fa112d249fa7afc741e78', 'Source differs')
require(len(manifest['artifacts']) == 80, 'Artifact count differs')
checksums = []
for entry in manifest['artifacts']:
    path = release / entry['path']
    require(path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'], entry['path'])
    checksums.append(f'{entry["sha256"]}  {entry["path"]}')
require((release / 'CHECKSUMS.sha256').read_text().splitlines() == checksums, 'Checksum table differs')
env = os.environ.copy()
aoem_manifest = str(release / 'aoem/manifest/aoem-manifest.json')
env.update(AOEM_DLL_MANIFEST=aoem_manifest, NOVOVM_AOEM_MANIFEST=aoem_manifest, AOEM_DLL_MANIFEST_REQUIRED='1')
library = release / manifest['aoem_runtime']['path']

def run_json(argv, label):
    result = subprocess.run(argv, env=env, capture_output=True, timeout=120)
    (output / (label + '.stdout')).write_bytes(result.stdout)
    (output / (label + '.stderr')).write_bytes(result.stderr)
    require(result.returncode == 0, label + ' command failed')
    return json.loads(result.stdout)

runtime = run_json([str(release / 'bin/novovmctl'), 'native-identity', 'qualify-runtime',
                    '--library', str(library), '--library-sha256', core], 'runtime')
data = runtime['data']
require(runtime['ok'] is True and data['library_sha256'] == core and os.path.samefile(data['library'], library),
        'Actual loaded AOEM differs')
for field in ('verification_qualified', 'scalar_verification_kat_passed', 'unified_semantic_verification_kat_passed',
              'mixed_batch_verification_kat_passed', 'primitive_sign_interface_size_checked'):
    require(data[field] is True, field)
for field in ('signing_tested', 'keygen_tested', 'custody_accessed', 'protected_key_created', 'database_created', 'service_started'):
    require(data[field] is False, field)
node_contract = run_json([str(release / 'bin/novovm-node'), '--service-contract'], 'node-contract')
require(node_contract['entry'] == 'native_execution_tick' and node_contract['start_mode'] == 'existing'
        and node_contract['platform'] == 'linux', 'Actual node contract differs')
before = subprocess.check_output(['systemctl', 'show', 'novonet-mailbox', 'supervm-relay', 'nginx', 'docker',
                                  '--property=Id,ActiveState,MainPID', '--no-pager']).decode()
(output / 'services-before.txt').write_text(before)
key_hashes = {name: digest(work / name if name == 'carrier.protected' else state / name)
              for name in ('validator.protected', 'transport.protected', 'carrier.protected')}
config = json.loads((work / 'run-B.json').read_text())
require(config['database'] == str(state / 'chain-state'), 'Database path differs')
config['library'] = str(library)
run_config = work / 'run-fixed-08236129.json'
with run_config.open('x', encoding='utf-8') as stream:
    json.dump(config, stream)
os.chown(run_config, (state / 'transport.protected').stat().st_uid,
         (state / 'transport.protected').stat().st_gid)
run_config.chmod(0o600)
unit = 'novovm-B-08236129-rotation-20261108'
node_env = (f'AOEM_DLL_MANIFEST={aoem_manifest} NOVOVM_AOEM_MANIFEST={aoem_manifest} '
            'AOEM_DLL_MANIFEST_REQUIRED=1 AOEM_SEMANTIC_GRAPH_V2_WORKERS=1 '
            f'NOVOVM_NODE_MODE=native_execution_tick NOVOVM_NATIVE_EXECUTION_CONFIG={run_config} '
            'NOVOVM_NATIVE_EXECUTION_START=existing NOVOVM_NATIVE_EXECUTION_RUN_MS=240000 '
            f'NOVOVM_NATIVE_EXECUTION_PIPELINE_PROGRESS_REPORT_PATH={work / "progress-B-fixed.json"}')
argv = ['systemd-run', '--quiet', '--wait', '--pipe', '--collect', '--unit=' + unit,
        '-p', 'User=novovm', '-p', 'Group=novovm', '-p', 'UMask=0077', '-p', 'RuntimeMaxSec=330',
        '-p', 'LoadCredentialEncrypted=owner-key:/etc/novovm/credentials/node-owner-key.cred',
        '-p', 'Environment=' + node_env, str(release / 'bin/novovm-node')]
started_wall = int(time.time() * 1000)
started = time.monotonic()
snapshots = []
with (output / 'node.stdout').open('xb') as stdout, (output / 'node.stderr').open('xb') as stderr:
    process = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
    while process.poll() is None:
        require(time.monotonic() - started < 340, 'Bounded original run did not terminate; preserve unit')
        record = json.loads((work / 'locator-B.json').read_text())
        if record['issued_at_ms'] >= started_wall:
            encoded = record['endpoints'][0]['uri'].split('://', 1)[1]
            endpoint = json.loads(base64.urlsafe_b64decode(encoded + '=' * (-len(encoded) % 4)))
            sample = dict(elapsed_seconds=round(time.monotonic() - started, 3), sequence=record['sequence'],
                          instance=bytes(endpoint['instance']).hex(), endpoint_key=bytes(endpoint['address']['endpoint_key']).hex(),
                          direct=endpoint['address']['direct'], relays=endpoint['address']['relays'])
            if not snapshots or snapshots[-1]['sequence'] != sample['sequence']:
                snapshots.append(sample)
                write(f'locator-{record["sequence"]}.json', record)
                write(f'snapshot-{record["sequence"]}.json', sample)
        time.sleep(5)
elapsed = time.monotonic() - started
write('rotation-snapshots.json', snapshots)
require(process.returncode == 0 and elapsed >= 235, 'Original steady run failed or ended early')
require(len({s['instance'] for s in snapshots}) >= 3, 'Two actual discovery rotations not observed')
require(len({s['endpoint_key'] for s in snapshots}) == 1, 'Stable carrier identity changed')
require(all(a['sequence'] < b['sequence'] for a, b in zip(snapshots, snapshots[1:])), 'Publication sequence regressed')
require(b'ClockRegression' not in (output / 'node.stderr').read_bytes()
        and b'monotonic clock moved backwards' not in (output / 'node.stderr').read_bytes(), 'Clock failure remains')
after = subprocess.check_output(['systemctl', 'show', 'novonet-mailbox', 'supervm-relay', 'nginx', 'docker',
                                 '--property=Id,ActiveState,MainPID', '--no-pager']).decode()
(output / 'services-after.txt').write_text(after)
require(before == after, 'Existing application service/PID changed')
for name, expected in key_hashes.items():
    require(digest(work / name if name == 'carrier.protected' else state / name) == expected, 'Purpose/carrier custody changed')
write('report.json', dict(status='PASS_B_ORIGINAL_DB_TWO_DISCOVERY_ROTATIONS', source_commit=manifest['git_commit'],
                         manifest_sha256=manifest_pin, artifacts_verified=80, node_sha256=digest(release / 'bin/novovm-node'),
                         runtime=runtime, node_contract=node_contract, elapsed_seconds=elapsed,
                         observed_instances=len({s['instance'] for s in snapshots}), publications=len(snapshots),
                         existing_database=str(state / 'chain-state'), database_initialized=False,
                         purpose_and_carrier_files_unchanged=True, existing_application_services_and_pids_unchanged=True,
                         native_and_multihop_four_host_accepted=False, asset_relay_accepted=False, tps_measured=False))
print('PASS: same original database; 240-second original node run; at least two real discovery rotations; no old service/key changes')
