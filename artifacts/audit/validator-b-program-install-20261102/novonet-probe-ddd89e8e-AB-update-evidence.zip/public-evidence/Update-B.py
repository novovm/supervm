"""Approved B-only candidate update. No initializer, keys, DB copies or app units."""
import hashlib,json,os,pwd,signal,subprocess,sys,tarfile,time
from pathlib import Path
assert os.getuid()==0
incoming=Path('/home/ecs-user/novovm-probe-update-ddd89e8e-20261108')
evidence=incoming/'evidence'
release=Path('/opt/novovm/releases/novonet-probe-ddd89e8e-linux-x86_64')
old_release=Path('/opt/novovm/releases/novonet-08236129-linux-x86_64')
state=Path('/var/lib/novovm/selfrun/91129655606029/B')
old_work=state/'novonet-ce1-20261108'
work=state/'novonet-probe-ddd89e8e-20261108'
old_unit='novovm-B-08236129-network-20261108'
new_unit='novovm-B-ddd89e8e-network-20261108'
uid=pwd.getpwnam('novovm').pw_uid; gid=pwd.getpwnam('novovm').pw_gid
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,value):
    with p.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2)
def services():return subprocess.check_output(['systemctl','show','novonet-mailbox','supervm-relay','nginx','docker','--property=Id,ActiveState,SubState,MainPID','--no-pager']).decode()
def mainpid(unit):return int(subprocess.check_output(['systemctl','show',unit,'--value','-p','MainPID']))
def custody():return {str(p):digest(p) for p in (state/'validator.protected',state/'transport.protected',old_work/'carrier.protected')}
def identity(pid,expected):
    require(pid>1 and Path(f'/proc/{pid}').stat().st_uid==uid,'Target PID owner differs')
    require(os.readlink(f'/proc/{pid}/exe')==str(expected),'Target executable differs')
    return Path(f'/proc/{pid}/stat').read_text().split()[21]
def stop_exact(unit,expected,expected_hash):
    pid=mainpid(unit)
    require(digest(expected)==expected_hash,'Target binary changed before termination')
    epoch=identity(pid,expected)
    require(mainpid(unit)==pid,'Unit PID changed')
    os.kill(pid,signal.SIGTERM)
    stop_signal='SIGTERM'
    for _ in range(100):
        if not Path(f'/proc/{pid}').exists():break
        time.sleep(.1)
    if Path(f'/proc/{pid}').exists():
        require(identity(pid,expected)==epoch,'PID was recycled; refusing termination')
        os.kill(pid,signal.SIGKILL);stop_signal='SIGKILL_after_SIGTERM'
        for _ in range(50):
            if not Path(f'/proc/{pid}').exists():break
            time.sleep(.1)
    require(not Path(f'/proc/{pid}').exists(),'Original PID did not exit')
    result=subprocess.run(['systemctl','show',unit,'-p','Result','-p','ExecMainCode','-p','ExecMainStatus'],capture_output=True,text=True)
    return dict(pid=pid,start_ticks=epoch,signal=stop_signal,scope='interrupted process recovery; not certified graceful drain',unit_result=result.stdout,unit_query_exit=result.returncode,unit_query_stderr=result.stderr)
def launch(unit,root,config,logs):
    require(subprocess.run(['pgrep','-u',str(uid),'-x','novovm-node'],capture_output=True).returncode==1,'Another native node still owns state/ports')
    for name in ('node.stdout','node.stderr'):
        p=logs/name;p.touch(exist_ok=False);os.chown(p,uid,gid);p.chmod(0o600)
    manifest=str(root/'aoem/manifest/aoem-manifest.json')
    env=f'AOEM_DLL_MANIFEST={manifest} NOVOVM_AOEM_MANIFEST={manifest} AOEM_DLL_MANIFEST_REQUIRED=1 AOEM_SEMANTIC_GRAPH_V2_WORKERS=1 NOVOVM_NODE_MODE=native_execution_tick NOVOVM_NATIVE_EXECUTION_CONFIG={config} NOVOVM_NATIVE_EXECUTION_START=existing NOVOVM_NATIVE_EXECUTION_RUN_MS=86400000 NOVOVM_NATIVE_EXECUTION_PIPELINE_PROGRESS_REPORT_PATH={logs / "progress.json"}'
    subprocess.run(['systemd-run','--quiet','--collect','--unit='+unit,'-p','User=novovm','-p','Group=novovm','-p','UMask=0077','-p','RuntimeMaxSec=86520','-p','LoadCredentialEncrypted=owner-key:/etc/novovm/credentials/node-owner-key.cred','-p','Environment='+env,'-p','StandardOutput=append:'+str(logs/'node.stdout'),'-p','StandardError=append:'+str(logs/'node.stderr'),str(root/'bin/novovm-node')],check=True)
    return mainpid(unit)
mode=sys.argv[1]
if mode=='prepare':
    archive=incoming/'novonet-probe-ddd89e8e-linux-x86_64.tar.gz'
    require(digest(archive)=='38f520b3110691cafdb690ff46cb56578c1a7d2682b98ae688b0c5e6dcc03a94','Archive mismatch')
    require(not release.exists() and not work.exists() and not evidence.exists(),'Refuse replacing release/config/evidence')
    evidence.mkdir(mode=0o700)
    with tarfile.open(archive) as bundle:
        for entry in bundle.getmembers():
            parts=Path(entry.name).parts
            require(parts and parts[0]==release.name and '..' not in parts and not entry.name.startswith('/') and (entry.isfile() or entry.isdir()),'Invalid release archive member')
        bundle.extractall(release.parent,filter='data')
    require(digest(release/'release-manifest.json')=='f9845e3bdaef188dc7c40db55f09de6bc75f37cb4cfbb3a3d02939af9aa4802e','Manifest mismatch')
    manifest=json.loads((release/'release-manifest.json').read_text())
    require(manifest['git_commit']=='ddd89e8e05721a2ddb8a7ae9255405d395b39a46' and len(manifest['artifacts'])==80,'Candidate source/count differs')
    for p in (release,*release.rglob('*')):
        require(not p.is_symlink(),'Redirected release');p.chmod(0o755 if p.is_dir() or p.parent==release/'bin' else 0o644)
    for entry in manifest['artifacts']:
        p=release/entry['path'];require(p.is_relative_to(release) and p.stat().st_size==entry['bytes'] and digest(p)==entry['sha256'],'Artifact mismatch: '+entry['path'])
    library=release/manifest['aoem_runtime']['path']
    require(digest(library)=='d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33','AOEM differs')
    env=os.environ.copy();env.update(AOEM_DLL_MANIFEST=str(release/'aoem/manifest/aoem-manifest.json'),NOVOVM_AOEM_MANIFEST=str(release/'aoem/manifest/aoem-manifest.json'),AOEM_DLL_MANIFEST_REQUIRED='1')
    result=subprocess.run([str(release/'bin/novovmctl'),'native-identity','qualify-runtime','--library',str(library),'--library-sha256',digest(library)],capture_output=True,env=env,timeout=120)
    (evidence/'runtime.stdout').write_bytes(result.stdout);(evidence/'runtime.stderr').write_bytes(result.stderr)
    require(result.returncode==0,'Installed runtime qualification failed')
    runtime=json.loads(result.stdout);require(runtime['ok'] and os.path.samefile(runtime['data']['library'],library),'Actual library differs')
    require(all(runtime['data'][k] is True for k in ('verification_qualified','scalar_verification_kat_passed','unified_semantic_verification_kat_passed','mixed_batch_verification_kat_passed')),'Runtime KAT failed')
    config=json.loads((old_work/'run-fixed-08236129.json').read_text());network=json.loads(Path(config['novonet_config_file']).read_text())
    require(config['database']==str(state/'chain-state') and Path(config['database']).is_dir(),'Original state missing')
    write(evidence/'before.json',dict(pid=mainpid(old_unit),services=services(),custody=custody(),config=config,network=network,progress=json.loads((old_work/'progress-B-steady.json').read_text()),locator=json.loads((old_work/'locator-B.json').read_text())))
    require(digest(old_release/'bin/novovm-node')=='2dbb493ac286fed4ca1bbce879d448027d087d1d3d6ff4d3445b3ca5d70bff29','Old binary mismatch')
    identity(mainpid(old_unit),old_release/'bin/novovm-node')
    work.mkdir(mode=0o750);os.chown(work,0,gid)
    (work/'logs').mkdir(mode=0o700);os.chown(work/'logs',uid,gid)
    (work/'commands').mkdir(mode=0o750);os.chown(work/'commands',0,gid)
    network['probe_control_file']=str(work/'commands/control.nvprobe')
    config['library']=str(library);config['novonet_config_file']=str(work/'network.json')
    for name,value in (('run.json',config),('network.json',network)):
        p=work/name;write(p,value);os.chown(p,0,gid);p.chmod(0o440)
    write(evidence/'prepared.json',dict(source=manifest['git_commit'],node_sha256=digest(release/'bin/novovm-node'),aoem_sha256=digest(library),artifacts_verified=80,database=config['database'],start='existing',no_initializer=True,services_unchanged=services()==json.loads((evidence/'before.json').read_text())['services']))
    print('PASS B candidate installed and qualified; original node still running')
elif mode=='update':
    before=json.loads((evidence/'before.json').read_text())
    require(before['services']==services() and before['custody']==custody(),'Services/custody changed before cutover')
    require(mainpid(old_unit)==before['pid'],'Old PID changed before cutover')
    stop=stop_exact(old_unit,old_release/'bin/novovm-node','2dbb493ac286fed4ca1bbce879d448027d087d1d3d6ff4d3445b3ca5d70bff29')
    write(evidence/'old-exit.json',stop)
    try:
        pid=launch(new_unit,release,work/'run.json',work/'logs')
        require(pid>1,'New node PID absent')
        identity(pid,release/'bin/novovm-node')
        for _ in range(120):
            require(mainpid(new_unit)==pid and Path(f'/proc/{pid}').exists(),'New node exited during startup')
            if (work/'logs/progress.json').exists():break
            time.sleep(.5)
        require((work/'logs/progress.json').exists(),'No original node progress')
        progress=json.loads((work/'logs/progress.json').read_text())
        require(progress['chain_id']==91129655606029 and progress['execution_failures']==0,'Recovered node health differs')
        require(before['services']==services() and before['custody']==custody(),'Service/custody post-check mismatch')
        maps=Path(f'/proc/{pid}/maps').read_text();require(str(release/'aoem/linux/core/bin/libaoem_ffi.so') in maps,'New process did not load pinned library')
        write(evidence/'started.json',dict(pid=pid,uid=uid,exe=str(release/'bin/novovm-node'),node_sha256=digest(release/'bin/novovm-node'),aoem_sha256=digest(release/'aoem/linux/core/bin/libaoem_ffi.so'),database=str(state/'chain-state'),start='existing',initialize_executed=False,custody_unchanged=True,other_services_unchanged=True,progress=progress))
        print('PASS B new original node running existing; inspect authenticated Status before A update')
    except Exception as error:
        write(evidence/'startup-failure.json',dict(error=str(error)))
        if mainpid(new_unit)>1:stop_exact(new_unit,release/'bin/novovm-node','603ab7f063274b03e1d81599a57fcb1765b626c04da6d9aef0df963aa24d39cb')
        logs=work/'rollback-logs';logs.mkdir(mode=0o700);os.chown(logs,uid,gid)
        restored=launch('novovm-B-08236129-probe-rollback-20261108',old_release,old_work/'run-fixed-08236129.json',logs)
        write(evidence/'rollback.json',dict(pid=restored,start='existing',reason=str(error)))
        raise
elif mode=='rollback':
    require(digest(old_release/'bin/novovm-node')=='2dbb493ac286fed4ca1bbce879d448027d087d1d3d6ff4d3445b3ca5d70bff29','Original rollback binary differs')
    before=json.loads((evidence/'before.json').read_text())
    require(before['custody']==custody(),'Custody differs; no automatic rollback')
    stop=stop_exact(new_unit,release/'bin/novovm-node','603ab7f063274b03e1d81599a57fcb1765b626c04da6d9aef0df963aa24d39cb')
    logs=work/'rollback-logs';logs.mkdir(mode=0o700);os.chown(logs,uid,gid)
    pid=launch('novovm-B-08236129-probe-rollback-20261108',old_release,old_work/'run-fixed-08236129.json',logs)
    write(evidence/'explicit-rollback.json',dict(old_exit=stop,pid=pid,start='existing',initialize_executed=False))
    print('Original 082 rollback requested using existing; inspect new logs and Status')
else:raise RuntimeError('Unknown operation')
