$ErrorActionPreference='Stop'
$r=Get-NetFirewallRule -Name 'NOVOVM-08236129-A-20261108'
$p=$r|Get-NetFirewallPortFilter;$a=$r|Get-NetFirewallAddressFilter;$app=$r|Get-NetFirewallApplicationFilter
[ordered]@{action=$r.Action.ToString();direction=$r.Direction.ToString();protocol=$p.Protocol;ports=@($p.LocalPort);remote=@($a.RemoteAddress);local=@($a.LocalAddress);program=$app.Program;profiles=@(Get-NetFirewallProfile|Select-Object Name,Enabled);pid=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'"|Select-Object ProcessId,ExecutablePath)}|ConvertTo-Json -Depth 6|Set-Content "$PSScriptRoot/A-rule-actual.json" -Encoding utf8
