"""One authorized fixed B->A non-business health object. No new socket or key."""
import hashlib,json,subprocess,time
from pathlib import Path
work=Path('/var/lib/novovm/selfrun/91129655606029/B/novonet-probe-ddd89e8e-20261108')
root=Path('/opt/novovm/releases/novonet-probe-ddd89e8e-linux-x86_64')
config=json.loads((work/'run.json').read_text())
command=work/'commands/control.nvprobe'
if command.exists():raise RuntimeError('Existing command; refuse replay')
ids=[hashlib.sha256(b'novovm-round-bft/v2/mldsa65/validator-id\0'+bytes(v['public_key'])).hexdigest() for v in config['genesis']['validators']]
result=subprocess.run([str(root/'bin/novovmctl'),'native-network-probe','prepare','--sender',ids[1],'--recipient',ids[0],'--output',str(command)],capture_output=True,text=True)
if result.returncode:raise RuntimeError(result.stderr)
time_limit=time.monotonic()+13
terminal=[]
while time.monotonic()<time_limit:
    time.sleep(.3)
    progress=json.loads((work/'logs/progress.json').read_text())
    terminal=[o for o in progress['native_network_probe']['events'] if o['event'] in ('probe_object_done','probe_expired','probe_expired_before_admission','probe_cancelled')]
    if terminal:break
print(json.dumps(dict(direction='B_to_A',command=json.loads(result.stdout),terminal=terminal,probe=progress['native_network_probe'],local_commands=progress['novonet']['probe_control'],receiver_observation_collected=False,business_receipt=False,four_host_accepted=False),indent=2))
