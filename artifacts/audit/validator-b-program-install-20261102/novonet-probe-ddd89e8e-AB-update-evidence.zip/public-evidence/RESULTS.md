# A/B获批existing更新记录

仅按用户明确批准操作A/B；先B成功，再A。源码固定ddd89e8e，交付记录252f7249；
本轮只读确认该交付提交自动CI42423130454 success，没有触发重跑。

## 通过范围

- B原PID1661875按精确exe/uid/start-time核验后SIGTERM，退出已核；原日志/程序/配置
  保留。新PID1816591，novovm账户，原systemd受保护credential，直接existing原库。
  不称SIGTERM为已认证的完整优雅排空。新程序603ab7f…，实际AOEM d73e4a2f…。
- A原PID30708按LocalService SID/原exe/hash核验后精确终止；未重新运行旧初始化
  任务。新PID24444，原LocalService，新的existing-only任务，原库/钥/原carrier。
  新程序19883c8b…，实际加载AOEM模块哈希1b764a36…；没有初始化或清LOCK。
- Windows/Linux候选在各自安装位置重新逐文件验hash。B包内实际库KAT再通过。
- 两台原状态根更新前/后/最终均f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333。
  Status高度仍0、current_height1；不代表共识继续推进、稳定性、资产业务或TPS通过。
- B其他novonet-mailbox/supervm-relay/nginx/docker服务状态及PID严格不变，三份
  protected材料hash不变，公开transport身份不变。B locator703→719→724，未清计数。
- A监听41051/42051归属新PID；B原41050/42050归属新PID。A最新locator直接读回
  因普通token权限不可读，未冒充缺失/已完整读回。A/B原Status认证查询均通过。
- 诊断显式配置启用，启动初始events0/commands0，证明没有自动发Probe。

## 一条B到A的原生对象发送端证据

只使用原新包ctl向B root-only命令目录发布固定377字节命令。没有新socket/私钥，
原node产生379字节控制对象，1个对象，NativeLifecycle按原sender处理。

- Object ID: 36c112d46a0b31fdce33ccd3e8b5270d2afda6349975912ff767629aa25928dd
- Session ID: 668e6e9ccd7ecd5ce873bbf2c951e658
- 实际路由native_udp，probe_owned → probe_admitted → probe_object_done。
- 依原transfer_tag(session,NVBFT001,object)关联到实际低层反馈：acknowledged_best1、
  feedback_packets2、send_terminal_state=delivered、原TransportDone均存在。
- A接收侧Probe观察未读回，不签双端完整证据，不是A→C或四机，也无Business Receipt。

## 原始失败/限制

1. A切换前首检拒绝：Windows把原/24回显为/255.255.255.0；当时未停止旧节点。
   另取原属性，确认相同子网、端口和程序路径后，按实际规范表示严格重验；没有
   放宽地址范围。只复用已经核验的准备目录/config，未重初始化。
2. 用户此前关闭A三类防火墙。追加授权后，为新程序增加完全同范围UDP规则，保留
   原规则，然后恢复Domain/Private/Public全部启用；之后A/B Status及B→A DONE通过。
3. A→B诊断单独UAC被取消，命令没有执行；没有重弹或假报通过。B→A使用已批准的
   B root通道和原node，未越过A的本地文件权限。A接收日志仍待取得。
4. B新epoch初期1884次unknown_source，后两份快照不增长；authentication等其他
   拒绝类别0，连接失败1→1、stderr为空。来源尚未归因；不以计数停止销账或称历史
   全部已修复。旧epoch96拒绝/105过期/207连接失败仍在原记录，不与新epoch比较归零。
5. 一次SSH内联只读Python命令转义失败，未执行检查；随后用原Collect-B.py核验。
   B无引导seeds时不存在bootstrap cache文件，未把这个按设计可选文件当网络故障。

## 保留/回滚

没有复制运行中的数据库作备份，没有迁移、覆盖、删除DB/journal或再创世。
旧082程序、配置、旧任务及日志保留。Update-A.ps1 -Rollback / Update-B.py rollback
明确是人工后继回滚动作：只停精确新PID，用旧082+旧config、同库existing重开。
本轮未执行回滚，不能称回滚实测通过；辅助脚本语法及明确无initialize调用已检查。
原24h有界运行方式保留，不宣称永久SCM部署。C/D完全未操作，仍原082版本。
后继C更新及A→C双端Object ID/Session ID/接收/ACK/DONE需另获批准。

本ZIP只含公开报告、源码辅助脚本及所列日志。A-before/B-before原始公开配置和
protected材料hash比对底稿仍在A本地，不打包用途材料、carrier或资产私钥、数据库。
