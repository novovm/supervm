$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\A\novonet-probe-ddd89e8e-20261108'
$config=Get-Content "$work/run.json" -Raw|ConvertFrom-Json
$root='C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64'
if((Get-FileHash "$root/bin/novovmctl.exe").Hash.ToLowerInvariant() -cne '690556730d3dea8e5664a4b7d87db77c5bd073175a3f1a1635aa4576ce070f02'){throw 'Fixed ctl differs'}
$ids=@(0,1|ForEach-Object{[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("novovm-round-bft/v2/mldsa65/validator-id`0")+[byte[]]$config.genesis.validators[$_].public_key))).ToLowerInvariant()})
if(Test-Path "$work/commands/control.nvprobe"){throw 'Existing command; no automatic replay'}
& "$root/bin/novovmctl.exe" native-network-probe prepare --sender $ids[0] --recipient $ids[1] --output "$work/commands/control.nvprobe" 1> "$out/A-B-probe-command.json" 2> "$out/A-B-probe-command.stderr"
if($LASTEXITCODE -ne 0){throw 'Local bounded command rejected'}
$end=(Get-Date).AddSeconds(15)
do{
    Start-Sleep -Milliseconds 300
    $progress=Get-Content "$work/logs/progress.json" -Raw|ConvertFrom-Json
    $terminal=@($progress.native_network_probe.events|Where-Object event -In @('probe_object_done','probe_expired','probe_expired_before_admission','probe_cancelled'))
}while(!$terminal.Count -and (Get-Date) -lt $end)
Write-Output ($progress|ConvertTo-Json -Depth 80)|Set-Content "$out/A-progress-after-probe.json" -Encoding utf8
$profiles=@(Get-NetFirewallProfile|Select-Object Name,Enabled)
if(@($profiles|Where-Object {-not $_.Enabled}).Count){throw 'Firewall must remain enabled during this health observation'}
[ordered]@{terminal=$terminal;sender=$ids[0];recipient=$ids[1];firewall=$profiles;old_task=(Get-ScheduledTask -TaskName 'NOVOVM-A-08236129-Network-20261108').State.ToString();old_task_result=(Get-ScheduledTaskInfo -TaskName 'NOVOVM-A-08236129-Network-20261108').LastTaskResult;new_task=(Get-ScheduledTask -TaskName 'NOVOVM-A-ddd89e8e-Existing-20261108').State.ToString()}|ConvertTo-Json -Depth 10|Set-Content "$out/A-B-probe-observation.json" -Encoding utf8
