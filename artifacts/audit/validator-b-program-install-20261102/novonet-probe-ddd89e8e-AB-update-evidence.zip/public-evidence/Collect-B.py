import hashlib,json,os,pwd,subprocess,time
from pathlib import Path
base=Path('/home/ecs-user/novovm-probe-update-ddd89e8e-20261108')
state=Path('/var/lib/novovm/selfrun/91129655606029/B');old=state/'novonet-ce1-20261108';work=state/'novonet-probe-ddd89e8e-20261108'
before=json.loads((base/'evidence/before.json').read_text());config=json.loads((work/'run.json').read_text());network=json.loads((work/'network.json').read_text())
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
services=subprocess.check_output(['systemctl','show','novonet-mailbox','supervm-relay','nginx','docker','--property=Id,ActiveState,SubState,MainPID','--no-pager']).decode()
need(services==before['services'],'Other application services/PIDs changed')
for path,value in before['custody'].items():need(digest(Path(path))==value,'Custody changed')
for field in ('genesis','uca_initialization','peers','database','signing_key_file','transport_key_file','key_storage','udp_addr'):
    need(config[field]==before['config'][field],'Original configuration changed: '+field)
need({k:v for k,v in network.items() if k!='probe_control_file'}==before['network'],'Original network policy changed')
pid=int(subprocess.check_output(['systemctl','show','novovm-B-ddd89e8e-network-20261108','--value','-p','MainPID']))
exe=Path(os.readlink(f'/proc/{pid}/exe'));need(Path(f'/proc/{pid}').stat().st_uid==pwd.getpwnam('novovm').pw_uid,'Wrong process account')
progress=json.loads((work/'logs/progress.json').read_text());locator=json.loads((old/'locator-B.json').read_text())
need(locator['relay_public_key']==before['locator']['relay_public_key'],'Transport public identity changed')
need(locator['sequence']>before['locator']['sequence'],'Locator did not advance')
need(locator['expires_at_ms']>int(time.time()*1000),'Locator expired')
need(progress['execution_failures']==0,'Execution failure')
fields=('chain_id','head','current_height','executed_batches','execution_failures','native_pending_deliveries','native_rejected_messages','native_expired_sends','native_network_probe','novonet')
print(json.dumps(dict(pid=pid,account='novovm',exe=str(exe),node_sha256=digest(exe),aoem_sha256=digest(Path(config['library'])),database=config['database'],start='existing',initialize_executed=False,old_exit=json.loads((base/'evidence/old-exit.json').read_text()),protected_material_unchanged=True,public_identity_unchanged=True,original_config_and_network_policy_unchanged=True,services_before=before['services'],services_after=services,locator_before_sequence=before['locator']['sequence'],locator_after_sequence=locator['sequence'],locator_issued_at_ms=locator['issued_at_ms'],locator_expires_at_ms=locator['expires_at_ms'],transport_identity_sha256=hashlib.sha256(bytes(locator['relay_public_key'])).hexdigest(),progress={k:progress.get(k) for k in fields},listeners=subprocess.check_output(['ss','-ulpn']).decode(),stderr=(work/'logs/node.stderr').read_text()[-8000:]),indent=2))
