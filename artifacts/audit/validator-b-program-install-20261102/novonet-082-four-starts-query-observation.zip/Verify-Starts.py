import hashlib
import json
from pathlib import Path
import zipfile

repo = Path(__file__).resolve().parents[2]
common = json.loads((repo / 'target/novonet-clock-fixed-08236129-20261108/public-inputs/common-approved.json').read_text())
results = []

def decode(raw):
    return json.loads(raw.decode('utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig'))

for host, index in (('C', 2), ('D', 3)):
    folder = repo / f'artifacts/audit/validator-{host.lower()}-novonet-082-start-20261108'
    summary = json.loads((folder / 'public-result.json').read_text(encoding='utf-8-sig'))
    archive = folder / 'original-public-results.zip'
    metadata = summary['public_evidence'] if host == 'C' else summary['raw_evidence']
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == metadata['sha256']
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        entries = {Path(i.filename).name: i for i in bundle.infolist() if not i.is_dir()}
        assert len(entries) == sum(not i.is_dir() for i in bundle.infolist())
        hashes = metadata.get('files', metadata.get('members'))
        for name, pin in hashes.items():
            raw = bundle.read(entries[name])
            assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], (host, name)
        owner = decode(bundle.read(entries['owner.json']))
        initialized = decode(bundle.read(entries['initialize.stdout']))
        locator = decode(bundle.read(entries['locator.json']))
        observation = decode(bundle.read(entries['observation.json']))
        assert owner['sid'] == 'S-1-5-19' and owner['host_id'] == host
        assert owner['purpose_keys_regenerated'] is False
        assert initialized['ok'] is True
        assert initialized['data']['initial_state_root'] == 'f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333'
        assert initialized['data']['chain_id'] == 91129655606029
        assert locator['relay_public_key'] == common['genesis']['validators'][index]['transport_public_key']
        results.append(dict(host=host, original_bytes_verified=True, sid=owner['sid'],
                            initial_root=initialized['data']['initial_state_root'],
                            expected_transport_key_matches=True, raw_observation=observation,
                            network_delivery_accepted=False))
with (Path(__file__).parent / 'starts-verified.json').open('x', encoding='utf-8') as output:
    json.dump(results, output, indent=2)
print('PASS C/D original ZIP/file hashes, actual LocalService, approved root, expected independent transport keys')
