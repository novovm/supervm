import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).parent
destination = root.parents[1] / 'artifacts/audit/validator-b-program-install-20261102/novonet-082-four-starts-query-observation.zip'
names = ['starts-verified.json', 'A-firewall-observed.json', 'Verify-Starts.py', 'Collect-Public.py']
names += [f'status-{host}.{extension}' for host in 'ABCD' for extension in ('json', 'stderr')]
names += ['status-B-capture-41190.json', 'status-B-capture-41190.stderr']
files = {name: (root / name).read_bytes() for name in names}
assert json.loads(files['status-A.json'].decode('utf-8-sig'))['result']['answer']['Status']['state_root'] == list(bytes.fromhex('f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333'))
for host in 'BCD':
    assert 'native query deadline; no fresh node observation' in files[f'status-{host}.stderr'].decode('utf-8-sig')
manifest = dict(scope='startup-and-read-only-query-observation-not-four-host-acceptance',
                program_source='08236129320da2e71c5fa112d249fa7afc741e78',
                query_exit_codes=dict(A=0, B=1, C=1, D=1),
                additional_B_fixed_port_query_exit_code=1,
                B_packet_capture_started=False,
                B_packet_capture_blocker='SSH connection timed out before remote command',
                firewall_fix_executed=False,
                files=[dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in files.items()])
with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in files.items():
        archive.writestr(name, data)
    archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    for name, data in files.items():
        assert archive.read(name) == data
print(json.dumps(dict(path=str(destination), bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest(), entries=len(files)+1)))
