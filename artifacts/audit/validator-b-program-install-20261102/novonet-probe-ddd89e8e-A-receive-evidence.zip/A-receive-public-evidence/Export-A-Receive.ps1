$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'A-receive-readback'
try{
    $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Read-only administrator export required'}
    if(Test-Path $out){throw 'Readback already exists; do not overwrite evidence'}
    New-Item -ItemType Directory -Path $out|Out-Null
    $work='C:\ProgramData\NOVOVM\selfrun\91129655606029\A\novonet-probe-ddd89e8e-20261108'
    $config=Get-Content "$work/run.json" -Raw|ConvertFrom-Json
    $network=Get-Content $config.novonet_config_file -Raw|ConvertFrom-Json
    $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
    if($nodes.Count -ne 1 -or $nodes[0].ExecutablePath -cne 'C:\ProgramData\NOVOVM\releases\novonet-probe-ddd89e8e-windows-x86_64\bin\novovm-node.exe'){throw 'Actual node ownership differs'}
    $sid=(Invoke-CimMethod $nodes[0] -MethodName GetOwnerSid).Sid
    if($sid -cne 'S-1-5-19'){throw 'Actual node is not original LocalService'}
    $nodeHash=(Get-FileHash $nodes[0].ExecutablePath).Hash.ToLowerInvariant()
    if($nodeHash -cne '19883c8b95fc059ec7838ff0556284b1ddd434b7a72bfbe93e3f3410f458a0fc'){throw 'Actual fixed node hash differs'}
    Copy-Item -LiteralPath "$work/logs/progress.json" -Destination "$out/progress-raw.json"
    Copy-Item -LiteralPath $network.public_record_file -Destination "$out/locator-raw.json"
    $progress=Get-Content "$out/progress-raw.json" -Raw|ConvertFrom-Json
    $locator=Get-Content "$out/locator-raw.json" -Raw|ConvertFrom-Json
    $wanted='36c112d46a0b31fdce33ccd3e8b5270d2afda6349975912ff767629aa25928dd'
    $wantedSession='668e6e9ccd7ecd5ce873bbf2c951e658'
    $events=@($progress.native_network_probe.events|Where-Object {[Convert]::ToHexString([byte[]]$_.object_id).ToLowerInvariant() -ceq $wanted})
    $received=@($events|Where-Object {$_.event -ceq 'probe_received_integrity_verified' -and [Convert]::ToHexString([byte[]]$_.session_id).ToLowerInvariant() -ceq $wantedSession})
    $report=[ordered]@{captured_at=(Get-Date).ToString('o');pid=$nodes[0].ProcessId;sid=$sid;node_sha256=$nodeHash;database=$config.database;read_only=$true;node_restarted=$false;permissions_changed=$false;new_object_sent=$false;object_id=$wanted;expected_session_id=$wantedSession;matching_events=$events;matching_verified_receive_count=$received.Count;probe_enabled=$progress.native_network_probe.enabled;evicted_probe_events=$progress.native_network_probe.evicted_events;locator_sequence=$locator.sequence;locator_issued_at_ms=$locator.issued_at_ms;locator_expires_at_ms=$locator.expires_at_ms;native_network=$progress.novonet;native_rejections=$progress.native_network_probe.transport.rejections;diagnostic_coverage=$progress.native_network_probe.transport.contended_observations;business_receipt=$false;four_host_accepted=$false}
    $report|ConvertTo-Json -Depth 25|Set-Content "$out/report.json" -Encoding utf8
    if($received.Count -ne 1){throw 'Historical matching receive not uniquely retained; preserve exported records, do not invent success'}
    'PASS existing A receive event exported and matched; no restart, new object or ACL change'|Set-Content "$PSScriptRoot/A-receive-export-result.txt"
}catch{
    $_.ToString()|Set-Content "$PSScriptRoot/A-receive-export-error.txt"
    throw
}
