# A接收侧只读补证：原B到A固定对象

原程序ddd89e8e，原PID24444/LocalService，未重启。原接收观察一直已由node记录；
前次普通token无法读LocalService目录，而Agent没有单独完成只读导出，是取证收尾
遗漏，不是已经证明接收失败。此前取消的UAC是A到B发命令，不是本次接收导出。
不能将该取消解释成接收记录不存在。后继用户要求修复后，一次只读UAC导出完成。

## 同一历史对象的双端核对

- Object ID 36c112d46a0b31fdce33ccd3e8b5270d2afda6349975912ff767629aa25928dd
- Session ID 668e6e9ccd7ecd5ce873bbf2c951e658
- 原B端probe_object_done，与原A端1条probe_received_integrity_verified匹配。
- 两端object/session/sender/recipient逐字节相同，A事件的实际认证peer就是B发送方。
- 两端实际native_udp；B目标114.92.30.222:61758、A来源47.103.59.206:41050。
  只说明本次会话坐标，不固定动态NAT地址。
- A的64条Probe上下文无淘汰，历史接收事件仍在；新A本地commands仍0，证明没有
  为补证重新发送或构造新对象。B先前保存的低层ACK/DONE原件继续使用，不重写。
- A低层120秒观察保留窗可能已过，本次不声称重新取得该对象全部低层分片日志；
  以仍保留的A完整接收事件和已留存的B低层证据分别关联。
- 两主机wall clock不同，不能用壁钟相减宣称网络延迟或推翻对象生命周期因果关系。

本次另外直接读取A原签名locator，sequence709、在导出时刻新鲜；原发现RPC启用，
installed_bound_peer_routes2、connection_failures0。代码里的global_auto_discovery
和native_multihop_accepted仍false，不因此改为全球自动入网/多跳通过。

## 未发生的操作

没有网络代码修改、权限放宽、节点重启、服务停止、初始化、密钥读取/替换或重发。
只读运行配置（路径/公开配置）、实际进程归属/程序哈希、原progress及公开locator。
未读或导出protected、credential、数据库、journal或资产私钥。
只签本条B到A真实对象的双端有界接管证据，不签Business Receipt、资产执行、
四机、A到C、多跳、SCM或TPS。C/D没有操作，C更新仍须另行批准。
