param([ValidatePattern('^[a-z0-9-]+$')][string]$Run='windows-full-1')
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location D:/WorksArea/SUPERVM
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_BUILD_JOBS='2'
$runtime='D:/WorksArea/SUPERVM/artifacts/runtime-candidates/native-transport-mldsa65-20261103'
$env:NOVOVM_AOEM_TEST_LIBRARY="$runtime/windows/aoem_ffi.dll"
$env:AOEM_DLL_MANIFEST="$runtime/manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:NOVOVM_AOEM_DLL=$env:NOVOVM_AOEM_TEST_LIBRARY
$env:NOVOVM_AOEM_BATCH_UNAVAILABLE_TEST_LIBRARY='D:/WorksArea/SUPERVM/aoem/windows/core/bin/aoem_ffi.dll'
if((Get-FileHash -LiteralPath $env:NOVOVM_AOEM_TEST_LIBRARY).Hash.ToLowerInvariant() -cne '1b764a36c1f782425237d40446d4ea827f56a66fb341b870855d84c15acdce50'){throw 'Pinned runtime differs'}
if((Get-FileHash -LiteralPath $env:NOVOVM_AOEM_BATCH_UNAVAILABLE_TEST_LIBRARY).Hash.ToLowerInvariant() -cne '31306037d7e764bd93e493ff61d4c69952ed1ffc18c2663b5d2c806d815e8947'){throw 'Original counterexample differs'}
$metadata=(& cargo metadata --no-deps --format-version 1|ConvertFrom-Json)
if($LASTEXITCODE -ne 0){throw 'Cargo metadata failed'}
$env:NOVOVM_PRODUCT_NAT_TEST_BINARY=Join-Path $metadata.target_directory 'debug/novovm-product-nat.exe'
foreach($path in @("nat-$Run-build.log","nat-$Run.log","nat-$Run-clippy.log")){if(Test-Path -LiteralPath "$PSScriptRoot/$path"){throw 'Diagnostic log exists; preserve original'}}
& cargo build --locked -p novovm-node --bin novovm-product-nat 2>&1|Tee-Object -FilePath "$PSScriptRoot/nat-$Run-build.log"
if($LASTEXITCODE -ne 0){throw 'Actual NAT executable build failed'}
& cargo test --locked -p novovmctl --test native_identity_cli -- --include-ignored --test-threads=1 --nocapture 2>&1|Tee-Object -FilePath "$PSScriptRoot/nat-$Run.log"
if($LASTEXITCODE -ne 0){throw 'Actual Windows qualification failed'}
if((Get-Content -LiteralPath "$PSScriptRoot/nat-$Run.log" -Raw) -notmatch 'test result: ok\. 7 passed'){throw 'Actual tests not executed'}
& cargo clippy --locked -p novovmctl --test native_identity_cli -- -D warnings 2>&1|Tee-Object -FilePath "$PSScriptRoot/nat-$Run-clippy.log"
if($LASTEXITCODE -ne 0){throw 'Windows strict Clippy failed'}
