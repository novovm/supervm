param([ValidatePattern('^[a-z0-9-]+$')][string]$Run='linux-1',[switch]$SkipBuild,[switch]$All)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
Set-Location /mnt/d/WorksArea/SUPERVM
$env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
$env:CARGO_BUILD_JOBS='2'
$runtime='/mnt/d/WorksArea/SUPERVM/artifacts/runtime-candidates/native-transport-mldsa65-20261103'
$env:NOVOVM_AOEM_TEST_LIBRARY="$runtime/linux/libaoem_ffi.so"
$env:AOEM_DLL_MANIFEST="$runtime/manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:NOVOVM_AOEM_DLL=$env:NOVOVM_AOEM_TEST_LIBRARY
$env:NOVOVM_PRODUCT_NAT_TEST_BINARY="$env:CARGO_TARGET_DIR/debug/novovm-product-nat"
if((Get-FileHash -LiteralPath $env:NOVOVM_AOEM_TEST_LIBRARY).Hash.ToLowerInvariant() -cne 'd73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33'){throw 'Pinned actual Linux runtime differs'}
if(!$SkipBuild){
    & cargo build --locked -p novovm-node --bin novovm-product-nat 2>&1|Tee-Object -FilePath "$PSScriptRoot/nat-$Run-build.log"
    if($LASTEXITCODE -ne 0){throw 'Actual authentication executable build failed'}
}
$log="$PSScriptRoot/nat-$Run.log"
if(Test-Path -LiteralPath $log){throw 'Original diagnostic log exists; do not overwrite'}
if($All){
    $formal='/mnt/d/WorksArea/SUPERVM/aoem/linux/core/bin/libaoem_ffi.so'
    if((Get-FileHash -LiteralPath $formal).Hash.ToLowerInvariant() -cne '4d06f36a67f41035661100ac0fd18c67dcae60bf2cdd5df28db33b555c538309'){throw 'Original counterexample library differs'}
    $env:NOVOVM_AOEM_BATCH_UNAVAILABLE_TEST_LIBRARY=$formal
    & cargo test --locked -p novovmctl --test native_identity_cli -- --include-ignored --test-threads=1 --nocapture 2>&1|Tee-Object -FilePath $log
}else{
    & cargo test --locked -p novovmctl --test native_identity_cli actual_protected_nat_executables_authenticate_and_reconnect_on_the_same_udp_port -- --exact --ignored --test-threads=1 --nocapture 2>&1|Tee-Object -FilePath $log
}
if($LASTEXITCODE -ne 0){throw 'Original native authentication test failed; retain log'}
$expected=if($All){7}else{1}
if((Get-Content -LiteralPath $log -Raw) -notmatch "test result: ok\. $expected passed"){throw 'Actual tests not executed'}
