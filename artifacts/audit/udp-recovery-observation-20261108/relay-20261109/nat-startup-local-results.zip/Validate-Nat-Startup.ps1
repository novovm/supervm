param([ValidatePattern('^[a-z0-9-]+$')][string]$Run)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
if(!$Run){throw 'Unique local evidence label required'}
if($IsLinux){
    Set-Location /mnt/d/WorksArea/SUPERVM
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
    $relative='linux/libaoem_ffi.so'
}else{
    Set-Location D:/WorksArea/SUPERVM
    $relative='windows/aoem_ffi.dll'
}
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_BUILD_JOBS='2'
$runtime=Join-Path (Get-Location) 'artifacts/runtime-candidates/native-transport-mldsa65-20261103'
$env:NOVOVM_AOEM_TEST_LIBRARY=Join-Path $runtime $relative
$env:AOEM_DLL_MANIFEST=Join-Path $runtime 'manifest.json'
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:NOVOVM_AOEM_DLL=$env:NOVOVM_AOEM_TEST_LIBRARY
$steps=@(
    @{Name='bin-test';Args=@('test','--locked','-p','novovm-node','--bin','novovm-product-nat');Expected=1},
    @{Name='runtime-tests';Args=@('test','--locked','-p','novovm-node','--lib','product_nat_runtime::tests','--','--include-ignored','--test-threads=1','--nocapture');Expected=6},
    @{Name='bin-clippy';Args=@('clippy','--locked','-p','novovm-node','--bin','novovm-product-nat','--','-D','warnings');Expected=0},
    @{Name='cli-clippy';Args=@('clippy','--locked','-p','novovmctl','--test','native_identity_cli','--','-D','warnings');Expected=0}
)
foreach($step in $steps){
    $log=Join-Path $PSScriptRoot "nat-$Run-$($step.Name).log"
    if(Test-Path -LiteralPath $log){throw 'Preserve original log'}
    $arguments=$step.Args
    & cargo @arguments 2>&1|Tee-Object -FilePath $log
    if($LASTEXITCODE -ne 0){throw "$($step.Name) failed; preserve original output"}
    if($step.Expected -gt 0 -and (Get-Content -LiteralPath $log -Raw) -notmatch "test result: ok\. $($step.Expected) passed"){throw 'Expected tests did not execute'}
}
