param([switch]$Linux, [string]$Label='fixed', [string]$Filter='native_lifecycle::', [switch]$Clippy)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
Set-Location $repo
$platform=if($Linux){'linux'}else{'windows'}
$env:CARGO_TARGET_DIR=if($Linux){'/home/aoem-a1/novovm-build-b-20261102'}else{'C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'}
$env:CARGO_BUILD_JOBS='2'
$pkg="$repo/artifacts/product-overlay/novonet-observation-e7b0cca7-$platform-x86_64"
$env:NOVOVM_AOEM_TEST_LIBRARY=if($Linux){"$pkg/aoem/linux/core/bin/libaoem_ffi.so"}else{"$pkg/aoem/windows/core/bin/aoem_ffi.dll"}
if(!(Test-Path $env:NOVOVM_AOEM_TEST_LIBRARY)){throw 'Missing actual AOEM library'}
$env:AOEM_DLL_MANIFEST="$pkg/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$log="$repo/target/native-time-upgrade-20261110/time-expiry-$platform-$Label.log"
if(Test-Path $log){throw 'Evidence already exists'}
if($Clippy){
    & cargo clippy --release --locked -p novovm-node --lib --tests --features iroh-transport -- -D warnings 2>&1 | Tee-Object -FilePath $log
}else{
    & cargo test --release --locked -p novovm-node --lib --features iroh-transport $Filter -- --include-ignored --test-threads=1 --nocapture 2>&1 | Tee-Object -FilePath $log
}
exit $LASTEXITCODE
