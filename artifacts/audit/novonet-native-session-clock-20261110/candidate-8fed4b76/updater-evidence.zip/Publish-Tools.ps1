$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:/WorksArea/SUPERVM'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110'
$tools=Join-Path $delivery 'update-tools'
$audit="$repo/artifacts/audit/novonet-native-session-clock-20261110/candidate-8fed4b76"
& "$tools/Test-Update-Windows.ps1" -PackageRoot "$repo/artifacts/product-overlay/novonet-observation-8fed4b76-windows-x86_64" *> "$delivery/updater-windows-tests.log"
if(!$?){throw 'Windows updater qualification failed'}
& wsl -d Ubuntu-24.04 -- bash -lc 'python3 /mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110/update-tools/test_update_b.py' *> "$delivery/updater-linux-tests.log"
if($LASTEXITCODE -ne 0){throw 'Linux updater qualification failed'}
$zip=Join-Path $audit 'existing-update-tools-8fed4b76.zip'
if(Test-Path -LiteralPath $zip){throw 'Preserve existing tool bundle'}
$names=@('Update-Windows.ps1','Test-Update-Windows.ps1','NovonetExistingProcess.ps1','Update-B.py','test_update_b.py','Read-Status.ps1','Prepare-OperatorRule.ps1','Check-Full.ps1')
Compress-Archive -LiteralPath @($names|ForEach-Object {Join-Path $tools $_}) -DestinationPath $zip
$manifest=[ordered]@{
    source='8fed4b76f518935b30fcfb13930ccd3d7aae7381'
    tool_archive_sha256=(Get-FileHash $zip).Hash.ToLowerInvariant()
    tool_archive_bytes=(Get-Item $zip).Length
    files=@($names|ForEach-Object {[ordered]@{name=$_;sha256=(Get-FileHash (Join-Path $tools $_)).Hash.ToLowerInvariant()}})
    windows_updater_groups=10
    windows_updater_actual_package_verified=$true
    linux_updater_tests=13
    scope='Offline updater gates; no installed node changed. Initial generated Windows test still expected historical 082/5181; retained and corrected to verified current 1ef pins. No updater or node assertion was relaxed.'
}
$manifest|ConvertTo-Json -Depth 8|Out-File "$audit/update-tools-manifest.json" -NoClobber -Encoding utf8
Compress-Archive -LiteralPath "$delivery/updater-windows-tests.log","$delivery/updater-linux-tests.log","$tools/Test-Update-Windows.pre-mapping.txt","$PSScriptRoot/Prepare-Update.ps1","$PSScriptRoot/Publish-Tools.ps1" -DestinationPath "$audit/updater-evidence.zip"
Copy-Item -LiteralPath "$delivery/local-original-recovery.zip" -Destination "$audit/local-original-recovery.zip"
Copy-Item -LiteralPath "$PSScriptRoot/UPGRADE.md" -Destination "$audit/UPGRADE.md"
$manifest|ConvertTo-Json -Depth 8
