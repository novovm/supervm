param(
    [Parameter(Mandatory)][ValidateSet('A','B','C','D')][string]$HostId,
    [Parameter(Mandatory)][ValidateSet('before','after')][string]$Phase
)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='D:/WorksArea/SUPERVM'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110'
$root=if($Phase -eq 'before'){"$repo/artifacts/product-overlay/novonet-sqlite-3fa11f94-windows-x86_64"}else{"$repo/artifacts/product-overlay/novonet-observation-8fed4b76-windows-x86_64"}
$client="$root/bin/novovm-native-client.exe"
$pin=if($Phase -eq 'before'){'9d8ae5db7532c59f3ae445c8176a66bc0f608d6d97e2133977b2f13065109cc2'}else{
    $v=Get-Content "$delivery/verified-windows.json" -Raw|ConvertFrom-Json
    if($v.source_commit -cne '8fed4b76f518935b30fcfb13930ccd3d7aae7381'){throw 'Wrong fixed client source'}
    $v.client_sha256
}
if((Get-FileHash -LiteralPath $client).Hash.ToLowerInvariant() -cne $pin){throw 'Fixed operator changed'}
$base="$repo/target/novonet-four-host-live-20261108"
$config=Join-Path $base $(if($HostId -eq 'B'){'client-B-capture-41190.json'}else{"client-$HostId.json"})
$env:AOEM_DLL_MANIFEST="$root/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$out=Join-Path $delivery "authenticated-$HostId-$Phase"
if(Test-Path -LiteralPath $out){throw 'Preserve existing health evidence'}
New-Item -ItemType Directory -Path $out|Out-Null
& $client $config status 1> "$out/original.json" 2> "$out/original.stderr"
if($LASTEXITCODE -ne 0){throw 'Authenticated Status failed'}
$result=Get-Content "$out/original.json" -Raw|ConvertFrom-Json
$status=$result.result.answer.Status
$stateRoot=[Convert]::ToHexString([byte[]]$status.state_root).ToLowerInvariant()
if($result.scope -cne 'native_sdk_operator_v1' -or $result.chain_id -ne 91129655606029 -or $stateRoot -cne 'f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333' -or $status.recovering -or $status.projection_failed -or $status.height -ne 0 -or $status.current_height -ne 1){throw 'Original state/health differs'}
Write-Output "PASS $HostId $Phase authenticated Status: $($result.elapsed_ms)ms; root=$stateRoot; not Object DONE"
