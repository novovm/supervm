# One read of the already-dispatched fixed run; never dispatch, retry or cancel CI.
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$source='8fed4b76f518935b30fcfb13930ccd3d7aae7381'
$id='42776380753'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110'
$raw=& gh api "repos/novovm/supervm/actions/runs/$id"
if($LASTEXITCODE -ne 0){throw 'Unable to read fixed Full run'}
$run=$raw|ConvertFrom-Json
if($run.head_sha -cne $source -or $run.event -cne 'workflow_dispatch' -or $run.run_attempt -ne 1){throw 'Wrong Full source/event/attempt'}
$jobsRaw=& gh api "repos/novovm/supervm/actions/runs/$id/jobs?per_page=100"
if($LASTEXITCODE -ne 0){throw 'Unable to read Full jobs'}
$jobs=$jobsRaw|ConvertFrom-Json
if($jobs.total_count -ne $jobs.jobs.Count){throw 'Incomplete job page'}
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
foreach($pair in @(@("ci-run-$stamp.json",$raw),@("ci-jobs-$stamp.json",$jobsRaw))){
    $stream=[IO.File]::Open((Join-Path $delivery $pair[0]),[IO.FileMode]::CreateNew)
    try{$stream.Write([Text.UTF8Encoding]::new($false).GetBytes(($pair[1] -join "`n")))}finally{$stream.Dispose()}
}
$candidate=@($jobs.jobs|Where-Object name -CEQ 'Full candidate result')
$aggregate=@($jobs.jobs|Where-Object name -CEQ 'CI scope result')
if($run.status -cne 'completed' -or $run.conclusion -cne 'success' -or $candidate.Count -ne 1 -or $candidate[0].conclusion -cne 'success' -or $aggregate.Count -ne 1 -or $aggregate[0].conclusion -cne 'success'){
    throw "Fixed Full not qualified: $($run.status)/$($run.conclusion); preserve existing nodes"
}
Write-Output "PASS exact-source Full $id attempt 1; deployment and real-network acceptance remain separate"
