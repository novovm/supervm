# Same existing UDP reply rule, bound to the fixed new native operator only.
# This is not node cutover and does not alter any firewall profile.
#Requires -Version 7.0
$ErrorActionPreference='Stop'
$principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator PowerShell required'}
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110'
$client='D:\WorksArea\SUPERVM\artifacts\product-overlay\novonet-observation-8fed4b76-windows-x86_64\bin\novovm-native-client.exe'
$verified=Get-Content "$delivery/verified-windows.json" -Raw|ConvertFrom-Json
if($verified.source_commit -cne '8fed4b76f518935b30fcfb13930ccd3d7aae7381' -or (Get-FileHash $client).Hash.ToLowerInvariant() -cne $verified.client_sha256){throw 'Fixed client mismatch'}
$oldName='UDP Query User{71CE9FCC-0EEB-4C2D-BD5D-7F1C1BFB8770}D:\worksarea\supervm\artifacts\product-overlay\novonet-sqlite-3fa11f94-windows-x86_64\bin\novovm-native-client.exe'
$newName='NOVOVM-Operator-8fed4b76-UDP-20261110'
$before=@(Get-NetFirewallProfile|Select-Object Name,Enabled)
$old=Get-NetFirewallRule -Name $oldName
$port=$old|Get-NetFirewallPortFilter
$app=$old|Get-NetFirewallApplicationFilter
if($old.Enabled -ne 'True' -or $old.Action -ne 'Allow' -or $old.Direction -ne 'Inbound' -or $port.Protocol -ne 'UDP' -or $app.Program -ine 'D:\worksarea\supervm\artifacts\product-overlay\novonet-sqlite-3fa11f94-windows-x86_64\bin\novovm-native-client.exe'){throw 'Original operator rule changed'}
if(Get-NetFirewallRule -Name $newName -ErrorAction SilentlyContinue){throw 'Rule already exists; inspect instead of repeating'}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile("$delivery/update-tools/Update-Windows.ps1",[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Original updater parse failed'}
$fn=@($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -ceq 'Assert-FirewallFilterScope'},$false))
if($fn.Count -ne 1){throw 'Original firewall comparison missing'}
. ([scriptblock]::Create($fn[0].Extent.Text))
Copy-NetFirewallRule -Name $oldName -NewName $newName|Out-Null
Get-NetFirewallRule -Name $newName|Get-NetFirewallApplicationFilter|Set-NetFirewallApplicationFilter -Program $client
$fresh=Get-NetFirewallRule -Name $newName
foreach($command in @('Get-NetFirewallPortFilter','Get-NetFirewallAddressFilter','Get-NetFirewallInterfaceFilter','Get-NetFirewallInterfaceTypeFilter','Get-NetFirewallSecurityFilter','Get-NetFirewallServiceFilter')){
    Assert-FirewallFilterScope (& $command -AssociatedNetFirewallRule $old) (& $command -AssociatedNetFirewallRule $fresh) $oldName $newName
}
if($fresh.Profile -ne $old.Profile -or $fresh.Enabled -ne $old.Enabled -or $fresh.Direction -ne $old.Direction -or $fresh.Action -ne $old.Action -or ($fresh|Get-NetFirewallApplicationFilter).Program -ine $client){throw 'Copied policy differs'}
if(($before|ConvertTo-Json -Compress) -cne (@(Get-NetFirewallProfile|Select-Object Name,Enabled)|ConvertTo-Json -Compress)){throw 'Profiles changed'}
[ordered]@{source=$verified.source_commit;client_sha256=$verified.client_sha256;old_rule=$oldName;new_rule=$newName;scope_unchanged=$true;profiles_unchanged=$true;node_changed=$false}|ConvertTo-Json|Out-File "$delivery/operator-rule.json" -NoClobber -Encoding utf8
Write-Output 'PASS same-scope new operator rule; old rule preserved; no node changed'
