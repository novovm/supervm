param(
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$Source,
    [Parameter(Mandatory)][ValidateSet('Build','Verify','Qualify','Archive')][string]$Phase,
    [switch]$Linux
)
$ErrorActionPreference='Stop'
$short=$Source.Substring(0,8)
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$deliveryName="candidate-observation-$short-20261110"
$delivery=if($Linux){"/mnt/c/Users/leadb/AppData/Local/NOVOVM/$deliveryName"}else{"C:/Users/leadb/AppData/Local/NOVOVM/$deliveryName"}
$package="novonet-observation-$short"
New-Item -ItemType Directory -Path $delivery -Force | Out-Null
Set-Location $repo
switch($Phase){
    'Build' {
        $platform=if($Linux){'linux'}else{'windows'}
        $env:AOEM_DLL_MANIFEST="$repo/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-$platform-x86_64/aoem/manifest/aoem-manifest.json"
        $env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
        $env:AOEM_DLL_MANIFEST_REQUIRED='1'
        $script=Get-Content "$repo/target/relay-evidence-20261109/Build-Sqlite-Candidate.ps1" -Raw
        if(!$script.Contains('3fa11f940b18e54b46e6b927d3d66294bea37088')){throw 'Original build wrapper changed'}
        $script=$script.Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$Source).Replace('candidate-sqlite-3fa11f94-20261110',$deliveryName).Replace('novonet-sqlite-3fa11f94',$package)
    }
    'Verify' {
        $script=Get-Content "$repo/target/novonet-probe-candidate-20261108/Verify.ps1" -Raw
        if(!$script.Contains('ddd89e8e05721a2ddb8a7ae9255405d395b39a46')){throw 'Original verifier changed'}
        $script=$script.Replace('ddd89e8e05721a2ddb8a7ae9255405d395b39a46',$Source).Replace('novonet-probe-ddd89e8e',$package)
        $script=$script.Replace('$PSScriptRoot',("'"+$delivery.Replace("'","''")+"'"))
    }
    'Qualify' {
        $script=Get-Content "$repo/target/relay-evidence-20261109/Qualify-Coordinated-Package.ps1" -Raw
        if(!$script.Contains('2b97fc8e5d1f83c521669e6f82803794ad4fd5ed')){throw 'Original qualifier changed'}
        $script=$script.Replace('2b97fc8e5d1f83c521669e6f82803794ad4fd5ed',$Source).Replace('delivery-2b97fc8e-20261109',$deliveryName).Replace('novonet-relay-evidence-2b97fc8e',$package)
        $script=$script.Replace('$env:CARGO_TARGET_DIR="$repo/target/runtime-rebuild"',"`$env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'")
        $target=if($Linux){'x86_64-unknown-linux-gnu'}else{'x86_64-pc-windows-msvc'}
        $script=$script.Replace('& cargo test --locked',"& cargo test --release --target $target --locked")
    }
    'Archive' {
        $name=if($Linux){'Archive-Coordinated-Linux.ps1'}else{'Archive-Coordinated-Windows.ps1'}
        $script=Get-Content "$repo/target/relay-evidence-20261109/$name" -Raw
        $script=$script.Replace('delivery-2b97fc8e-20261109',$deliveryName).Replace('novonet-relay-evidence-2b97fc8e',$package)
    }
}
if($Phase -eq 'Archive'){ & ([scriptblock]::Create($script)) }
else { & ([scriptblock]::Create($script)) -Linux:$Linux }
