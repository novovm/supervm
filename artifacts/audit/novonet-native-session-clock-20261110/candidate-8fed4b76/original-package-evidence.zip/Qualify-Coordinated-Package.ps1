param([switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$delivery=if($Linux){'/mnt/c/Users/leadb/AppData/Local/NOVOVM/delivery-2b97fc8e-20261109'}else{'C:/Users/leadb/AppData/Local/NOVOVM/delivery-2b97fc8e-20261109'}
$platform=if($Linux){'linux'}else{'windows'}
Set-Location $repo
if($Linux){
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
}else{
    $env:CARGO_TARGET_DIR="$repo/target/runtime-rebuild"
}
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_BUILD_JOBS='2'
$root="$repo/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-$platform-x86_64"
$verification=Get-Content -LiteralPath "$delivery/verified-$platform.json" -Raw|ConvertFrom-Json
$manifest=Get-Content -LiteralPath "$root/release-manifest.json" -Raw|ConvertFrom-Json
if($verification.source_commit -cne '2b97fc8e5d1f83c521669e6f82803794ad4fd5ed' -or $manifest.git_commit -cne $verification.source_commit -or $verification.manifest_sha256 -cne (Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant()){throw 'Independently verified source/manifest required'}
$extension=if($Linux){''}else{'.exe'}
$env:NOVOVM_AOEM_TEST_LIBRARY=Join-Path $root $manifest.aoem_runtime.path
$env:AOEM_DLL_MANIFEST="$root/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:NOVOVM_AOEM_DLL=$env:NOVOVM_AOEM_TEST_LIBRARY
$env:NOVOVM_CTL_TEST_BINARY="$root/bin/novovmctl$extension"
$env:NOVOVM_PRODUCT_NAT_TEST_BINARY="$root/bin/novovm-product-nat$extension"
$env:NOVOVM_AOEM_BATCH_UNAVAILABLE_TEST_LIBRARY=if($Linux){"$repo/aoem/linux/core/bin/libaoem_ffi.so"}else{"$repo/aoem/windows/core/bin/aoem_ffi.dll"}
$log="$delivery/packaged-native-identity-$platform.log"
if(Test-Path -LiteralPath $log){throw 'Preserve original qualification output'}
& cargo test --locked -p novovmctl --test native_identity_cli -- --include-ignored --test-threads=1 --nocapture *>&1|Tee-Object -FilePath $log
if($LASTEXITCODE -ne 0){throw 'Actual packaged CLI/NAT qualification failed'}
if((Get-Content -LiteralPath $log -Raw) -notmatch 'test result: ok\. 7 passed'){throw 'Actual package tests not executed'}
if((Get-FileHash "$root/bin/novovmctl$extension").Hash.ToLowerInvariant() -cne $verification.ctl_sha256){throw 'Packaged ctl changed'}
Write-Output 'PASS actual packaged protected identity/NAT/reconnect/counterexamples; not deployed'
