param([switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$source='3fa11f940b18e54b46e6b927d3d66294bea37088'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$delivery=if($Linux){'/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'}else{'C:/Users/leadb/AppData/Local/NOVOVM/candidate-sqlite-3fa11f94-20261110'}
$platform=if($Linux){'linux'}else{'windows'}
if($Linux){
    function global:git { & '/mnt/c/Program Files/Git/cmd/git.exe' -C 'D:/WorksArea/SUPERVM' @args }
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
}else{
    $env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'
}
Set-Location $repo
if((git rev-parse HEAD).Trim() -cne $source -or @(git status --porcelain).Count){throw 'Not the clean frozen source'}
$env:RUSTUP_TOOLCHAIN='1.94.0';$env:CARGO_BUILD_JOBS='2'
$runtime="$repo/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-$platform-x86_64/aoem"
$hash=if($Linux){'d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33'}else{'1b764a36c1f782425237d40446d4ea827f56a66fb341b870855d84c15acdce50'}
$target=if($Linux){'x86_64-unknown-linux-gnu'}else{'x86_64-pc-windows-msvc'}
$log="$delivery/build-$platform.log"
if(Test-Path -LiteralPath $log){throw 'Preserve original build evidence'}
& "$repo/scripts/novovm-package-product-linux.ps1" -Target $target -PackageDir "artifacts/product-overlay/novonet-sqlite-3fa11f94-$platform-x86_64" -AoemPackageRoot $runtime -AoemCoreSha256 $hash *>&1|Tee-Object -FilePath $log
if($LASTEXITCODE -ne 0){throw 'Original packager failed'}
if((git rev-parse HEAD).Trim() -cne $source -or @(git status --porcelain).Count){throw 'Source changed during build'}
Write-Output 'PASS fixed-source build; not deployed'
