param([switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$source='ddd89e8e05721a2ddb8a7ae9255405d395b39a46'
$platform=if($Linux){'linux'}else{'windows'}
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$root=(Resolve-Path -LiteralPath "$repo/artifacts/product-overlay/novonet-probe-ddd89e8e-$platform-x86_64").Path
$manifest=Get-Content -LiteralPath "$root/release-manifest.json" -Raw | ConvertFrom-Json
if($manifest.git_commit -cne $source){throw 'Frozen source differs'}
$comparison=if($Linux){[StringComparison]::Ordinal}else{[StringComparison]::OrdinalIgnoreCase}
$expectedChecksums=@()
foreach($entry in $manifest.artifacts){
    $path=[IO.Path]::GetFullPath((Join-Path $root $entry.path))
    if(!$path.StartsWith($root+[IO.Path]::DirectorySeparatorChar,$comparison)){throw 'Artifact escaped package'}
    $item=Get-Item -LiteralPath $path
    if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.LinkType){throw 'Redirected artifact'}
    if($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $entry.sha256){throw "Artifact mismatch: $($entry.path)"}
    $expectedChecksums+="$($entry.sha256)  $($entry.path)"
}
if(@(Compare-Object @(Get-Content -LiteralPath "$root/CHECKSUMS.sha256") $expectedChecksums -SyncWindow 0).Count){throw 'Checksum index differs'}
$contracts=@($manifest.build_contracts|Where-Object binary -CEQ 'novovm-node')
if($contracts.Count -ne 1 -or $contracts[0].cargo_features -notcontains 'iroh-transport'){throw 'Actual fallback feature missing'}
$extension=if($Linux){''}else{'.exe'}
$library=Join-Path $root $manifest.aoem_runtime.path
$env:AOEM_DLL_MANIFEST="$root/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$runtimeOutput=@(& "$root/bin/novovmctl$extension" native-identity qualify-runtime --library $library --library-sha256 $manifest.aoem_runtime.sha256)
if($LASTEXITCODE -ne 0){throw 'Copied runtime qualification failed'}
$runtime=$runtimeOutput -join "`n" | ConvertFrom-Json
if(!$runtime.ok -or $runtime.data.algorithm -cne 'ML-DSA-65' -or $runtime.data.signature_suite -ne 65 -or $runtime.data.library_sha256 -cne $manifest.aoem_runtime.sha256){throw 'Runtime identity differs'}
$actual=$runtime.data.library
if(!$Linux -and $actual.StartsWith('\\?\')){$actual=$actual.Substring(4)}
if(![string]::Equals([IO.Path]::GetFullPath($actual),[IO.Path]::GetFullPath($library),$comparison)){throw 'Actually loaded a different library'}
foreach($field in @('verification_qualified','scalar_verification_kat_passed','unified_semantic_verification_kat_passed','mixed_batch_verification_kat_passed','primitive_sign_interface_size_checked')){
    if($runtime.data.$field -isnot [bool] -or !$runtime.data.$field){throw "KAT failed: $field"}
}
foreach($field in @('signing_tested','keygen_tested','protected_key_created','custody_accessed','database_created','service_started','whole_node_post_quantum_qualified')){
    if($runtime.data.$field -isnot [bool] -or $runtime.data.$field){throw "Offline scope exceeded: $field"}
}
$nodeOutput=@(& "$root/bin/novovm-node$extension" --service-contract)
if($LASTEXITCODE -ne 0){throw 'Actual node contract failed'}
$node=$nodeOutput -join "`n" | ConvertFrom-Json
if($node.contract -cne 'windows-scm-existing-v1' -or $node.platform -cne $platform -or $node.entry -cne 'native_execution_tick' -or $node.start_mode -cne 'existing' -or $node.supported -ne (!$Linux)){throw 'Node contract differs'}
foreach($field in @('service_started','database_opened','custody_accessed')){if($node.$field -isnot [bool] -or $node.$field){throw 'Node exceeded offline scope'}}
$command=Join-Path $PSScriptRoot "offline-$platform.nvprobe"
if(Test-Path $command){throw 'Refuse replacing existing smoke command'}
$prepareOutput=@(& "$root/bin/novovmctl$extension" native-network-probe prepare --sender ('11'*32) --recipient ('22'*32) --output $command)
if($LASTEXITCODE -ne 0){throw 'Packaged probe prepare failed'}
$prepare=$prepareOutput -join "`n" | ConvertFrom-Json
if(!$prepare.ok -or (Get-Item $command).Length -ne 377){throw 'Bounded binary prepare failed'}
$cancelOutput=@(& "$root/bin/novovmctl$extension" native-network-probe cancel --from $command --output $command)
if($LASTEXITCODE -ne 0){throw 'Packaged probe cancel failed'}
$cancel=$cancelOutput -join "`n" | ConvertFrom-Json
if(!$cancel.ok -or (Get-Item $command).Length -ne 377){throw 'Bounded binary cancel failed'}
foreach($result in @($prepare,$cancel)){
    foreach($field in @('sent','object_done','business_receipt','node_started')){
        if($result.data.$field -isnot [bool] -or $result.data.$field){throw "Probe exceeded offline scope: $field"}
    }
}
$output=Join-Path $PSScriptRoot "verified-$platform.json"
if(Test-Path $output){throw 'Refuse overwriting evidence'}
[ordered]@{source_commit=$manifest.git_commit;platform=$platform;package=$root;manifest_sha256=(Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant();artifacts_verified=$manifest.artifacts.Count;artifacts_bytes=($manifest.artifacts|Measure-Object bytes -Sum).Sum;node_sha256=(Get-FileHash "$root/bin/novovm-node$extension").Hash.ToLowerInvariant();client_sha256=(Get-FileHash "$root/bin/novovm-native-client$extension").Hash.ToLowerInvariant();ctl_sha256=(Get-FileHash "$root/bin/novovmctl$extension").Hash.ToLowerInvariant();actual_packaged_runtime=$runtime;actual_packaged_node_contract=$node;probe_prepare=$prepare;probe_cancel=$cancel;four_host_accepted=$false;service_started=$false;database_created=$false;tps_measured=$false}|ConvertTo-Json -Depth 9|Set-Content -LiteralPath $output -Encoding utf8
Write-Output "PASS independent copied-package verification: $output"
