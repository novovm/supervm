$ErrorActionPreference='Stop'
$repo='/mnt/d/WorksArea/SUPERVM'
$delivery='/mnt/c/Users/leadb/AppData/Local/NOVOVM/delivery-2b97fc8e-20261109'
$name='novonet-relay-evidence-2b97fc8e-linux-x86_64'
$archive="$delivery/$name.tar.gz"
if(Test-Path -LiteralPath $archive){throw 'Preserve archive'}
if(!(Test-Path -LiteralPath "$delivery/verified-linux.json")){throw 'Actual verification required'}
& tar -czf $archive -C "$repo/artifacts/product-overlay" $name
if($LASTEXITCODE -ne 0){throw 'Archive creation failed'}
& tar -df $archive -C "$repo/artifacts/product-overlay"
if($LASTEXITCODE -ne 0){throw 'Archive differs from independently verified package'}
Write-Output "PASS original tar archive and diff: $archive"
