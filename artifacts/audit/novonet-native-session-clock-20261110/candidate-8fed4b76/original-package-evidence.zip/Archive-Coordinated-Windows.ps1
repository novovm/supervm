$ErrorActionPreference='Stop'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/delivery-2b97fc8e-20261109'
$root='D:/WorksArea/SUPERVM/artifacts/product-overlay/novonet-relay-evidence-2b97fc8e-windows-x86_64'
$archive="$delivery/novonet-relay-evidence-2b97fc8e-windows-x86_64.zip"
if(Test-Path -LiteralPath $archive){throw 'Preserve archive'}
if(!(Test-Path -LiteralPath "$delivery/verified-windows.json")){throw 'Actual verification required'}
Compress-Archive -LiteralPath $root -DestinationPath $archive -CompressionLevel Optimal
Write-Output "Created candidate archive; independent ZIP-member verification still required: $archive"
