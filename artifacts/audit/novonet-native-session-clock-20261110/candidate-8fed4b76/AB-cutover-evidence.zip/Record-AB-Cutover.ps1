$ErrorActionPreference='Stop'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-8fed4b76-20261110'
$audit='D:/WorksArea/SUPERVM/artifacts/audit/novonet-native-session-clock-20261110/candidate-8fed4b76'
$controller=Get-Content "$delivery/cutover-controller.json" -Raw|ConvertFrom-Json
if($controller.phase -cne 'AB_existing_and_authenticated_status_pass'){throw 'AB cutover incomplete'}
$runFile=Get-ChildItem "$delivery/ci-run-*.json"|Sort-Object LastWriteTimeUtc|Select-Object -Last 1
$jobsFile=Join-Path $delivery $runFile.Name.Replace('ci-run-','ci-jobs-')
$run=Get-Content $runFile.FullName -Raw|ConvertFrom-Json
$jobs=Get-Content $jobsFile -Raw|ConvertFrom-Json
if($run.head_sha -cne $controller.source -or $run.id -ne 42776380753 -or $run.run_attempt -ne 1 -or $run.conclusion -cne 'success'){throw 'Full mismatch'}
foreach($name in @('Rust checks','CI scope result','Full candidate result')){
    $job=@($jobs.jobs|Where-Object name -CEQ $name)
    if($job.Count -ne 1 -or $job[0].conclusion -cne 'success'){throw "Gate not successful: $name"}
}
$a=Get-Content "$delivery/A-update/after.json" -Raw|ConvertFrom-Json
$b=Get-Content "$delivery/B-started-original.json" -Raw|ConvertFrom-Json
$packages=(Get-Content "$audit/candidate-manifest.json" -Raw|ConvertFrom-Json).packages
$rows=@()
foreach($tuple in @(@('A','windows',$a),@('B','linux',$b))){
    $hostId,$platform,$receipt=$tuple
    $pin=$packages|Where-Object platform -CEQ $platform
    if($receipt.source -cne $controller.source -or $receipt.node_sha256 -cne $pin.node_sha256 -or $receipt.aoem_sha256 -cne $pin.aoem_sha256 -or !$receipt.custody_unchanged -or $receipt.start -cne 'existing' -or $receipt.initialize_executed){throw 'Deployment receipt mismatch'}
    $status=Get-Content "$delivery/authenticated-$hostId-after/original.json" -Raw|ConvertFrom-Json
    $answer=$status.result.answer.Status
    $root=[Convert]::ToHexString([byte[]]$answer.state_root).ToLowerInvariant()
    if($root -cne 'f6186d40260aa18e84b01101d56ca3e918aff799ef41d927aeab554495f56333' -or $answer.recovering -or $answer.projection_failed){throw 'External state mismatch'}
    $rows += [ordered]@{host_id=$hostId;pid=$receipt.pid;source=$receipt.source;node_sha256=$receipt.node_sha256;aoem_sha256=$receipt.aoem_sha256;database=$receipt.database;start=$receipt.start;custody_unchanged=$receipt.custody_unchanged;initialize_executed=$false;current_height=$answer.current_height;finalized_height=$answer.height;state_root=$root;authenticated_status_ms=$status.elapsed_ms;object_DONE_verified=$false}
}
$public=[ordered]@{source=$controller.source;full_run=$run.id;full_attempt=$run.run_attempt;full_conclusion=$run.conclusion;completed_utc=$controller.completed_utc;hosts=$rows;C_update_released=$true;D_waits_for_C_and_A_query=$true;scope='B/A existing cutover and external authenticated Status; not four-host object or business acceptance'}
$public|ConvertTo-Json -Depth 10|Out-File "$audit/AB-CUTOVER-PUBLIC.json" -Encoding utf8 -NoClobber
$files=@($runFile.FullName,$jobsFile,"$delivery/cutover-controller.json","$delivery/full-final-check.log","$delivery/A-update.log","$delivery/B-update.log","$delivery/A-update/result.json","$delivery/A-update/old-exit.json","$delivery/A-authenticated-after.log","$delivery/B-authenticated-after.log",$PSCommandPath)
Compress-Archive -LiteralPath $files -DestinationPath "$audit/AB-cutover-evidence.zip"
$public|ConvertTo-Json -Depth 10
