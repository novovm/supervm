# Generate pinned copies of the original existing updater, never start a node.
$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$source='e7b0cca7fb823a7b15e8788090052b17ddfd2454'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-e7b0cca7-20261110'
$out=Join-Path $delivery 'update-tools'
if(Test-Path -LiteralPath $out){throw 'Preserve existing prepared tools'}
$old=Get-Content "$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/candidate-manifest.json" -Raw|ConvertFrom-Json
$current=@{}
foreach($platform in @('windows','linux')){
    $verified=Get-Content "$delivery/verified-$platform.json" -Raw|ConvertFrom-Json
    $qualified=Get-Content "$delivery/owner-qualification-$platform.json" -Raw|ConvertFrom-Json
    if($verified.source_commit -cne $source -or $qualified.source_commit -cne $source -or $qualified.node_sha256 -cne $verified.node_sha256){throw 'Fixed package qualification required'}
    $current[$platform]=$verified
}
New-Item -ItemType Directory -Path $out|Out-Null
function Save-New([string]$Name,[string]$Text){
    $stream=[IO.File]::Open((Join-Path $out $Name),[IO.FileMode]::CreateNew)
    try{$stream.Write([Text.UTF8Encoding]::new($false).GetBytes($Text))}finally{$stream.Dispose()}
}
function Replace-Line([string]$Text,[string]$Prefix,[string]$Replacement){
    $pattern='(?m)^'+[regex]::Escape($Prefix)+'.*\r?$'
    if([regex]::Matches($Text,$pattern).Count -ne 1){throw "Expected one original assignment: $Prefix"}
    return [regex]::Replace($Text,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($match) $Replacement})
}
function Adapt-Windows([string]$Text){
    return $Text.Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$source).
        Replace('424e70b8b0acf847598f2bd7b5aefb4276bad052ab2afb64f7e8412d60d9e1bb',$current.windows.manifest_sha256).
        Replace('5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27',$current.windows.node_sha256).
        Replace('novonet-sqlite-3fa11f94','novonet-observation-e7b0cca7').Replace('3fa11f94','e7b0cca7')
}
$windows=Adapt-Windows (Get-Content "$repo/scripts/windows/Update-NovonetExisting.ps1" -Raw)
$oldWin=$old.packages|Where-Object platform -CEQ windows
foreach($pair in @(
    @('$oldNodePin=',('$oldNodePin='''+$oldWin.node_sha256+'''')),
    @('$oldWork=','$oldWork=Join-Path $state ''novonet-observation-1ef31893-20261110'''),
    @('$oldRelease=','$oldRelease=''C:\ProgramData\NOVOVM\releases\novonet-observation-1ef31893-windows-x86_64'''),
    @('$oldTask=','$oldTask="NOVOVM-$HostId-1ef31893-Existing-20261110"'),
    @('$oldProgressPath=','$oldProgressPath=Join-Path $oldWork ''logs\progress.json'''),
    @('$oldRuleName=','$oldRuleName="NOVOVM-1ef31893-$HostId-20261110"')
)){$windows=Replace-Line $windows $pair[0] $pair[1]}
Save-New 'Update-Windows.ps1' $windows
$test=Adapt-Windows (Get-Content "$repo/scripts/tests/novonet-existing-update.tests.ps1" -Raw)
$test=$test.Replace("'../windows/Update-NovonetExisting.ps1'","'Update-Windows.ps1'").Replace("'../../target/relay-evidence-20261109/gate-tests-'","'gate-tests-'")
Save-New 'Test-Update-Windows.ps1' $test
Save-New 'NovonetExistingProcess.ps1' (Get-Content "$repo/scripts/windows/NovonetExistingProcess.ps1" -Raw)
$linux=Get-Content "$repo/scripts/linux/update-novonet-existing.py" -Raw
$linux=$linux.Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$source).
    Replace('3a837ed6095a826e96df42610972980287f677c59d8ba02d426961a99dae2247',$current.linux.manifest_sha256).
    Replace('8ae62f05146112f792b7868e170a1ae03445c783bf7964f2416bfb7ebff2184c',$current.linux.node_sha256).
    Replace('novonet-sqlite-3fa11f94','novonet-observation-e7b0cca7').Replace('3fa11f94','e7b0cca7').
    Replace('novovm-sqlite-update-e7b0cca7','novovm-session-clock-update-e7b0cca7')
$oldLinux=$old.packages|Where-Object platform -CEQ linux
$archive=Join-Path $delivery 'novonet-observation-e7b0cca7-linux-x86_64.tar.gz'
foreach($pair in @(
    @('ARCHIVE_PIN = ',("ARCHIVE_PIN = '"+(Get-FileHash $archive).Hash.ToLowerInvariant()+"'")),
    @('OLD_NODE_PIN = ',("OLD_NODE_PIN = '"+$oldLinux.node_sha256+"'")),
    @('old_release = ',"old_release = Path('/opt/novovm/releases/novonet-observation-1ef31893-linux-x86_64')"),
    @('old_work = ',"old_work = state / 'novonet-observation-1ef31893-20261110'"),
    @('old_progress = ',"old_progress = old_work / 'logs/progress.json'"),
    @('old_unit = ',"old_unit = 'novovm-B-1ef31893-network-20261110.service'")
)){$linux=Replace-Line $linux $pair[0] $pair[1]}
Save-New 'Update-B.py' $linux
$test=Get-Content "$repo/scripts/tests/test_novonet_linux_existing.py" -Raw
$test=$test.Replace("Path(__file__).resolve().parents[1] / 'linux/update-novonet-existing.py'","Path(__file__).resolve().parent / 'Update-B.py'").
    Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$source).
    Replace('novovm-B-2b97fc8e-network-20261109.service','novovm-B-1ef31893-network-20261110.service').
    Replace('logs-retry-start-1/progress.json','logs/progress.json')
Save-New 'test_update_b.py' $test
foreach($name in @('Read-Status.ps1','Prepare-OperatorRule.ps1','Check-Full.ps1')){
    Save-New $name (Get-Content (Join-Path $PSScriptRoot $name) -Raw)
}
Write-Output 'Pinned original updaters prepared for 1ef -> e7; no installed node changed'
