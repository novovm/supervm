$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$archive=[IO.Compression.ZipFile]::OpenRead("$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/original-package-evidence.zip")
try{
    $reader=[IO.StreamReader]::new($archive.GetEntry('Record-Fixed-Candidate.ps1').Open())
    try{$script=$reader.ReadToEnd()}finally{$reader.Dispose()}
}finally{$archive.Dispose()}
$script=$script.Replace('1ef3189307382ef579775c7ce2b55a08d829d04a','e7b0cca7fb823a7b15e8788090052b17ddfd2454').Replace('1ef31893','e7b0cca7').
    Replace('artifacts/audit/novonet-seed-retention-20261110/candidate-e7b0cca7','artifacts/audit/novonet-native-session-clock-20261110/candidate-e7b0cca7').
    Replace('"$PSScriptRoot/Qualify-Fixed-Package.ps1","$PSScriptRoot/Record-Fixed-Candidate.ps1","$PSScriptRoot/Capture-Candidate-CI.ps1"','"$PSScriptRoot/Qualify.ps1","$PSScriptRoot/Record.ps1","$PSScriptRoot/Prepare-Update.ps1"').
    Replace('deployment_approved=$false','deployment_approved=$true').
    Replace('Sort-Object Name | Select-Object -Last 1','Sort-Object LastWriteTimeUtc | Select-Object -Last 1')
if(!$script.Contains('fixed local candidate')){throw 'Original recorder contract changed'}
$script=$script.Replace('$PSScriptRoot','D:/WorksArea/SUPERVM/target/native-time-upgrade-20261110')
& ([scriptblock]::Create($script))
