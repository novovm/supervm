param([switch]$Linux)
$ErrorActionPreference='Stop'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$source='e7b0cca7fb823a7b15e8788090052b17ddfd2454'
$archive=[IO.Compression.ZipFile]::OpenRead("$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/original-package-evidence.zip")
try {
    $reader=[IO.StreamReader]::new($archive.GetEntry('Qualify-Fixed-Package.ps1').Open())
    try {$script=$reader.ReadToEnd()} finally {$reader.Dispose()}
} finally {$archive.Dispose()}
if(!$script.Contains('1ef3189307382ef579775c7ce2b55a08d829d04a')){throw 'Original qualifier source guard changed'}
$script=$script.Replace('1ef3189307382ef579775c7ce2b55a08d829d04a',$source).Replace('1ef31893',$source.Substring(0,8))
& ([scriptblock]::Create($script)) -Linux:$Linux
