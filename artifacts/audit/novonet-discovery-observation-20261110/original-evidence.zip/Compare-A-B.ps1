$ErrorActionPreference='Stop'
$dir=Join-Path $PSScriptRoot 'actual-A-B-3fa'
$a=Get-Content "$dir/A-after.json" -Raw|ConvertFrom-Json
$b=Get-Content "$dir/B-after.json" -Raw|ConvertFrom-Json
$done=@($a.native_network_probe.events|Where-Object event -eq 'probe_object_done')
$received=@($b.native_network_probe.events|Where-Object event -eq 'probe_received_integrity_verified')
if($done.Count -ne 1 -or $received.Count -ne 1){throw 'Single dual-ended result not established'}
function Hex($v){[Convert]::ToHexString([byte[]]$v).ToLowerInvariant()}
foreach($field in @('object_id','session_id','nonce','sender','recipient')){
    if((Hex $done[0].$field) -cne (Hex $received[0].$field)){throw "Mismatch: $field"}
}
if($done[0].path -ne 'native_udp' -or $received[0].path -ne 'native_udp'){throw 'Not native UDP'}
# Same public correlation definition as transfer_tag_v1; not a protocol or receipt.
$tag=Hex ([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::ASCII.GetBytes('novonet-local-transfer-evidence-v1') + [byte[]]$done[0].session_id + [Text.Encoding]::ASCII.GetBytes('NVBFT001') + [byte[]]$done[0].object_id)))
$at=@($a.native_network_probe.transport.objects|Where-Object {(Hex $_.tag) -ceq $tag})
$bt=@($b.native_network_probe.transport.objects|Where-Object {(Hex $_.tag) -ceq $tag})
if($at.Count -ne 1 -or $bt.Count -ne 1 -or $at[0].send_terminal_state -ne 'delivered' -or $at[0].acknowledged_best -ne 1 -or $null -eq $bt[0].verified_us){throw 'Transport correlation incomplete'}
$admitted=@($a.native_network_probe.events|Where-Object event -eq 'probe_admitted')[0]
[ordered]@{
    program_source='3fa11f940b18e54b46e6b927d3d66294bea37088';direction='A_to_B';single_command=$true
    object_id=Hex $done[0].object_id;session_id=Hex $done[0].session_id;transfer_tag=$tag
    nonce=Hex $done[0].nonce;sender=Hex $done[0].sender;recipient=Hex $done[0].recipient
    sender_route=$done[0].route;receiver_route=$received[0].route;path='native_udp'
    command_issued_ms=$done[0].issued_at_ms;sender_admitted_ms=$admitted.wall_ms;sender_done_ms=$done[0].wall_ms
    receiver_verified_ms=$received[0].wall_ms;sender_admitted_to_done_ms=($done[0].wall_ms-$admitted.wall_ms)
    cross_host_latency_claimed=$false;transport_acknowledged_fragments=$at[0].acknowledged_best
    sender_transport=$at[0];receiver_transport=$bt[0]
    sender_execution_failures=$a.execution_failures;receiver_execution_failures=$b.execution_failures
    sender_connection_failures=$a.novonet.connection_failures;receiver_connection_failures=$b.novonet.connection_failures
    dual_ended_fixed_probe_passed=$true;business_receipt=$false;four_host_multihop_accepted=$false
} | ConvertTo-Json -Depth 30
