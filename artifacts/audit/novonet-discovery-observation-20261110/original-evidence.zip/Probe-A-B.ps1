#Requires -Version 7.0
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$work='C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-sqlite-3fa11f94-20261110'
$root='C:/ProgramData/NOVOVM/releases/novonet-sqlite-3fa11f94-windows-x86_64'
$out=Join-Path $PSScriptRoot 'actual-A-B-3fa'
if(Test-Path -LiteralPath $out){throw 'Existing evidence; do not resend'}
if(Test-Path -LiteralPath "$work/commands/control.nvprobe"){throw 'Command already present; do not replay'}
$node=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'" | Where-Object { $_.ExecutablePath -ieq "$root/bin/novovm-node.exe".Replace('/','\') })
if($node.Count -ne 1 -or (Invoke-CimMethod $node[0] -MethodName GetOwnerSid).Sid -ne 'S-1-5-19'){throw 'Original A owner not confirmed'}
if((Get-FileHash -LiteralPath "$root/bin/novovm-node.exe").Hash.ToLowerInvariant() -ne '5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27'){throw 'Node differs'}
if((Get-FileHash -LiteralPath "$root/bin/novovmctl.exe").Hash.ToLowerInvariant() -ne '6c9f53dfad098291d7e42f8464bb1c244463b368b5712ccf14ed8badc0aafd2e'){throw 'Ctl differs'}
$config=Get-Content -LiteralPath "$work/run.json" -Raw|ConvertFrom-Json
$network=Get-Content -LiteralPath $config.novonet_config_file -Raw|ConvertFrom-Json
if($network.probe_control_file.Replace('\','/') -ne "$work/commands/control.nvprobe"){throw 'Command owner differs'}
$before=Get-Content -LiteralPath "$work/logs/progress.json" -Raw|ConvertFrom-Json
if($before.chain_id -ne 91129655606029 -or $before.execution_failures -ne 0 -or ((Get-Date)-(Get-Item "$work/logs/progress.json").LastWriteTime).TotalSeconds -gt 30){throw 'Progress not live/healthy'}
$ids=@(0,1 | ForEach-Object { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([byte[]]([Text.Encoding]::UTF8.GetBytes("novovm-round-bft/v2/mldsa65/validator-id`0") + [byte[]]$config.genesis.validators[$_].public_key))).ToLowerInvariant() })
if($ids[0] -ne 'b5d25773baaf82e8c109d41782a15ac3e45b57562f9bb023c8c1cab63d6acc43' -or $ids[1] -ne '4cecd4ba4092c821333501687e7a363d829d544c1a203ea2390d76e8b2a5627f'){throw 'Original identities differ'}
New-Item -ItemType Directory -Path $out | Out-Null
Copy-Item -LiteralPath "$work/logs/progress.json" -Destination "$out/A-before.json"
& "$root/bin/novovmctl.exe" native-network-probe prepare --sender $ids[0] --recipient $ids[1] --output "$work/commands/control.nvprobe" 1> "$out/command.json" 2> "$out/command.stderr"
if($LASTEXITCODE -ne 0){throw 'Original ctl rejected; do not retry'}
Copy-Item -LiteralPath "$work/commands/control.nvprobe" -Destination "$out/command-raw.nvprobe"
Start-Sleep -Seconds 13
Copy-Item -LiteralPath "$work/logs/progress.json" -Destination "$out/A-after.json"
$after=Get-Content -LiteralPath "$out/A-after.json" -Raw|ConvertFrom-Json
[ordered]@{utc=[DateTime]::UtcNow.ToString('o');pid=$node[0].ProcessId;command_issued_once=$true;probe=$after.native_network_probe.events;novonet=$after.novonet;execution_failures=$after.execution_failures}|ConvertTo-Json -Depth 30
