param([switch]$Linux, [ValidatePattern('^[a-z0-9-]+$')][string]$Run='final-1')
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
Set-Location $repo
$platform=if($Linux){'linux'}else{'windows'}
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_BUILD_JOBS='2'
if($Linux){
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
}else{
    $env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'
}
$runtime="$repo/artifacts/product-overlay/novonet-sqlite-3fa11f94-$platform-x86_64/aoem"
$env:AOEM_DLL_MANIFEST="$runtime/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_DLL=if($Linux){"$runtime/linux/core/bin/libaoem_ffi.so"}else{"$runtime/windows/core/bin/aoem_ffi.dll"}
$env:NOVOVM_AOEM_DLL=$env:AOEM_DLL
$env:NOVOVM_AOEM_TEST_LIBRARY=$env:AOEM_DLL
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$expected=if($Linux){'d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33'}else{'1b764a36c1f782425237d40446d4ea827f56a66fb341b870855d84c15acdce50'}
if((Get-FileHash -LiteralPath $env:AOEM_DLL).Hash.ToLowerInvariant() -cne $expected){throw 'Actual runtime differs'}
function Check([string]$Label,[string[]]$Arguments,[switch]$Test){
    $log="$PSScriptRoot/$platform-$Run-$Label.log"
    if(Test-Path -LiteralPath $log){throw "Refusing overwrite $log"}
    & cargo @Arguments 2>&1 | Tee-Object -FilePath $log
    if($LASTEXITCODE -ne 0){throw "Failed $Label; original log retained $log"}
    if($Test -and (Get-Content -LiteralPath $log -Raw) -notmatch 'test result: ok\. [1-9][0-9]* passed'){throw "Zero executed tests $Label"}
}
Check 'owner' @('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','native_pipeline::service::network::tests','--','--test-threads=1','--nocapture') -Test
Check 'discovery' @('test','--release','--locked','-p','novovm-node','--lib','--features','iroh-transport','native_pipeline::service::network::discovery::tests','--','--test-threads=1','--nocapture') -Test
Check 'clippy' @('clippy','--release','--locked','-p','novovm-node','--lib','--tests','--features','iroh-transport','--','-D','warnings')
Write-Output 'PASS affected local checks only; no deployment or cloud dispatch'
