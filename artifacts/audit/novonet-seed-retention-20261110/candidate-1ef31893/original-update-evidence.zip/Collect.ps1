param([Parameter(Mandatory=$true)][string]$Label,[switch]$BOnly)
$ErrorActionPreference='Stop'
$root='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'
$out="$root/live-evidence/$Label"
if(Test-Path $out){throw 'Preserve existing snapshot'}
New-Item -ItemType Directory $out -Force|Out-Null
$remote='/var/lib/novovm/selfrun/91129655606029/B/novonet-observation-1ef31893-20261110/logs/progress.json'
$raw=ssh -F C:/Users/leadb/.ssh/validator-B.conf -o BatchMode=yes -o ConnectTimeout=10 validator-B "sudo -n cat $remote"
if($LASTEXITCODE -ne 0){throw 'Remote snapshot failed'}
$b=$raw|ConvertFrom-Json
[IO.File]::WriteAllText("$out/B-progress.json",($raw -join "`n"),[Text.UTF8Encoding]::new($false))
$b.novonet|ConvertTo-Json -Depth 18
if(!$BOnly){
    Copy-Item 'C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-observation-1ef31893-20261110/logs/progress.json' "$out/A-progress.json"
    $a=Get-Content "$out/A-progress.json" -Raw|ConvertFrom-Json
    $a.novonet|ConvertTo-Json -Depth 18
}
