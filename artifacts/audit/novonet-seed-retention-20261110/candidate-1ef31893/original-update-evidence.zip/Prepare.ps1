$ErrorActionPreference='Stop'
$old='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-68fa7588-20261110'
$new='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'
$out="$new/update-tools"
if(Test-Path $out){throw 'Preserve existing prepared tools'}
$pins=Get-Content 'D:/WorksArea/SUPERVM/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893/candidate-manifest.json' -Raw|ConvertFrom-Json
foreach($p in $pins.packages){
    $file=Get-Item "$new/$($p.archive)"
    if($file.Length -ne $p.archive_bytes -or (Get-FileHash $file.FullName).Hash.ToLowerInvariant() -cne $p.archive_sha256){throw 'Fixed archive mismatch'}
}
New-Item -ItemType Directory $out|Out-Null
function Save-New($name,$text){
    $f=[IO.File]::Open("$out/$name",[IO.FileMode]::CreateNew)
    try{$f.Write([Text.UTF8Encoding]::new($false).GetBytes($text))}finally{$f.Dispose()}
}
function Adapt($text,$platform){
    $previous=Get-Content "$old/verified-$platform.json" -Raw|ConvertFrom-Json
    $current=$pins.packages|Where-Object platform -CEQ $platform
    foreach($field in @('source_commit','manifest_sha256','node_sha256')){
        $text=$text.Replace([string]$previous.$field,[string]$current.$field)
    }
    if($platform -eq 'linux'){
        $archiveHash=(Get-FileHash "$old/novonet-observation-68fa7588-linux-x86_64.tar.gz").Hash.ToLowerInvariant()
        $text=$text.Replace($archiveHash,$current.archive_sha256)
        $text=$text.Replace('8ae62f05146112f792b7868e170a1ae03445c783bf7964f2416bfb7ebff2184c',$previous.node_sha256)
    }else{
        $text=$text.Replace('5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27',$previous.node_sha256)
    }
    $text=$text.Replace('68fa7588','1ef31893')
    # These remaining 3fa references are exclusively the previous owner/rollback.
    $text=$text.Replace('novonet-sqlite-3fa11f94','novonet-observation-68fa7588').Replace('3fa11f94','68fa7588')
    return $text
}
Save-New 'Update-B.py' (Adapt (Get-Content "$old/update-tools/Update-B.py" -Raw) 'linux')
Save-New 'test_update_b.py' (Adapt (Get-Content "$old/update-tools/test_update_b.py" -Raw) 'linux')
Save-New 'Update-A.ps1' (Adapt (Get-Content "$old/update-tools/Update-A.ps1" -Raw) 'windows')
Save-New 'Test-Update-A.ps1' (Adapt (Get-Content "$old/update-tools/Test-Update-A.ps1" -Raw) 'windows')
Copy-Item "$old/update-tools/NovonetExistingProcess.ps1" "$out/NovonetExistingProcess.ps1"
$status=Get-Content 'D:/WorksArea/SUPERVM/target/openssl-security-20261110/Read-Update-Status.ps1' -Raw
Save-New 'Read-Status.ps1' ($status.Replace('candidate-observation-68fa7588','candidate-observation-1ef31893'))
Write-Output 'Fixed archives verified; original pinned updater copies generated; no node changed'
