$ErrorActionPreference='Stop'
$out='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110/update-tools'
$probe=Get-Content 'D:/WorksArea/SUPERVM/target/novonet-failure-observation-20261110/Probe-A-B.ps1' -Raw
$probe=$probe.Replace('novonet-sqlite-3fa11f94','novonet-observation-1ef31893').Replace('actual-A-B-3fa','actual-A-B-1ef')
$probe=$probe.Replace('5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27','d419df614d6b804136eca82fd7427d84155241c82b7f74c3c00bf2fdb3ea6087')
$probe=$probe.Replace('6c9f53dfad098291d7e42f8464bb1c244463b368b5712ccf14ed8badc0aafd2e','00955e09f3f610df00745ade00f8438d2cb650ab721ed88854efefafe3e1a730')
$compare=Get-Content 'D:/WorksArea/SUPERVM/target/novonet-failure-observation-20261110/Compare-A-B.ps1' -Raw
$compare=$compare.Replace('actual-A-B-3fa','actual-A-B-1ef').Replace('3fa11f940b18e54b46e6b927d3d66294bea37088','1ef3189307382ef579775c7ce2b55a08d829d04a')
foreach($pair in @(@('Probe-A-B.ps1',$probe),@('Compare-A-B.ps1',$compare))){
    $f=[IO.File]::Open("$out/$($pair[0])",[IO.FileMode]::CreateNew)
    try{$f.Write([Text.UTF8Encoding]::new($false).GetBytes($pair[1]))}finally{$f.Dispose()}
}
Write-Output 'Original probe and correlation scripts pinned; no command sent'
