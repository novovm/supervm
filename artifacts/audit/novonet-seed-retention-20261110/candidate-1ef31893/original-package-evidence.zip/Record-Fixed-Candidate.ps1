$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$source='1ef3189307382ef579775c7ce2b55a08d829d04a'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'
$output="$repo/artifacts/audit/novonet-seed-retention-20261110/candidate-1ef31893"
if(Test-Path -LiteralPath $output){throw 'Preserve existing candidate record'}
$ciFile=Get-ChildItem -LiteralPath $delivery -Filter 'ci-run-*.json' | Sort-Object Name | Select-Object -Last 1
if(!$ciFile){throw 'Original CI status must be read'}
$ci=Get-Content -LiteralPath $ciFile.FullName -Raw | ConvertFrom-Json
if($ci.head_sha -cne $source -or $ci.run_attempt -ne 1){throw 'Wrong CI identity'}
$records=@()
foreach($platform in @('windows','linux')) {
    $root="$repo/artifacts/product-overlay/novonet-observation-1ef31893-$platform-x86_64"
    $manifest=Get-Content "$root/release-manifest.json" -Raw | ConvertFrom-Json
    $verified=Get-Content "$delivery/verified-$platform.json" -Raw | ConvertFrom-Json
    $owner=Get-Content "$delivery/owner-qualification-$platform.json" -Raw | ConvertFrom-Json
    if($manifest.git_commit -cne $source -or $verified.source_commit -cne $source -or $owner.source_commit -cne $source){throw 'Source differs'}
    # The original packager excludes CHECKSUMS.sha256 by basename at every depth.
    # Pin and verify the one inherited AOEM checksum table explicitly, never allow
    # arbitrary extra archive files or modify the frozen release manifest.
    $nestedRelative="aoem/$platform/CHECKSUMS.sha256"
    $nested=Join-Path $root $nestedRelative
    $nestedPin=if($platform -eq 'windows'){'cac4db2bdced355ed2e2473fbc092095c0bef1f791fa6654dd00691310d39d30'}else{'94ae7322b1eeedcd9c358d97bbafab389b722378e53a796a393782f14fb71734'}
    if((Get-FileHash $nested).Hash.ToLowerInvariant() -cne $nestedPin){throw 'Inherited AOEM checksum table changed'}
    $nestedCount=0
    foreach($line in Get-Content $nested){
        if($line -notmatch '^([a-f0-9]{64})  (.+)$'){throw 'Invalid AOEM checksum row'}
        $hash=$Matches[1]; $relative=$Matches[2]
        if([IO.Path]::IsPathRooted($relative) -or $relative.Split('/') -contains '..'){throw 'Invalid checksum path'}
        $member=Join-Path (Split-Path $nested -Parent) $relative
        if((Get-FileHash $member).Hash.ToLowerInvariant() -cne $hash){throw "Nested AOEM checksum differs: $relative"}
        $nestedCount++
    }
    $expected=@($manifest.artifacts.path)+@('CHECKSUMS.sha256','release-manifest.json',$nestedRelative)
    $files=@(Get-ChildItem -LiteralPath $root -Recurse -File)
    $names=@($files | ForEach-Object {[IO.Path]::GetRelativePath($root,$_.FullName).Replace('\','/')})
    if(@(Compare-Object ($expected|Sort-Object) ($names|Sort-Object)).Count){throw "Unexpected package members $platform"}
    foreach($entry in $manifest.artifacts){
        $path=Join-Path $root $entry.path
        if((Get-Item $path).Length -ne $entry.bytes -or (Get-FileHash $path).Hash.ToLowerInvariant() -cne $entry.sha256){throw "Changed package member $path"}
    }
    if((Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant() -cne $verified.manifest_sha256){throw 'Manifest changed'}
    if($owner.node_sha256 -cne $verified.node_sha256 -or $owner.aoem_sha256 -cne $manifest.aoem_runtime.sha256){throw 'Different qualified node/runtime'}
    if((Get-Content "$delivery/packaged-native-identity-$platform.log" -Raw) -notmatch 'test result: ok\. 7 passed; 0 failed'){throw 'Package identity tests incomplete'}
    $extension=if($platform -eq 'windows'){'.zip'}else{'.tar.gz'}
    $archive="$delivery/novonet-observation-1ef31893-$platform-x86_64$extension"
    if($platform -eq 'windows'){
        $zip=[IO.Compression.ZipFile]::OpenRead($archive)
        try {
            $members=@($zip.Entries | Where-Object {!$_.FullName.EndsWith('/')})
            if($members.Count -ne $files.Count -or @($members.FullName|Select-Object -Unique).Count -ne $files.Count){throw 'ZIP duplicates/count mismatch'}
            foreach($file in $files){
                $relative=[IO.Path]::GetRelativePath($root,$file.FullName).Replace('\','/')
                $entry=$zip.GetEntry("novonet-observation-1ef31893-$platform-x86_64/$relative")
                if(!$entry -or $entry.Length -ne $file.Length){throw "ZIP member differs $relative"}
                $stream=$entry.Open()
                try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
                if($hash -cne (Get-FileHash $file.FullName).Hash.ToLowerInvariant()){throw "ZIP data differs $relative"}
            }
        }finally{$zip.Dispose()}
    }else{
        & wsl.exe -d Ubuntu-24.04 -- tar -df /mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110/novonet-observation-1ef31893-linux-x86_64.tar.gz -C /mnt/d/WorksArea/SUPERVM/artifacts/product-overlay
        if($LASTEXITCODE -ne 0){throw 'Linux archived bytes differ'}
    }
    $records+=@{platform=$platform;source_commit=$source;archive=[IO.Path]::GetFileName($archive);archive_bytes=(Get-Item $archive).Length;archive_sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();manifest_sha256=$verified.manifest_sha256;manifest_members=$manifest.artifacts.Count;total_files=$files.Count;inherited_aoem_checksum=@{path=$nestedRelative;sha256=$nestedPin;entries_verified=$nestedCount};node_sha256=$verified.node_sha256;client_sha256=$verified.client_sha256;ctl_sha256=$verified.ctl_sha256;aoem_sha256=$manifest.aoem_runtime.sha256;aoem_manifest_sha256=(Get-FileHash "$root/aoem/manifest/aoem-manifest.json").Hash.ToLowerInvariant();package_identity_tests=7;qualification=$owner.results;deployed=$false}
}
New-Item -ItemType Directory -Path $output | Out-Null
$logs=@(Get-ChildItem -LiteralPath $delivery -File | Where-Object {$_.Extension -in '.json','.log'})
$logs+=Get-Item "$PSScriptRoot/Qualify-Fixed-Package.ps1","$PSScriptRoot/Record-Fixed-Candidate.ps1","$PSScriptRoot/Capture-Candidate-CI.ps1","$repo/target/openssl-security-20261110/Candidate.ps1","$repo/target/relay-evidence-20261109/Build-Sqlite-Candidate.ps1","$repo/target/novonet-probe-candidate-20261108/Verify.ps1","$repo/target/relay-evidence-20261109/Qualify-Coordinated-Package.ps1","$repo/target/relay-evidence-20261109/Archive-Coordinated-Windows.ps1","$repo/target/relay-evidence-20261109/Archive-Coordinated-Linux.ps1"
if(@($logs.Name | Select-Object -Unique).Count -ne $logs.Count){throw 'Evidence archive names must be unique'}
Compress-Archive -LiteralPath $logs.FullName -DestinationPath "$output/original-package-evidence.zip" -CompressionLevel Optimal
$evidence=[IO.Compression.ZipFile]::OpenRead("$output/original-package-evidence.zip")
try {
    if($evidence.Entries.Count -ne $logs.Count){throw 'Evidence member count differs'}
    foreach($file in $logs){
        $entry=$evidence.GetEntry($file.Name)
        if(!$entry -or $entry.Length -ne $file.Length){throw "Evidence member differs $($file.Name)"}
        $stream=$entry.Open()
        try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($hash -cne (Get-FileHash $file.FullName).Hash.ToLowerInvariant()){throw "Evidence bytes differ $($file.Name)"}
    }
}finally{$evidence.Dispose()}
@{source_commit=$source;local_delivery_directory=$delivery;packages=$records;evidence_archive_sha256=(Get-FileHash "$output/original-package-evidence.zip").Hash.ToLowerInvariant();CI=@{run=$ci.id;head_sha=$ci.head_sha;event=$ci.event;attempt=$ci.run_attempt;status=$ci.status;conclusion=$ci.conclusion;snapshot=$ciFile.Name;url=$ci.html_url};scope='fixed local candidate; actual package process recovery and same-source owner IO are separate; no public network acceptance';deployment_approved=$false;A_B_C_D_changed=$false} | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$output/candidate-manifest.json" -Encoding utf8
Write-Output 'PASS independent full package and archive verification; no deployment'
