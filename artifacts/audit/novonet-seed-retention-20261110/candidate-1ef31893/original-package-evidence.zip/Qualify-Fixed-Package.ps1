param([switch]$Linux)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$source='1ef3189307382ef579775c7ce2b55a08d829d04a'
$repo=if($Linux){'/mnt/d/WorksArea/SUPERVM'}else{'D:/WorksArea/SUPERVM'}
$delivery=if($Linux){'/mnt/c/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'}else{'C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'}
$platform=if($Linux){'linux'}else{'windows'}
$root="$repo/artifacts/product-overlay/novonet-observation-1ef31893-$platform-x86_64"
Set-Location $repo
if($Linux){
    function global:git { & '/mnt/c/Program Files/Git/cmd/git.exe' -C 'D:/WorksArea/SUPERVM' @args }
    $env:PATH='/home/aoem-a1/.cargo/bin:'+$env:PATH
    $env:CARGO_TARGET_DIR='/home/aoem-a1/novovm-build-b-20261102'
    $env:CARGO_BUILD_TARGET='x86_64-unknown-linux-gnu'
}else{
    $env:CARGO_TARGET_DIR='C:/Users/leadb/AppData/Local/NOVOVM/build-2b97fc8e-windows'
}
if((git rev-parse HEAD).Trim() -cne $source -or @(git status --porcelain).Count){throw 'Frozen clean source required'}
foreach($phase in @('Verify','Qualify')) {
    & "$repo/target/openssl-security-20261110/Candidate.ps1" -Source $source -Phase $phase -Linux:$Linux
}
$manifest=Get-Content "$root/release-manifest.json" -Raw | ConvertFrom-Json
$env:AOEM_DLL=Join-Path $root $manifest.aoem_runtime.path
$env:NOVOVM_AOEM_DLL=$env:AOEM_DLL
$env:NOVOVM_AOEM_TEST_LIBRARY=$env:AOEM_DLL
$env:AOEM_DLL_MANIFEST="$root/aoem/manifest/aoem-manifest.json"
$env:NOVOVM_AOEM_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:NOVOVM_AOEM_TEST_MANIFEST=$env:AOEM_DLL_MANIFEST
$env:AOEM_DLL_MANIFEST_REQUIRED='1'
$env:AOEM_SEMANTIC_GRAPH_V2_WORKERS='2'
$env:NOVOVM_ALLOW_LEGACY_HOST_EXECUTION='0'
$extension=if($Linux){''}else{'.exe'}
$env:NOVOVM_RESIDENT_NODE_BINARY="$root/bin/novovm-node$extension"
$env:NOVOVM_NATIVE_LOAD_DIAGNOSTICS='1'
$env:RUSTUP_TOOLCHAIN='1.94.0'
$env:CARGO_BUILD_JOBS='2'
$buildLog="$delivery/owner-test-build-$platform.log"
if(Test-Path $buildLog){throw 'Preserve existing qualification evidence'}
$messages=@(& cargo test --release --locked -p novovm-node --lib --features iroh-transport --no-run --message-format=json 2> $buildLog)
if($LASTEXITCODE -ne 0){throw 'Original test harness build failed'}
$bins=@($messages | ForEach-Object {$_|ConvertFrom-Json} | Where-Object {$_.reason -eq 'compiler-artifact' -and $_.target.name -eq 'novovm_node' -and $_.profile.test -and $_.executable} | ForEach-Object executable | Select-Object -Unique)
if($bins.Count -ne 1){throw 'One actual original owner harness required'}
$binary=$bins[0]
$results=@()
foreach($item in @(
    @{name='owner-with-packaged-aoem';filter='native_pipeline::service::network::';count=15;ignored=$false;scope='source-matched owner component IO with packaged AOEM, not packaged node process'},
    @{name='packaged-node-recovery';filter='native_only_';count=6;ignored=$true;scope='actual packaged node process, native protocol and original isolated database recovery'},
    @{name='packaged-uca-recovery';filter='native_uca_process_';count=1;ignored=$true;scope='actual packaged node and adjacent client, isolated UCA recovery'},
    @{name='packaged-runtime-startup';filter='actual_uca_startup_three_pins_reopen_and_legacy_asset_rejection';count=1;ignored=$true;scope='original startup owner with packaged AOEM, isolated state'}
)){
    $log="$delivery/$($item.name)-$platform.log"
    if(Test-Path $log){throw 'Preserve original test output'}
    $argsList=@($item.filter,'--test-threads=1','--nocapture')
    if($item.ignored){$argsList+='--ignored'}
    & $binary @argsList *>&1 | Tee-Object -FilePath $log
    $exit=$LASTEXITCODE
    if($exit -ne 0 -or (Get-Content $log -Raw) -notmatch "test result: ok\. $($item.count) passed; 0 failed"){throw "Qualification failed: $($item.name); original evidence retained"}
    $results+=@{name=$item.name;passed=$item.count;scope=$item.scope;log=[IO.Path]::GetFileName($log);exit=$exit}
}
if((git rev-parse HEAD).Trim() -cne $source -or @(git status --porcelain).Count){throw 'Source changed during qualification'}
$output="$delivery/owner-qualification-$platform.json"
if(Test-Path $output){throw 'Preserve qualification result'}
@{source_commit=$source;harness=$binary;harness_sha256=(Get-FileHash $binary).Hash.ToLowerInvariant();node=$env:NOVOVM_RESIDENT_NODE_BINARY;node_sha256=(Get-FileHash $env:NOVOVM_RESIDENT_NODE_BINARY).Hash.ToLowerInvariant();aoem_sha256=(Get-FileHash $env:AOEM_DLL).Hash.ToLowerInvariant();results=$results;public_network_accepted=$false;A_B_C_D_changed=$false} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $output -Encoding utf8
& "$repo/target/openssl-security-20261110/Candidate.ps1" -Source $source -Phase Archive -Linux:$Linux
Write-Output 'PASS package qualification; not deployed; actual Carrier/seed/DONE owner tests remain local component scope'
