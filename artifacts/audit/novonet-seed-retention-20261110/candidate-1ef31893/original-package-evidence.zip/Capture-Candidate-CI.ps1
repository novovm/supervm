$ErrorActionPreference='Stop'
$directory='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-1ef31893-20261110'
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
$raw=& gh api repos/novovm/supervm/actions/runs/42717131364
if($LASTEXITCODE -ne 0){throw 'CI read failed'}
$run=$raw | ConvertFrom-Json
if($run.head_sha -cne '1ef3189307382ef579775c7ce2b55a08d829d04a' -or $run.event -ne 'push' -or $run.run_attempt -ne 1){throw 'Unexpected original CI identity'}
$jobs=& gh api 'repos/novovm/supervm/actions/runs/42717131364/jobs?per_page=100'
if($LASTEXITCODE -ne 0){throw 'CI jobs read failed'}
$raw | Set-Content -LiteralPath "$directory/ci-run-$stamp.json" -Encoding utf8
$jobs | Set-Content -LiteralPath "$directory/ci-jobs-$stamp.json" -Encoding utf8
@{run=$run.id;source=$run.head_sha;attempt=$run.run_attempt;status=$run.status;conclusion=$run.conclusion;checked_utc=$stamp} | ConvertTo-Json -Compress
