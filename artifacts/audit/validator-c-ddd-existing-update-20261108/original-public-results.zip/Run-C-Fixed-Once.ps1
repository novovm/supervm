﻿#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
try {
 if(Test-Path (Join-Path $out 'C-before.json')){throw 'Preflight result exists; inspect before retry'}
 & (Join-Path $out 'Inspect-C.ps1')
 $before=Get-Content (Join-Path $out 'C-before.json') -Raw|ConvertFrom-Json
 if($before.exe -cne 'C:\ProgramData\NOVOVM\releases\novonet-08236129-windows-x86_64\bin\novovm-node.exe' -or $before.node_sha256 -cne '9040ac63828c30011e8e7c4801be31183ecb69960854dd4974671df3d5d14d51' -or $before.database -cne 'C:\ProgramData\NOVOVM\selfrun\91129655606029\C\chain-state' -or !$before.database_exists){throw 'Original C process/database differs'}
 if(!(Get-NetIPAddress -IPAddress 192.168.71.125 -AddressFamily IPv4 -ErrorAction SilentlyContinue)){throw 'C LAN differs'}
 $prior=Get-Content 'D:\WEB3_AI\SUPERVM\target\novonet-probe-C-update-20261108\public-evidence\C-before.json' -Raw|ConvertFrom-Json
 if($before.pid -ne 19752 -or $before.uid -cne $prior.uid -or (Get-ScheduledTask -TaskName 'NOVOVM-C-08236129-Existing-Rollback-20261108').State -ne 'Running' -or $before.progress.current_height -ne $prior.progress.current_height -or $before.progress.execution_failures -ne 0){throw 'Original process/task/state changed; stop for review'}
 if(($before.config|ConvertTo-Json -Depth 85 -Compress) -cne ($prior.config|ConvertTo-Json -Depth 85 -Compress) -or ($before.network|ConvertTo-Json -Depth 85 -Compress) -cne ($prior.network|ConvertTo-Json -Depth 85 -Compress)){throw 'Original configuration changed; stop for review'}
 foreach($property in $prior.custody_sha256.PSObject.Properties){if($before.custody_sha256.($property.Name) -cne $property.Value){throw 'Original custody hashes changed; stop for review'}}

 & (Join-Path $out 'Update-C-fixed.ps1') -ResumePrepared
 $work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-ddd89e8e-20261108'
 foreach($name in @('owner.json','progress.json','node.stderr')){Copy-Item -LiteralPath (Join-Path $work ('logs\'+$name)) -Destination (Join-Path $out ('C-'+$name))}
 $after=Get-Content (Join-Path $out 'C-after.json') -Raw|ConvertFrom-Json
 $network=Get-Content (Join-Path $work 'network.json') -Raw|ConvertFrom-Json
 Copy-Item -LiteralPath $network.public_record_file -Destination (Join-Path $out 'C-locator.json')
 $task=Get-ScheduledTask -TaskName 'NOVOVM-C-ddd89e8e-Existing-20261108';$info=Get-ScheduledTaskInfo -TaskName $task.TaskName
 [ordered]@{success=$true;collected_utc=[DateTime]::UtcNow.ToString('o');task_state=$task.State.ToString();last_task_result=$info.LastTaskResult;initialize_executed=$false;source='ddd89e8e05721a2ddb8a7ae9255405d395b39a46'}|ConvertTo-Json|Set-Content (Join-Path $out 'C-observation.json') -Encoding utf8
} catch {
 [ordered]@{success=$false;error=$_.Exception.Message;observed_utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'C-operation-error.json') -Encoding utf8
 throw
}
