﻿#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$out=$PSScriptRoot
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-08236129-20261108'
$config=Get-Content -LiteralPath "$work/run.json" -Raw -Encoding UTF8|ConvertFrom-Json
$network=Get-Content -LiteralPath $config.novonet_config_file -Raw -Encoding UTF8|ConvertFrom-Json
$processes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
if($processes.Count -ne 1){throw 'Unexpected original node process count'}
$process=$processes[0]
$owner=Invoke-CimMethod -InputObject $process -MethodName GetOwnerSid
if($owner.Sid -cne 'S-1-5-19'){throw 'Original C node is not LocalService'}
$task=Get-ScheduledTask -TaskName 'NOVOVM-C-08236129-Network-20261108'
$listeners=@(Get-NetUDPEndpoint|Where-Object OwningProcess -EQ $process.ProcessId|Select-Object LocalAddress,LocalPort,OwningProcess)
$rules=@(Get-NetFirewallRule -Enabled True -Direction Inbound|Where-Object {$_.DisplayName -match 'NOVOVM|novovm-node'}|ForEach-Object {
    $rule=$_;$app=$rule|Get-NetFirewallApplicationFilter;$port=$rule|Get-NetFirewallPortFilter
    [ordered]@{name=$rule.Name;action=$rule.Action.ToString();program=$app.Program;protocol=$port.Protocol;local_port=$port.LocalPort}
})
$keys=@{}
foreach($path in @($config.signing_key_file,$config.transport_key_file,$network.carrier_identity_file)){$keys[$path]=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
$result=[ordered]@{pid=$process.ProcessId;parent_pid=$process.ParentProcessId;exe=$process.ExecutablePath;node_sha256=(Get-FileHash -LiteralPath $process.ExecutablePath).Hash.ToLowerInvariant();uid=$owner.Sid;command_line=$process.CommandLine;database=$config.database;database_exists=(Test-Path -LiteralPath $config.database -PathType Container);library_sha256=(Get-FileHash -LiteralPath $config.library).Hash.ToLowerInvariant();config=$config;network=$network;progress=(Get-Content "$work/progress.json" -Raw|ConvertFrom-Json);locator=(Get-Content "$work/locator.json" -Raw|ConvertFrom-Json);custody_sha256=$keys;listeners=$listeners;task=[ordered]@{name=$task.TaskName;state=$task.State.ToString();user=$task.Principal.UserId;actions=$task.Actions};firewall_rules=$rules}
$result|ConvertTo-Json -Depth 80|Set-Content -LiteralPath "$out/C-before.json" -Encoding UTF8
'PASS C read-only preflight saved; node/task not changed'|Set-Content -LiteralPath "$out/C-inspect-result.txt" -Encoding UTF8
