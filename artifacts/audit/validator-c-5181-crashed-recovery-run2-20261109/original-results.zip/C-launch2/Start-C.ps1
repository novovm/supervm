#Requires -Version 7.0
#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$repo='D:\WEB3_AI\SUPERVM'
$out=Join-Path $repo 'target\novonet-5181-update-20261109\C-run2'
$launcher=$PSScriptRoot
$updater=Join-Path $repo 'scripts\windows\Update-Novonet5181Existing.ps1'
$package='E:\区块链四机通讯\novonet-5181-update-20261109\novonet-probe-5181da73-windows-x86_64'
$work='C:\ProgramData\NOVOVM\selfrun\91129655606029\C\novonet-probe-5181da73-20261109'
$result=[ordered]@{started_utc=[DateTime]::UtcNow.ToString('o');host_id='C';update_success=$false;observation_completed=$false}
try {
 if((Get-FileHash -LiteralPath $updater).Hash -cne '140646774AC236C339E93A8D15BAC8967565186F199332C01A082943D55EE373'){throw 'Reviewed update script changed'}
 & $updater -HostId C -PackageRoot $package -EvidenceRoot $out -RecoverCrashed *> (Join-Path $launcher 'update-output.txt')
 $update=Get-Content -LiteralPath (Join-Path $out 'result.json') -Raw|ConvertFrom-Json
 if(!$update.update_completed){throw 'Fixed updater did not report completion'}
 $result.update_success=$true
 $result['pid']=$update.pid
 $samples=Join-Path $out 'recovery-samples.jsonl'
 $file=[IO.File]::Open($samples,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 $writer=[IO.StreamWriter]::new($file,[Text.UTF8Encoding]::new($false))
 $deadline=[DateTime]::UtcNow.AddSeconds(120)
 $index=0
 try {
  do {
   $row=[ordered]@{index=$index;utc=[DateTime]::UtcNow.ToString('o');read_ok=$false}
   try {
    $path=Join-Path $work 'logs\progress.json'
    $row['file_last_write_utc']=(Get-Item -LiteralPath $path).LastWriteTimeUtc.ToString('o')
    $raw=[IO.File]::ReadAllBytes($path)
    $p=[Text.Encoding]::UTF8.GetString($raw).TrimStart([char]0xfeff)|ConvertFrom-Json
    $t=$p.native_network_probe.transport
    $row['head']=$p.head;$row['height']=$p.current_height;$row['round']=$p.round
    $row['ticks']=$p.ticks;$row['execution_failures']=$p.execution_failures
    $row['novonet']=$p.novonet
    $row['udp_recovery_event_names']=$t.udp_recovery_event_names
    $row['udp_recovery']=$t.udp_recovery
    $row['udp_recovery_omitted']=$t.udp_recovery_omitted
    $row['contended_observations']=$t.contended_observations
    $row.read_ok=$true
   } catch {$row['error']=$_.Exception.Message}
   $writer.WriteLine(($row|ConvertTo-Json -Depth 60 -Compress));$writer.Flush()
   $index++
   if([DateTime]::UtcNow -ge $deadline){break}
   Start-Sleep -Seconds 5
  } while($true)
 } finally {$writer.Dispose()}
 $result['sample_count']=$index
 $result.observation_completed=$true
 $before=Get-Content -LiteralPath (Join-Path $out 'before.json') -Raw|ConvertFrom-Json
 $after=Get-Content -LiteralPath (Join-Path $out 'after.json') -Raw|ConvertFrom-Json
 $publicBefore=$before|Select-Object host_id,time,pid,exe,node_sha256,sid,database,custody_sha256,firewall_profiles
 $publicBefore|ConvertTo-Json -Depth 30|Set-Content (Join-Path $out 'before-public.json') -Encoding utf8
 $publicAfter=$after|Select-Object host_id,time,source,pid,exe,node_sha256,sid,database,start,initialize_executed,keys_generated,custody_unchanged,aoem_module,aoem_sha256,old_task,new_task,listeners,new_command_file_present
 $publicAfter|ConvertTo-Json -Depth 30|Set-Content (Join-Path $out 'after-public.json') -Encoding utf8
 $map=[ordered]@{config_peer_fields=@($before.config.PSObject.Properties.Name|Where-Object {$_ -match 'peer|validator|transport'});configured_peers=$before.config.peers;network_peer_records=$before.network.peer_records;discovery=$before.network.discovery;discovery_seeds=$before.network.discovery_seeds}
 $map|ConvertTo-Json -Depth 45|Set-Content (Join-Path $out 'peer-map-public.json') -Encoding utf8
 Copy-Item -LiteralPath (Join-Path $work 'logs\owner.json') -Destination (Join-Path $out 'owner-public.json')
 Copy-Item -LiteralPath (Join-Path $work 'logs\node.stderr') -Destination (Join-Path $out 'node-stderr.txt')
 $nodes=@(Get-CimInstance Win32_Process -Filter "Name='novovm-node.exe'")
 $result['final_processes']=@($nodes|Select-Object ProcessId,ParentProcessId,ExecutablePath)
} catch {$result['error']=$_.Exception.Message}
finally {
 $result['finished_utc']=[DateTime]::UtcNow.ToString('o')
 $result|ConvertTo-Json -Depth 20|Set-Content (Join-Path $launcher 'operation-result.json') -Encoding utf8
}
if($result.Contains('error')){exit 1}
