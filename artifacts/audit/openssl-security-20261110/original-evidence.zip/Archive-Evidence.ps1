$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$output="$repo/artifacts/audit/openssl-security-20261110"
$files=@(Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object {$_.Extension -in '.log','.json','.ps1'})
$files+=@(Get-ChildItem -LiteralPath "$repo/target/novonet-failure-observation-20261110" -Filter '*-openssl-final-*.log')
$files+=Get-Item "$repo/target/novonet-failure-observation-20261110/Validate.ps1","$repo/target/novonet-failure-observation-20261110/validate-linux.sh"
foreach($platform in 'windows','linux'){
    foreach($scope in 'owner','discovery'){
        $expected=if($scope -eq 'owner'){8}else{2}
        $log=Get-Content "$repo/target/novonet-failure-observation-20261110/$platform-openssl-final-$scope.log" -Raw
        if($log -notmatch "test result: ok\. $expected passed; 0 failed"){throw "Unfinished $platform $scope"}
    }
    $log=Get-Content "$repo/target/novonet-failure-observation-20261110/$platform-openssl-final-clippy.log" -Raw
    if($log -notmatch 'Finished `release`'){throw "Unfinished $platform clippy"}
    $log=Get-Content "$PSScriptRoot/$platform-rollout-policy.log" -Raw
    if($log -notmatch 'test result: ok\. 1 passed; 0 failed'){throw "Unfinished $platform consumer"}
}
$archive="$output/original-evidence.zip"
if(Test-Path -LiteralPath $archive){throw 'Preserve original evidence archive'}
if(@($files.Name|Sort-Object -Unique).Count -ne $files.Count){throw 'Duplicate archive member names'}
Compress-Archive -LiteralPath $files.FullName -DestinationPath $archive -CompressionLevel Optimal
$zip=[IO.Compression.ZipFile]::OpenRead($archive)
try {
    if($zip.Entries.Count -ne $files.Count){throw 'Archive member count differs'}
    foreach($file in $files){
        $entry=$zip.GetEntry($file.Name)
        if(!$entry -or $entry.Length -ne $file.Length){throw 'Archive member size differs'}
        $stream=$entry.Open()
        try{$actual=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
        if($actual -cne (Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()){throw 'Archive member hash differs'}
    }
} finally {$zip.Dispose()}
[ordered]@{archive='original-evidence.zip';bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();members=$files.Count;root_lock_sha256=(Get-FileHash "$repo/Cargo.lock").Hash.ToLowerInvariant();source_base=(git -C $repo rev-parse HEAD).Trim();scope='local affected checks and original failed CI log; not packaged or deployed'} | ConvertTo-Json | Set-Content -LiteralPath "$output/evidence-manifest.json" -Encoding utf8
Write-Output 'PASS archived original logs with every member independently verified'
