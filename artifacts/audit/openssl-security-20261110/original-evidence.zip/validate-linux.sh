#!/usr/bin/env bash
set -euo pipefail
cd /mnt/d/WorksArea/SUPERVM
export PATH=/home/aoem-a1/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/home/aoem-a1/novovm-build-b-20261102
export CARGO_BUILD_JOBS=2
export RUSTUP_TOOLCHAIN=1.94.0
export CARGO_BUILD_TARGET=x86_64-unknown-linux-gnu
runtime="$PWD/artifacts/product-overlay/novonet-sqlite-3fa11f94-linux-x86_64/aoem"
export AOEM_DLL_MANIFEST="$runtime/manifest/aoem-manifest.json"
export NOVOVM_AOEM_MANIFEST="$AOEM_DLL_MANIFEST"
export NOVOVM_AOEM_TEST_MANIFEST="$AOEM_DLL_MANIFEST"
export AOEM_DLL_MANIFEST_REQUIRED=1
export AOEM_DLL="$runtime/linux/core/bin/libaoem_ffi.so"
export NOVOVM_AOEM_DLL="$AOEM_DLL"
export NOVOVM_AOEM_TEST_LIBRARY="$AOEM_DLL"
export AOEM_SEMANTIC_GRAPH_V2_WORKERS=2
export NOVOVM_ALLOW_LEGACY_HOST_EXECUTION=0
read -r actual _ < <(sha256sum "$AOEM_DLL")
test "$actual" = d73e4a2f1ec42f75e7b2356c10779330b1dc902113d290275042d3bf8a06bc33
log_dir="$PWD/target/novonet-failure-observation-20261110"
run=${1:-final-2}
[[ "$run" =~ ^[a-z0-9-]+$ ]]
check() {
    local label="$1"; shift
    local log="$log_dir/linux-$run-$label.log"
    test ! -e "$log"
    cargo "$@" 2>&1 | tee "$log"
    if [[ "$label" != clippy ]]; then
        grep -Eq 'test result: ok\. [1-9][0-9]* passed' "$log"
    fi
}
check owner test --release --locked -p novovm-node --lib --features iroh-transport native_pipeline::service::network::tests -- --test-threads=1 --nocapture
check discovery test --release --locked -p novovm-node --lib --features iroh-transport native_pipeline::service::network::discovery::tests -- --test-threads=1 --nocapture
check clippy clippy --release --locked -p novovm-node --lib --tests --features iroh-transport -- -D warnings
printf '%s\n' 'PASS affected local checks only; no deployment or cloud dispatch'
