param([ValidateSet('first','final','final2')][string]$Phase)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$root='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-68fa7588-20261110'
$out=Join-Path $root 'public-update-evidence'
if(!(Test-Path $out)){New-Item -ItemType Directory -Path $out|Out-Null}
function Remote([string]$Path,[string]$Name){
    if(Test-Path "$out/$Name"){throw 'Evidence already exists'}
    $raw=ssh.exe -F C:/Users/leadb/.ssh/validator-B.conf -o BatchMode=yes -o ConnectTimeout=10 validator-B "sudo -n cat $Path"
    if($LASTEXITCODE -ne 0){throw 'B read failed'}
    $null=$raw|ConvertFrom-Json
    [IO.File]::WriteAllText("$out/$Name",($raw -join "`n"),[Text.UTF8Encoding]::new($false))
}
Copy-Item C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-observation-68fa7588-20261110/logs/progress.json "$out/A-progress-$Phase.json"
Copy-Item C:/ProgramData/NOVOVM/selfrun/91129655606029/A/novonet-08236129-20261108/locator.json "$out/A-locator-$Phase.json"
Remote '/var/lib/novovm/selfrun/91129655606029/B/novonet-observation-68fa7588-20261110/logs/progress.json' "B-progress-$Phase.json"
Remote '/var/lib/novovm/selfrun/91129655606029/B/novonet-ce1-20261108/locator-B.json' "B-locator-$Phase.json"
if($Phase -eq 'first'){exit}
foreach($name in @('prepared.json','started.json','old-exit.json','runtime.stdout')){if(!(Test-Path "$out/B-$name")){Remote "/home/ecs-user/novovm-observation-update-68fa7588-20261110/evidence/$name" "B-$name"}}
foreach($name in @('after.json','result.json','old-exit.json')){Copy-Item "$root/A-update/$name" "$out/A-$name"}
foreach($h in @('A','B')){foreach($p in @('before','after')){foreach($ext in @('json','stderr')){Copy-Item "$root/authenticated-$h-$p/original.$ext" "$out/$h-status-$p.$ext"}}}
$hosts=@()
foreach($h in @('B','A')){
    $first=Get-Content "$out/$h-progress-first.json" -Raw|ConvertFrom-Json
    $last=Get-Content "$out/$h-progress-$Phase.json" -Raw|ConvertFrom-Json
    $lf=Get-Content "$out/$h-locator-first.json" -Raw|ConvertFrom-Json
    $ll=Get-Content "$out/$h-locator-$Phase.json" -Raw|ConvertFrom-Json
    $now=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    if($last.ticks -le $first.ticks -or $last.execution_failures -ne 0 -or $ll.sequence -le $lf.sequence -or $ll.expires_at_ms -le $now -or $ll.issued_at_ms -gt $now){throw 'Progress or locator not advancing'}
    $s=Get-Content $(if($h -eq 'A'){"$out/A-after.json"}else{"$out/B-started.json"}) -Raw|ConvertFrom-Json
    $old=Get-Content "$out/$h-old-exit.json" -Raw|ConvertFrom-Json
    $health=@{}
    foreach($p in @('before','after')){
        $q=Get-Content "$out/$h-status-$p.json" -Raw|ConvertFrom-Json
        $a=$q.result.answer.Status
        $health[$p]=@{elapsed_ms=$q.elapsed_ms;root=[Convert]::ToHexString([byte[]]$a.state_root).ToLowerInvariant();height=$a.height;current_height=$a.current_height;recovering=$a.recovering;projection_failed=$a.projection_failed}
    }
    $hosts+=@{host=$h;old_pid=$old.pid;new_pid=$s.pid;node_sha256=$s.node_sha256;aoem_sha256=$s.aoem_sha256;database=$s.database;owner=$(if($h -eq 'A'){$s.sid}else{"novovm uid=$($s.uid)"});custody_unchanged=$s.custody_unchanged;start='existing';health=$health;locator_sequence_first=$lf.sequence;locator_sequence_final=$ll.sequence;locator_fresh=$true;ticks_first=$first.ticks;ticks_final=$last.ticks;novonet=$last.novonet}
}
$b=Get-Content "$out/B-started.json" -Raw|ConvertFrom-Json
$result=@{source='68fa758820889c3f5e8bb230aa42cef100b77b4b';time_utc=[DateTime]::UtcNow.ToString('o');order=@('B','A');hosts=$hosts;other_services_after=$b.other_services_after;other_services_unchanged=$b.other_services_unchanged;firewall_profiles=@(Get-NetFirewallProfile|Select-Object Name,Enabled);initialize_executed=$false;keys_generated=$false;rollback_executed=$false;C_D_updated=$false;new_probe_sent=$false;root_cause_resolved=$false;ci_run=42685932056;ci_conclusion='success';failure_boundary='A discovery_lookup: carrier connect deadline before entry write, NOVONET bound authentication and RPC; exact carrier subphase unknown'}
$result|ConvertTo-Json -Depth 35|Set-Content "$out/update-result.json" -Encoding utf8NoBOM
gh run view 42685932056 --json status,conclusion,headSha,jobs > "$out/ci-final.json"
if($LASTEXITCODE -ne 0){throw 'CI read failed'}
$ci=Get-Content "$out/ci-final.json" -Raw|ConvertFrom-Json
if($ci.headSha -ne $result.source -or $ci.conclusion -ne 'success'){throw 'CI mismatch'}
foreach($f in @('Update-A.ps1','Update-B.py','NovonetExistingProcess.ps1')){Copy-Item "$root/update-tools/$f" "$out/$f"}
Copy-Item "$PSScriptRoot/Read-Update-Status.ps1" "$out/Read-Update-Status.ps1"
Copy-Item $PSCommandPath "$out/Collect-Update.ps1"
$members=@(Get-ChildItem $out -File|ForEach-Object{@{name=$_.Name;bytes=$_.Length;sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}})
$members|ConvertTo-Json -Depth 5|Set-Content "$out/evidence-members.json" -Encoding utf8NoBOM
$dest='D:/WorksArea/SUPERVM/artifacts/audit/openssl-security-20261110/candidate-68fa7588'
$zip="$dest/original-update-evidence.zip"
if(Test-Path $zip){throw 'Archive exists'}
[IO.Compression.ZipFile]::CreateFromDirectory($out,$zip)
$z=[IO.Compression.ZipFile]::OpenRead($zip)
try{foreach($m in $members){$e=$z.GetEntry($m.name);$stream=$e.Open();try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()};if($e.Length -ne $m.bytes -or $hash -ne $m.sha256){throw 'Archive mismatch'}}}finally{$z.Dispose()}
Copy-Item "$out/update-result.json" "$dest/update-result.json"
Get-FileHash $zip
$hosts|Select-Object host,new_pid,locator_sequence_final,novonet|ConvertTo-Json -Depth 12
