$ErrorActionPreference='Stop'
$source='68fa758820889c3f5e8bb230aa42cef100b77b4b'
$repo='D:/WorksArea/SUPERVM'
$delivery='C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-68fa7588-20261110'
$output="$repo/artifacts/audit/openssl-security-20261110/candidate-68fa7588"
$package='novonet-observation-68fa7588'
if(Test-Path -LiteralPath $output){throw 'Preserve candidate evidence'}
$records=@()
foreach($platform in 'windows','linux'){
    $verified=Get-Content "$delivery/verified-$platform.json" -Raw|ConvertFrom-Json
    $log=Get-Content "$delivery/packaged-native-identity-$platform.log" -Raw
    if($verified.source_commit -cne $source -or $log -notmatch 'test result: ok\. 7 passed; 0 failed'){throw 'Actual qualified fixed package required'}
    $root="$repo/artifacts/product-overlay/$package-$platform-x86_64"
    if((Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant() -cne $verified.manifest_sha256){throw 'Manifest changed'}
    $extension=if($platform -eq 'windows'){'.zip'}else{'.tar.gz'}
    $archive="$delivery/$package-$platform-x86_64$extension"
    if($platform -eq 'windows'){
        $zip=[IO.Compression.ZipFile]::OpenRead($archive)
        try{
            $files=@(Get-ChildItem -LiteralPath $root -Recurse -File)
            if(@($zip.Entries|Where-Object {!$_.FullName.EndsWith('/')}).Count -ne $files.Count){throw 'ZIP file count differs'}
            foreach($file in $files){
                $relative=[IO.Path]::GetRelativePath($root,$file.FullName).Replace('\','/')
                $entry=$zip.GetEntry("$package-$platform-x86_64/$relative")
                if(!$entry -or $entry.Length -ne $file.Length){throw "ZIP size/path differs $relative"}
                $stream=$entry.Open()
                try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)).ToLowerInvariant()}finally{$stream.Dispose()}
                if($hash -cne (Get-FileHash $file.FullName).Hash.ToLowerInvariant()){throw "ZIP hash differs $relative"}
            }
        }finally{$zip.Dispose()}
    }
    $records+=[ordered]@{platform=$platform;source_commit=$source;archive=[IO.Path]::GetFileName($archive);archive_bytes=(Get-Item $archive).Length;archive_sha256=(Get-FileHash $archive).Hash.ToLowerInvariant();manifest_sha256=$verified.manifest_sha256;artifacts_verified=$verified.artifacts_verified;node_sha256=$verified.node_sha256;client_sha256=$verified.client_sha256;ctl_sha256=$verified.ctl_sha256;aoem_sha256=$verified.actual_packaged_runtime.data.library_sha256;packaged_identity_nat_tests_passed=7;deployed=$false}
}
New-Item -ItemType Directory -Path $output|Out-Null
$files=@(Get-ChildItem -LiteralPath $delivery -File|Where-Object {$_.Extension -in '.log','.json'})
$files+=Get-Item "$PSScriptRoot/Candidate.ps1","$PSScriptRoot/Prepare-Updaters.ps1","$PSScriptRoot/Record-Candidate.ps1"
Compress-Archive -LiteralPath $files.FullName -DestinationPath "$output/original-package-evidence.zip" -CompressionLevel Optimal
[ordered]@{source_commit=$source;local_delivery_directory=$delivery;packages=$records;package_evidence_sha256=(Get-FileHash "$output/original-package-evidence.zip").Hash.ToLowerInvariant();scope='actual local package qualification; CI and deployment separate'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$output/candidate-manifest.json" -Encoding utf8
Write-Output 'PASS fixed candidate manifest and independent Windows ZIP member verification; Linux tar diff was recorded by original archiver'
