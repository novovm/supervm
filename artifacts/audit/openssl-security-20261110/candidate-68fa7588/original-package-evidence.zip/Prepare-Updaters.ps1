# Generate this delivery's pinned copies of the original updaters and their guards.
# This script does not invoke an updater, touch node state, or stop a process.
$ErrorActionPreference='Stop'
$repo='D:/WorksArea/SUPERVM'
$source='68fa758820889c3f5e8bb230aa42cef100b77b4b'
$short=$source.Substring(0,8)
$package="novonet-observation-$short"
$delivery="C:/Users/leadb/AppData/Local/NOVOVM/candidate-observation-$short-20261110"
$output="$delivery/update-tools"
if(Test-Path -LiteralPath $output){throw 'Preserve prepared deployment tools'}
$windows=Get-Content "$delivery/verified-windows.json" -Raw|ConvertFrom-Json
$linux=Get-Content "$delivery/verified-linux.json" -Raw|ConvertFrom-Json
foreach($verified in $windows,$linux){
    if($verified.source_commit -cne $source){throw 'Wrong verified source'}
    $root="$repo/artifacts/product-overlay/$package-$($verified.platform)-x86_64"
    if((Get-FileHash "$root/release-manifest.json").Hash.ToLowerInvariant() -cne $verified.manifest_sha256){throw 'Verified manifest changed'}
    $log=Get-Content "$delivery/packaged-native-identity-$($verified.platform).log" -Raw
    if($log -notmatch 'test result: ok\. 7 passed; 0 failed'){throw 'Actual package qualification required'}
}
$archive="$delivery/$package-linux-x86_64.tar.gz"
$archivePin=(Get-FileHash $archive).Hash.ToLowerInvariant()
New-Item -ItemType Directory -Path $output|Out-Null
function Save-New([string]$Name,[string]$Text){
    $path=Join-Path $output $Name
    $file=[IO.File]::Open($path,[IO.FileMode]::CreateNew)
    try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes($Text);$file.Write($bytes);$file.Flush($true)}finally{$file.Dispose()}
}
function Adapt-B([string]$Text){
    $Text=$Text.Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$source)
    $Text=$Text.Replace('d6ed8d869c46530077e9feb61b4ce0ef83dddcddc907f2e6d8a443825ae3e692',$archivePin)
    $Text=$Text.Replace('3a837ed6095a826e96df42610972980287f677c59d8ba02d426961a99dae2247',$linux.manifest_sha256)
    $Text=$Text.Replace('8ae62f05146112f792b7868e170a1ae03445c783bf7964f2416bfb7ebff2184c',$linux.node_sha256)
    $Text=$Text.Replace('dbdcd2f08bd0ddb83ebd0a6027cf54f8d4dee9f03a7a9ab8b988750d8f79a8b7','8ae62f05146112f792b7868e170a1ae03445c783bf7964f2416bfb7ebff2184c')
    $Text=$Text.Replace('novovm-sqlite-update-3fa11f94-20261110',"novovm-observation-update-$short-20261110")
    $Text=$Text.Replace('novonet-sqlite-3fa11f94',$package).Replace('novovm-B-3fa11f94-network',"novovm-B-$short-network").Replace('pre3fa11f94',"pre$short")
    $Text=$Text.Replace('novonet-relay-evidence-2b97fc8e-20261109','novonet-sqlite-3fa11f94-20261110').Replace('novonet-relay-evidence-2b97fc8e-linux','novonet-sqlite-3fa11f94-linux')
    $Text=$Text.Replace('novovm-B-2b97fc8e-network-20261109.service','novovm-B-3fa11f94-network-20261110.service').Replace("'logs-retry-start-1/progress.json'","'logs/progress.json'")
    return $Text
}
$b=Get-Content "$repo/scripts/linux/update-novonet-existing.py" -Raw
$b=Adapt-B $b
$b=$b.Replace('B-only 3fa candidate updater',"B-only $short candidate updater")
Save-New 'Update-B.py' $b
$bt=Adapt-B (Get-Content "$repo/scripts/tests/test_novonet_linux_existing.py" -Raw)
$bt=$bt.Replace("Path(__file__).resolve().parents[1] / 'linux/update-novonet-existing.py'","Path(__file__).resolve().parent / 'Update-B.py'")
Save-New 'test_update_b.py' $bt
function Adapt-A([string]$Text){
    $Text=$Text.Replace('3fa11f940b18e54b46e6b927d3d66294bea37088',$source)
    $Text=$Text.Replace('424e70b8b0acf847598f2bd7b5aefb4276bad052ab2afb64f7e8412d60d9e1bb',$windows.manifest_sha256)
    $Text=$Text.Replace('5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27',$windows.node_sha256)
    $Text=$Text.Replace('3fa11f94',$short).Replace("novonet-sqlite-$short",$package)
    $Text=$Text.Replace('ff68c5930b9b205b25ba5351a17ad08aa68f51d7cf71779d0507b6269f4087f3','5a471fc805f86aaf57d6b06a4cfc1f4ba8aacff7eea67c74fabe036718a27b27')
    $Text=$Text.Replace('novonet-probe-5181da73-20261109','novonet-sqlite-3fa11f94-20261110').Replace('novonet-probe-5181da73-windows','novonet-sqlite-3fa11f94-windows')
    $Text=$Text.Replace('5181da73-Existing-20261109','3fa11f94-Existing-20261110').Replace('NOVOVM-5181da73-$HostId-20261109','NOVOVM-3fa11f94-$HostId-20261110')
    return $Text
}
$a=Adapt-A (Get-Content "$repo/scripts/windows/Update-NovonetExisting.ps1" -Raw)
$a=$a.Replace("ValidateSet('A','C','D')","ValidateSet('A')")
Save-New 'Update-A.ps1' $a
Copy-Item -LiteralPath "$repo/scripts/windows/NovonetExistingProcess.ps1" -Destination "$output/NovonetExistingProcess.ps1"
$at=Adapt-A (Get-Content "$repo/scripts/tests/novonet-existing-update.tests.ps1" -Raw)
$at=$at.Replace("'../windows/Update-NovonetExisting.ps1'","'Update-A.ps1'").Replace("foreach(`$HostId in @('A','C','D'))","foreach(`$HostId in @('A'))")
$at=$at.Replace("Join-Path `$PSScriptRoot ('../../target/relay-evidence-20261109/gate-tests-'","Join-Path `$PSScriptRoot ('gate-tests-'")
Save-New 'Test-Update-A.ps1' $at
Write-Output 'Prepared pinned original updater copies; no deployment performed; run their guards before use'
