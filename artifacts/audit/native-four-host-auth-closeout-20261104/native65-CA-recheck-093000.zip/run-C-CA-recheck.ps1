$ErrorActionPreference = 'Stop'
$start = [DateTimeOffset]'2026-11-04T09:30:00+08:00'
if ([DateTimeOffset]::UtcNow -ge $start.AddMinutes(-5)) { throw 'Missed arming deadline; report, do not catch up.' }
$exe = Join-Path $env:LOCALAPPDATA 'NOVOVM/candidates/native65-d7ef793b-windows-x86_64/bin/novovm-product-nat.exe'
if ((Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant() -ne '970e89225b5daa6a1563e0d5313db3cf25ad3ba2a90a0cc2188c8bf5a58dec73') { throw 'Wrong frozen NAT executable' }
foreach ($line in Get-Content -LiteralPath "$PSScriptRoot/CONFIG-CHECKSUMS.sha256") {
    if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw 'Invalid checksum line' }
    $expected=$Matches[1]; $path=Join-Path $PSScriptRoot $Matches[2]
    if ((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ne $expected) { throw 'Changed recheck config' }
}
$out=Join-Path $env:LOCALAPPDATA 'NOVOVM/four-host-167999907280566/lan-evidence-20261104-093000-C'
if (Test-Path -LiteralPath $out) { throw 'Preserve existing evidence; do not overwrite' }
foreach($case in @('first','second')) {
    $path=Join-Path $PSScriptRoot "C/probe-C-A-$case.json"
    $config=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
    if ((Get-FileHash -LiteralPath $config.library).Hash.ToLowerInvariant() -ne $config.library_sha256) { throw 'Wrong candidate AOEM' }
    if (Test-Path -LiteralPath (Join-Path "$PSScriptRoot/C" $config.report_path)) { throw 'Preserve original native report' }
}
New-Item -ItemType Directory -Path $out | Out-Null
Find-NetRoute -RemoteIPAddress 192.168.71.74 | Select-Object IPAddress,InterfaceAlias,InterfaceIndex,DestinationPrefix,NextHop |
    ConvertTo-Json -Depth 3 > "$out/routes-before.json"
Write-Output 'ARMED_CA_RECHECK_C start=2026-11-04T09:30:00+08:00; keep this terminal running'
while([DateTimeOffset]::UtcNow -lt $start) { Start-Sleep -Seconds 1 }
if([DateTimeOffset]::UtcNow -gt $start.AddSeconds(5)) { throw 'Missed execution time; do not catch up' }
$records=@()
foreach($case in @('first','second')) {
    $begin=[DateTimeOffset]::UtcNow
    & $exe (Join-Path $PSScriptRoot "C/probe-C-A-$case.json") > "$out/$case.stdout.txt" 2> "$out/$case.stderr.txt"
    $code=$LASTEXITCODE
    $records+=@{case=$case;started_utc=$begin.ToString('o');ended_utc=[DateTimeOffset]::UtcNow.ToString('o');exit_code=$code}
    $records|ConvertTo-Json -Depth 4 > "$out/execution.json"
    if($code -ne 0) { exit $code }
}
Write-Output 'C/A recheck finished; return original reports, stdout/stderr, execution and routes to A'
