# 三组 LAN 认证收尾：当前只做 READY_LAN

继续使用已验收 d7ef793b Windows 包、同一 AOEM core 和本机已有传输身份。
本包只有公开原配置，没有EXE、DLL、私钥或新协议。配置版本2、域
167999907280566、原10秒probe和90秒observer不变；不启链、不改生产超时。

| 配对 | 原 observer | 原 probe | probe目的地址 |
| --- | --- | --- | --- |
| A/C | A固定C公钥 | C连续first/second | 192.168.71.74:41050 |
| A/D | A固定D公钥 | D连续first/second | 192.168.71.74:41050 |
| C/D | D固定C公钥 | C连续first/second | 192.168.71.59:41050 |

没有B、公网地址或Relay/WSS回退。对端身份仍用完整1952字节公钥pin，
不自行用指纹填写peer_id。双方报告及下列本机路由证据一起验收LAN路径。

## 现在给 C/D Codex 的动作

1. 从A消息核对ZIP SHA256，解压到新的独立目录，例如
   `%LOCALAPPDATA%/NOVOVM/four-host-167999907280566/lan-20261104`，不覆盖旧报告。
2. 按LAN-CHECKSUMS.sha256核对README和全部配置，只解析/执行本机C或D目录。
3. 核对原候选/身份路径与此前回执一致，不重装、编译或生成密钥。
4. 仅复核本轮必须的地址/路径差额：C当前LAN IPv4应为192.168.71.125；
   D为192.168.71.59；A已实读192.168.71.74。若不同，回传实际地址给A，
   不擅改本组共同配置。D确认UDP41050无其他进程占用，不挪用旧监听。
5. C保存`Find-NetRoute -RemoteIPAddress 192.168.71.74`和到192.168.71.59的结果；
   D保存到192.168.71.74和192.168.71.125的结果，含源IPv4、接口和下一跳。
   只查这些相关路由，不重做硬件清点或校时，不改VPN/路由/防火墙。
6. 回传READY_LAN_C或READY_LAN_D，说明包验真、地址、路由及D端口状态。
   此时不运行probe/observer。若有权限或规则问题，只回报原错误，不关闭防火墙。

## READY 汇总后统一预约

A将给三个配对统一的执行时刻，沿上一轮方式在保留终端中一次性等待，到点自动运行。
不创建Windows计划任务、常驻服务或另一个协调网络。observer在对应probe前15秒启动。
当前没有生效的LAN开始时刻，禁止套用已过期的07:06/07:09。

C的原命令（按A后续时间，分别C/A及C/D）：

```powershell
$root = Join-Path $env:LOCALAPPDATA 'NOVOVM/four-host-167999907280566/lan-20261104'
$exe = Join-Path $env:LOCALAPPDATA 'NOVOVM/candidates/native65-d7ef793b-windows-x86_64/bin/novovm-product-nat.exe'
& $exe (Join-Path $root 'C/probe-C-A-first.json')
& $exe (Join-Path $root 'C/probe-C-A-second.json')
# 另一预约时刻：
& $exe (Join-Path $root 'C/probe-C-D-first.json')
& $exe (Join-Path $root 'C/probe-C-D-second.json')
```

D的原命令（按A后续时间，D/A和D作C/D observer）：

```powershell
$root = Join-Path $env:LOCALAPPDATA 'NOVOVM/four-host-167999907280566/lan-20261104'
$exe = Join-Path $env:LOCALAPPDATA 'NOVOVM/candidates/native65-d7ef793b-windows-x86_64/bin/novovm-product-nat.exe'
& $exe (Join-Path $root 'D/probe-D-A-first.json')
& $exe (Join-Path $root 'D/probe-D-A-second.json')
# C/D预约时刻前15秒，在D本机运行（有界90秒）：
& $exe (Join-Path $root 'D/observer-D-for-C.json')
```

每个配对first失败则不运行该配对second，保留原报告/退出码/stdout/stderr；
其他独立配对是否继续按A统一预约执行，不覆盖或自动重试失败。
观察端必须保存完整原报告，不能把其accepted=true当成probe已收到回复。
配对时须匹配双方身份、session及观察源地址，实际源地址应为本组预期LAN对端。
若路由或观察地址显示TUN/公网/中继，不把绕通签为LAN直连。

成功新会话不替代旧会话原报文重放；后者由A单独沿原endpoint执行并记录到达/拒绝证据。
本包不授权更换身份/规则、开验证者、创世、NOV分配、业务压测或影响B旧服务。
