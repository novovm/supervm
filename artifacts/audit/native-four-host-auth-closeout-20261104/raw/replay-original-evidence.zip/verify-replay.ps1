param([Parameter(Mandatory)][string]$Root)
$ErrorActionPreference = 'Stop'
$rootPath = (Resolve-Path -LiteralPath $Root).Path
$sender = Get-Content -LiteralPath "$rootPath/attempt-01/sender-result.json" -Raw | ConvertFrom-Json
$receiver = Get-Content -LiteralPath "$rootPath/B.report.json" -Raw | ConvertFrom-Json
$submitted = Get-Content -LiteralPath "$rootPath/attempt-01/replay-submission.json" -Raw | ConvertFrom-Json
$packets = @(foreach ($line in Get-Content -LiteralPath "$rootPath/B-recv.strace") {
    if ($line -notmatch 'recvfrom\(') { continue }
    if ($line -notmatch '^(?<pid>\d+)\s+(?<time>\d+\.\d+) recvfrom\(\d+, "(?<wire>(?:\\x[0-9a-f]{2})+)", \d+, 0, .*sin_port=htons\((?<port>\d+)\), sin_addr=inet_addr\("(?<ip>(?:\\x[0-9a-f]{2})+)"\).* = (?<length>\d+)$') {
        throw 'Unparsed successful receive; do not infer arrival from incomplete trace'
    }
    $fields = $Matches.Clone()
    [byte[]]$wire = @(foreach ($hex in [regex]::Matches($fields.wire, '\\x([0-9a-f]{2})')) {
        [Convert]::ToByte($hex.Groups[1].Value, 16)
    })
    [byte[]]$ipBytes = @(foreach ($hex in [regex]::Matches($fields.ip, '\\x([0-9a-f]{2})')) {
        [Convert]::ToByte($hex.Groups[1].Value, 16)
    })
    if ($wire.Length -ne [int]$fields.length) { throw 'Receive capture was truncated' }
    [pscustomobject]@{
        pid = $fields.pid
        time_unix_seconds = [decimal]::Parse($fields.time, [Globalization.CultureInfo]::InvariantCulture)
        source = [Text.Encoding]::ASCII.GetString($ipBytes) + ':' + $fields.port
        bytes = $wire.Length
        sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($wire)).ToLowerInvariant()
        hex = [Convert]::ToHexString($wire)
    }
})
foreach ($exchange in @($sender.before, $sender.confirmed_new_session, $sender.after)) {
    $path = Join-Path "$rootPath/attempt-01" $exchange.wire_file
    if ((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -ne $exchange.wire_sha256) {
        throw 'Sender saved wire hash mismatch'
    }
}
$old = @($packets | Where-Object sha256 -EQ $sender.before.wire_sha256)
$confirmed = @($packets | Where-Object sha256 -EQ $sender.confirmed_new_session.wire_sha256)
$after = @($packets | Where-Object sha256 -EQ $sender.after.wire_sha256)
if ($old.Count -ne 2 -or $confirmed.Count -ne 1 -or $after.Count -ne 1) {
    throw 'Need two exact old-wire arrivals and one each confirmed/new request arrival'
}
$savedOld = [Convert]::ToHexString([IO.File]::ReadAllBytes("$rootPath/attempt-01/session1-request.wire.bin"))
if ($old[0].hex -ne $savedOld -or $old[1].hex -ne $savedOld) { throw 'Old bytes differ' }
if (-not ($old[0].time_unix_seconds -lt $confirmed[0].time_unix_seconds -and
          $confirmed[0].time_unix_seconds -lt $old[1].time_unix_seconds -and
          $old[1].time_unix_seconds -le $after[0].time_unix_seconds)) {
    throw 'Receiver order does not prove replay after new-session request'
}
if ($submitted.submitted_ms -lt $sender.confirmed_new_session.reply_ms -or
    $submitted.wire_sha256 -ne $sender.before.wire_sha256) { throw 'Replay precedes session2 confirmation' }
$expectedSource = $sender.before.observed_endpoint
foreach ($packet in @($old) + @($confirmed) + @($after)) {
    if ($packet.source -ne $expectedSource) { throw 'Replay or legitimate traffic changed source' }
}
$firstSession = [Convert]::ToHexString([byte[]]$sender.before.session_id)
$secondSession = [Convert]::ToHexString([byte[]]$sender.confirmed_new_session.session_id)
if ($firstSession -eq $secondSession -or
    [Convert]::ToHexString([byte[]]$sender.after.session_id) -ne $secondSession -or
    [Convert]::ToHexString([byte[]]$receiver.session_id) -ne $secondSession) { throw 'Session mismatch' }
if (-not $receiver.accepted -or -not $sender.sender_round_trips_passed -or
    $receiver.authenticated_requests -ne 3 -or $receiver.authenticated_exchanges -ne 3 -or
    $receiver.local_replies_submitted -ne 3 -or
    $receiver.observed_endpoint -ne $expectedSource -or
    $receiver.local_peer_id -ne $sender.peer_id -or $receiver.peer_id -ne $sender.local_peer_id) {
    throw 'Receiver application counts, identity or valid traffic inconsistent'
}
[pscustomobject]@{
    scope = 'fixed_receiver_original_native_endpoint_stale_session_wire'
    receiver_arrival_proven = $true
    replay_byte_identical = $true
    new_session_confirmed_before_replay = $true
    old_request_not_delivered_to_nat_application = $true
    valid_application_round_trips = 3
    receiver_requests = $receiver.authenticated_requests
    old_wire_sha256 = $sender.before.wire_sha256
    source = $expectedSource
    sessions = @($firstSession.ToLowerInvariant(), $secondSession.ToLowerInvariant())
    arrival_sequence = @($old[0], $confirmed[0], $old[1], $after[0]) | Select-Object pid,time_unix_seconds,source,bytes,sha256
    specific_rejection_code = 'not observed; no SecureReplay classification claimed'
    chain_started = $false
} | ConvertTo-Json -Depth 8
